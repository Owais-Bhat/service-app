(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=window.location.hostname!==`localhost`&&window.location.hostname!==`127.0.0.1`?`/api`:`http://localhost:5000/api`,t=()=>{let e=localStorage.getItem(`auth_token`);return{"Content-Type":`application/json`,Authorization:e?`Bearer ${e}`:``}},n=class{constructor(e){this.table=e,this.params={},this.eqs=[],this.method=`GET`,this.body=null,this.isSingle=!1}select(e=`*`){return this.params.select=e,this}eq(e,t){return this.eqs.push(`${e}:${t}`),this}order(e,{ascending:t=!0}={}){return this.params.order=`${e}:${t?`asc`:`desc`}`,this}in(e,t){return this.params.in=`${e}:${t.join(`,`)}`,this}maybeSingle(){return this.isSingle=!0,this}single(){return this.isSingle=!0,this}_buildQuery(){let e=new URLSearchParams;return Object.entries(this.params).forEach(([t,n])=>e.set(t,n)),this.eqs.forEach(t=>e.append(`eq`,t)),e.toString()}insert(e){return this.method=`POST`,this.body=e,this}upsert(e){return this.method=`POST`,this.body=e,this}update(e){return this.method=`PATCH`,this.body=e,this}delete(){return this.method=`DELETE`,this}async then(n,r){try{let r=this.method===`POST`?``:`?${this._buildQuery()}`,i={method:this.method,headers:t()};this.body&&(i.body=JSON.stringify(this.body));let a=await fetch(`${e}/data/${this.table}${r}`,i),o=await a.json();if(!a.ok)return n({data:null,error:{message:o.error||`Request failed`,status:a.status}});n({data:this.isSingle&&Array.isArray(o)?o[0]:o,error:null})}catch(e){n({data:null,error:{message:e.message}})}}},r=3e3,i=2,a=`realtime_force_poll`,o=(()=>{let t=null,n=null,o=0,s=0,c=`idle`,l=new Set,u=new Set,d=e=>{if(!e)return null;let t=/^(\w+)=eq\.(.+)$/.exec(e);return t?{col:t[1],val:t[2]}:null},f=(e,t)=>{if(e.table&&e.table!==t.table||e.events&&!e.events.has(`*`)&&!e.events.has(t.type))return!1;if(e.filter){let n=d(e.filter);if(n&&t.row&&String(t.row[n.col])!==String(n.val))return!1}return!0},p=e=>{if(e.kind===`db`){let t={eventType:e.type,schema:`public`,table:e.table,new:e.row,old:null};l.forEach(n=>{if(f(n,e))try{n.cb(t)}catch(e){console.error(`[realtime] handler error`,e)}})}else e.kind===`notify`&&u.forEach(t=>{if(!(t.subjects&&!t.subjects.has(e.subject)))try{t.cb(e)}catch(e){console.error(`[realtime] notify handler error`,e)}})},m=()=>{if(t){try{t.close()}catch{}t=null}},h=()=>{n&&=(clearInterval(n),null)},g=()=>{if(c===`poll`)return;m(),c=`poll`,console.warn(`[realtime] using polling fallback (interval `+r+`ms)`);let t=async()=>{let t=localStorage.getItem(`auth_token`);if(t)try{let n=await fetch(`${e}/events/poll?since=${o}`,{headers:{Authorization:`Bearer ${t}`}});if(!n.ok)return;let r=await n.json();typeof r.cursor==`number`&&(o=Math.max(o,r.cursor)),(r.events||[]).forEach(p)}catch{}};t(),n=setInterval(t,r)},_=async()=>{if(c===`sse`)return;let n=localStorage.getItem(`auth_token`);if(!n)return;if(typeof EventSource>`u`||localStorage.getItem(a)===`1`)return g();c=`sse`;let r;try{r=await fetch(`${e}/events/ticket`,{method:`POST`,headers:{Authorization:`Bearer ${n}`}})}catch{return g()}if(!r.ok)return g();let l=await r.json();if(!l.ticket)return g();let u=`${e}/events?ticket=${encodeURIComponent(l.ticket)}`;t=new EventSource(u);let d=!1;t.onopen=()=>{d=!0,s=0},t.onmessage=e=>{let t;try{t=JSON.parse(e.data)}catch{return}typeof t._id==`number`&&(o=Math.max(o,t._id)),p(t)},t.onerror=()=>{if(d||(s+=1),s>=i){try{localStorage.setItem(a,`1`)}catch{}g()}}},v=()=>{c===`idle`&&_()},y=()=>{l.size===0&&u.size===0&&(m(),h(),c=`idle`)};return{addSub(e){return l.add(e),v(),()=>{l.delete(e),y()}},addNotifySub(e){return u.add(e),v(),()=>{u.delete(e),y()}},reset(){m(),h(),l.clear(),u.clear(),o=0,s=0,c=`idle`}}})();function s(e,t){return o.addNotifySub({subjects:e?new Set(e):null,cb:t})}function c(){o.reset()}var l=class{constructor(e){this.name=e,this._handlers=[],this._unsubs=[]}on(e,t,n){let r=new Set([t.event||`*`]);return this._handlers.push({events:r,table:t.table||null,filter:t.filter||null,cb:n}),this}subscribe(){return this._handlers.forEach(e=>this._unsubs.push(o.addSub(e))),this}unsubscribe(){this._unsubs.forEach(e=>e()),this._unsubs=[]}},u={from:e=>new n(e),channel:e=>new l(e),removeChannel:e=>{try{e?.unsubscribe?.()}catch{}},auth:{getSession:async()=>{let e=await u.auth.getUser();return{data:{session:e.data.user?{user:e.data.user}:null}}},onAuthStateChange:e=>{let t=t=>{t.key===`auth_token`&&e(t.newValue?`SIGNED_IN`:`SIGNED_OUT`,null)};return window.addEventListener(`storage`,t),{data:{subscription:{unsubscribe:()=>window.removeEventListener(`storage`,t)}}}},getUser:async()=>{if(!localStorage.getItem(`auth_token`))return{data:{user:null}};try{let n=await fetch(`${e}/auth/me`,{headers:t()}),r=await n.json();return n.ok?{data:{user:r.user}}:{data:{user:null}}}catch{return{data:{user:null}}}},updateUser:async({password:n})=>{try{let r=await fetch(`${e}/auth/update-password`,{method:`POST`,headers:t(),body:JSON.stringify({password:n})}),i=await r.json();return r.ok?{data:{user:i.user},error:null}:{data:null,error:{message:i.error}}}catch(e){return{data:null,error:{message:e.message}}}},signInWithPassword:async({email:t,password:n})=>{try{let r=await fetch(`${e}/auth/signin`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({email:t,password:n})}),i=await r.json();return r.ok?(c(),localStorage.removeItem(a),localStorage.setItem(`auth_token`,i.token),{data:{user:i.user},error:null}):{data:null,error:{message:i.error}}}catch(e){return{data:null,error:{message:e.message}}}},signUp:async({email:t,password:n,options:r})=>{try{let i=await fetch(`${e}/auth/signup`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({email:t,password:n,fullName:r.data.full_name,access_key:r.data.access_key||r.data.regKey})}),a=await i.json();return i.ok?{data:{user:{id:a.userId,email:t}},error:null}:{data:null,error:{message:a.error}}}catch(e){return{data:null,error:{message:e.message}}}},signOut:async()=>(localStorage.removeItem(`auth_token`),{error:null})}};async function d(e){let{data:{user:t}}=await u.auth.getUser();if(t?.role)return t.role;let{data:n,error:r}=await u.from(`profiles`).select(`role`).eq(`id`,e).single();return r?`client`:n?.role||`client`}async function f(t,n){let r=await fetch(`${e}/auth/signin`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({email:t,password:n})}),i=await r.json();return r.ok&&i.token?(c(),localStorage.removeItem(a),localStorage.setItem(`auth_token`,i.token),{data:{user:i.user},error:null}):{data:null,error:{message:i.error||`Sign in failed`}}}async function p(t,n,r,i){let a=await fetch(`${e}/auth/signup`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({email:t,password:n,fullName:r,access_key:i})}),o=await a.json();return a.ok?{data:{user:o.userId},error:null}:{data:null,error:{message:o.error||`Sign up failed`}}}async function m(){return localStorage.removeItem(`auth_token`),localStorage.removeItem(`realtime_force_poll`),c(),{error:null}}var h=null;function g(){return h||(h=document.createElement(`div`),h.className=`toast-container`,document.body.appendChild(h)),h}function _(e,t=`info`,n=3500){let r=g(),i=document.createElement(`div`);i.className=`toast ${t}`,i.innerHTML=`<span>${{success:`✅`,error:`❌`,info:`ℹ️`,warning:`⚠️`}[t]||`ℹ️`}</span><span>${e}</span>`,r.appendChild(i),setTimeout(()=>{i.style.opacity=`0`,i.style.transform=`translateX(20px)`,i.style.transition=`0.3s`,setTimeout(()=>i.remove(),300)},n)}function v(e){if(e instanceof Date)return Number.isNaN(e.getTime())?null:e;let t=String(e||``).trim();if(!t)return null;let n=/^(\d{4})-(\d{2})-(\d{2})(?:T00:00:00\.000Z)?$/.exec(t);if(n)return new Date(Number(n[1]),Number(n[2])-1,Number(n[3]));let r=t.includes(` `)?t.replace(` `,`T`):t,i=new Date(r);return Number.isNaN(i.getTime())?null:i}function y(e){if(!e)return`—`;let t=v(e);return t?t.toLocaleDateString(`en-US`,{month:`short`,day:`numeric`,year:`numeric`}):`-`}function b(e){if(!e)return`—`;let t=v(e);return t?t.toLocaleString(`en-US`,{month:`short`,day:`numeric`,hour:`2-digit`,minute:`2-digit`,second:`2-digit`}):`-`}function x(e){if(!e)return`—`;let t=v(e);return t?t.toLocaleTimeString(`en-US`,{hour:`2-digit`,minute:`2-digit`,second:`2-digit`,hour12:!0}):`-`}function S(e){return e?e.split(` `).map(e=>e[0]).join(``).toUpperCase().slice(0,2):`?`}function C(e,t){if(!t||!t.length)return;let n=Object.keys(t[0]),r=[n.join(`,`),...t.map(e=>n.map(t=>`"${(e[t]===null||e[t]===void 0?``:String(e[t])).replace(/"/g,`""`)}"`).join(`,`))].join(`
`),i=new Blob([r],{type:`text/csv;charset=utf-8;`}),a=document.createElement(`a`),o=URL.createObjectURL(i);a.setAttribute(`href`,o),a.setAttribute(`download`,e),a.style.visibility=`hidden`,document.body.appendChild(a),a.click(),document.body.removeChild(a)}function w(){let e=localStorage.getItem(`theme`)||`light`;document.documentElement.setAttribute(`data-theme`,e),T(e)}function ee(){let e=document.documentElement.getAttribute(`data-theme`)===`dark`?`light`:`dark`;document.documentElement.setAttribute(`data-theme`,e),localStorage.setItem(`theme`,e),T(e)}function T(e){document.querySelectorAll(`.theme-toggle-btn`).forEach(t=>{t.innerHTML=e===`dark`?`☀️`:`🌙`})}function E(e,t=12){let n=new Date(e),r=t;for(;r>0;){let e=n.getHours();if(n.getDay()===0){n.setDate(n.getDate()+1),n.setHours(10,0,0,0);continue}if(e<10){n.setHours(10,0,0,0);continue}if(e>=18){n.setDate(n.getDate()+1),n.setHours(10,0,0,0);continue}let t=new Date(n);t.setHours(18,0,0,0);let i=(t.getTime()-n.getTime())/(1e3*60*60);r<=i?(n.setMilliseconds(n.getMilliseconds()+r*60*60*1e3),r=0):(r-=i,n.setDate(n.getDate()+1),n.setHours(10,0,0,0))}return n}var D=null;function O(){if(D)return D;let e=window.AudioContext||window.webkitAudioContext;return e?(D=new e,D):null}var te=!1;function ne(){if(te)return;let e=O();e&&e.state===`suspended`&&e.resume().catch(()=>{}),te=!0,window.removeEventListener(`click`,ne),window.removeEventListener(`keydown`,ne),window.removeEventListener(`touchstart`,ne)}typeof window<`u`&&(window.addEventListener(`click`,ne,{once:!0}),window.addEventListener(`keydown`,ne,{once:!0}),window.addEventListener(`touchstart`,ne,{once:!0}));function re(e=`info`){let t=O();if(!t)return;t.state===`suspended`&&t.resume().catch(()=>{});let n={payment:[880,1320],success:[660,990],info:[540,720],alert:[440,660]},[r,i]=n[e]||n.info,a=t.currentTime;[r,i].forEach((e,n)=>{let r=t.createOscillator(),i=t.createGain();r.type=`sine`,r.frequency.value=e,r.connect(i).connect(t.destination);let o=a+n*.16;i.gain.setValueAtTime(0,o),i.gain.linearRampToValueAtTime(.18,o+.02),i.gain.exponentialRampToValueAtTime(.001,o+.22),r.start(o),r.stop(o+.24)})}var ie=!1;async function ae(){if(typeof Notification>`u`)return`unsupported`;if(Notification.permission===`granted`)return`granted`;if(Notification.permission===`denied`)return`denied`;if(ie)return Notification.permission;ie=!0;try{return await Notification.requestPermission()}catch{return Notification.permission}}function k({title:e,body:t,tag:n,onclick:r,type:i=`info`}){if(re(i),typeof Notification<`u`&&Notification.permission===`granted`)try{let i=new Notification(e,{body:t,tag:n,renotify:!0,silent:!1});return r&&(i.onclick=()=>{window.focus(),r(),i.close()}),i}catch{}_(`${e}${t?` — `+t:``}`,i===`payment`?`success`:i,6e3)}function oe(e){let t=new Date,n=e.getTime()-t.getTime();return n<=0?`<span style="color:var(--danger);font-weight:700">OVERDUE</span>`:`<span style="color:var(--primary);font-weight:600">${Math.floor(n/(1e3*60*60))}h ${Math.floor(n%(1e3*60*60)/(1e3*60))}m left</span>`}function se(e){if(!e)return`-`;let t=new Date(e),n=new Date,r=t.getTime()<n.getTime(),i=`${t.getDate()} ${t.toLocaleDateString(`en-US`,{weekday:`long`})} ${t.toLocaleTimeString(`en-US`,{hour:`numeric`,minute:`2-digit`,hour12:!0}).toLowerCase()}`;return`<span style="color:${r?`var(--danger)`:`var(--success)`};font-weight:600;">${i}</span>`}function A(e){e&&(e.innerHTML=`
    <div style="display:flex;justify-content:center;align-items:center;min-height:300px;">
      <div style="text-align:center;">
        <div style="width:50px;height:50px;border:4px solid var(--border);border-top:4px solid var(--primary);border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 16px;" class="loader-spinner"></div>
        <p style="color:var(--text-dim);font-weight:600;">Loading...</p>
      </div>
    </div>
  `)}var j={shield:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 5 6v6c0 4.5 3 8 7 9 4-1 7-4.5 7-9V6l-7-3Z"/><path d="m9 12 2 2 4-4"/></svg>`,whatsapp:`<svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>`,phone:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.3 1.8.6 2.6a2 2 0 0 1-.5 2.1L8 9.6a16 16 0 0 0 6 6l1.2-1.2a2 2 0 0 1 2.1-.5c.8.3 1.7.5 2.6.6a2 2 0 0 1 1.7 2Z"/></svg>`,user:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>`,users:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21a4 4 0 0 0-8 0"/><circle cx="12" cy="7" r="4"/><path d="M22 21a4 4 0 0 0-3-3.87"/><path d="M2 21a4 4 0 0 1 3-3.87"/></svg>`,pin:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s7-6.5 7-12a7 7 0 1 0-14 0c0 5.5 7 12 7 12Z"/><circle cx="12" cy="10" r="2.5"/></svg>`,crosshair:`<svg viewBox="0 0 24 24" fill="currentColor"><path d="M13.02 19.93v2.02c2.01-.2 3.84-1 5.32-2.21l-1.42-1.43a7.941 7.941 0 0 1-3.9 1.62zM4.03 12c0-4.05 3.03-7.41 6.95-7.93V2.05C5.95 2.58 2.03 6.84 2.03 12c0 5.16 3.92 9.42 8.95 9.95v-2.02c-3.92-.52-6.95-3.88-6.95-7.93zM19.95 11h2.02c-.2-2.01-1-3.84-2.21-5.32l-1.43 1.43c.86 1.1 1.44 2.43 1.62 3.89zM18.34 4.26a9.981 9.981 0 0 0-5.32-2.21v2.02c1.46.18 2.79.76 3.9 1.62l1.42-1.43zM18.33 16.9l1.43 1.42A9.949 9.949 0 0 0 21.97 13h-2.02a7.941 7.941 0 0 1-1.62 3.9z"/><path d="M16 11.1C16 8.61 14.1 7 12 7s-4 1.61-4 4.1c0 1.66 1.33 3.63 4 5.9 2.67-2.27 4-4.24 4-5.9zm-4 .9a1.071 1.071 0 0 1 0-2.14A1.071 1.071 0 0 1 12 12z"/></svg>`,edit:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 1 1 3 3L7 19l-4 1 1-4 12.5-12.5Z"/></svg>`,receipt:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 3h14v18l-3-2-2 2-2-2-2 2-2-2-3 2V3Z"/><path d="M9 8h6M9 12h6M9 16h4"/></svg>`,wrench:`<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 14V16C8.68629 16 6 18.6863 6 22H4C4 17.5817 7.58172 14 12 14ZM12 13C8.685 13 6 10.315 6 7C6 3.685 8.685 1 12 1C15.315 1 18 3.685 18 7C18 10.315 15.315 13 12 13ZM12 11C14.21 11 16 9.21 16 7C16 4.79 14.21 3 12 3C9.79 3 8 4.79 8 7C8 9.21 9.79 11 12 11ZM14.5946 18.8115C14.5327 18.5511 14.5 18.2794 14.5 18C14.5 17.7207 14.5327 17.449 14.5945 17.1886L13.6029 16.6161L14.6029 14.884L15.5952 15.4569C15.9883 15.0851 16.4676 14.8034 17 14.6449V13.5H19V14.6449C19.5324 14.8034 20.0116 15.0851 20.4047 15.4569L21.3971 14.8839L22.3972 16.616L21.4055 17.1885C21.4673 17.449 21.5 17.7207 21.5 18C21.5 18.2793 21.4673 18.551 21.4055 18.8114L22.3972 19.3839L21.3972 21.116L20.4048 20.543C20.0117 20.9149 19.5325 21.1966 19.0001 21.355V22.5H17.0001V21.3551C16.4677 21.1967 15.9884 20.915 15.5953 20.5431L14.603 21.1161L13.6029 19.384L14.5946 18.8115ZM18 19.5C18.8284 19.5 19.5 18.8284 19.5 18C19.5 17.1716 18.8284 16.5 18 16.5C17.1716 16.5 16.5 17.1716 16.5 18C16.5 18.8284 17.1716 19.5 18 19.5Z"/></svg>`,refresh:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 0 1-15.5 6.4M3 12a9 9 0 0 1 15.5-6.4"/><path d="M21 4v5h-5M3 20v-5h5"/></svg>`,check:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m8 12 3 3 5-6"/></svg>`,arrowRight:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>`,arrowLeft:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M11 6l-6 6 6 6"/></svg>`,moon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z"/></svg>`,sun:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4 12H2M22 12h-2M5 5l1.5 1.5M17.5 17.5 19 19M5 19l1.5-1.5M17.5 6.5 19 5"/></svg>`,staff:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>`,dashboard:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/></svg>`,ticket:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v2a2 2 0 0 0 0 4v2a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-2a2 2 0 0 0 0-4V9Z"/><path d="M13 7v10"/></svg>`,inbox:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3 13h5l2 3h4l2-3h5"/><path d="M5 4h14l3 9v5a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-5l3-9Z"/></svg>`,box:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8 12 3 3 8v8l9 5 9-5V8Z"/><path d="m3 8 9 5 9-5"/><path d="M12 13v8"/></svg>`,building:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="2" width="16" height="20" rx="1.5"/><path d="M8 6h2M14 6h2M8 10h2M14 10h2M8 14h2M14 14h2M10 22v-4h4v4"/></svg>`,clock:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>`,clipboard:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="4" width="12" height="18" rx="2"/><path d="M9 4V3a2 2 0 0 1 6 0v1"/><path d="M9 12h6M9 16h4"/></svg>`,search:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>`,eye:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>`,eyeOff:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="m3 3 18 18"/><path d="M10.6 10.6A3 3 0 0 0 13.4 13.4"/><path d="M9.9 5.2A10.8 10.8 0 0 1 12 5c6.5 0 10 7 10 7a17.8 17.8 0 0 1-3.2 4.2"/><path d="M6.1 6.8C3.5 8.6 2 12 2 12s3.5 7 10 7a10.4 10.4 0 0 0 5.1-1.3"/></svg>`,star:`<svg viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1" stroke-linejoin="round"><path d="m12 2 3 7 7 .6-5.3 4.6 1.6 7-6.3-3.8L5.7 21l1.6-7L2 9.6 9 9l3-7Z"/></svg>`,starOutline:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><path d="m12 2 3 7 7 .6-5.3 4.6 1.6 7-6.3-3.8L5.7 21l1.6-7L2 9.6 9 9l3-7Z"/></svg>`,settings:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Z"/><path d="M19.4 15a1.8 1.8 0 0 0 .36 2l.05.05a2.1 2.1 0 0 1-3 3l-.05-.05a1.8 1.8 0 0 0-2-.36 1.8 1.8 0 0 0-1.1 1.66V21a2.1 2.1 0 0 1-4.2 0v-.08A1.8 1.8 0 0 0 8.4 19.3a1.8 1.8 0 0 0-2 .36l-.05.05a2.1 2.1 0 0 1-3-3l.05-.05a1.8 1.8 0 0 0 .36-2 1.8 1.8 0 0 0-1.66-1.1H2a2.1 2.1 0 0 1 0-4.2h.08A1.8 1.8 0 0 0 3.7 8.3a1.8 1.8 0 0 0-.36-2l-.05-.05a2.1 2.1 0 0 1 3-3l.05.05a1.8 1.8 0 0 0 2 .36H8.4A1.8 1.8 0 0 0 9.5 2.1V2a2.1 2.1 0 0 1 4.2 0v.08a1.8 1.8 0 0 0 1.1 1.66 1.8 1.8 0 0 0 2-.36l.05-.05a2.1 2.1 0 0 1 3 3l-.05.05a1.8 1.8 0 0 0-.36 2v.08a1.8 1.8 0 0 0 1.66 1.1H22a2.1 2.1 0 0 1 0 4.2h-.08A1.8 1.8 0 0 0 19.4 15Z"/></svg>`,block:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="m5.7 5.7 12.6 12.6"/></svg>`,rupee:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M6 4h12M6 9h12M6 14c4 0 6-2.2 6-5"/><path d="m9 14 7 7"/></svg>`,card:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="2.5"/><path d="M2 10h20M6 15h2M11 15h3"/></svg>`,logout:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5M21 12H9"/></svg>`,menu:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6h16M4 12h16M4 18h16"/></svg>`,close:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18M6 6l12 12"/></svg>`,play:`<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7L8 5Z"/></svg>`,pause:`<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/></svg>`,alert:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 9v4M12 17h.01"/><path d="M10.3 3.7 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.7a2 2 0 0 0-3.4 0Z"/></svg>`,hourglass:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2h12M6 22h12M6 2v4l6 6 6-6V2M6 22v-4l6-6 6 6v4"/></svg>`,plus:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>`,link:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/></svg>`,upload:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M17 8l-5-5-5 5"/><path d="M12 3v12"/></svg>`,download:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></svg>`,edit:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5Z"/></svg>`},ce=new URL(`/assets/logo-Cuxe_Kd5.png`,``+import.meta.url).href;function le(e,t){let n=document.getElementById(`app`),r=`login`,i=()=>{let a=localStorage.getItem(`theme`)||`light`;n.innerHTML=`
      <div class="auth-page">
        ${t?`
        <button class="btn btn-secondary" id="auth-back-btn" style="position: absolute; top: 20px; left: 20px; padding: 8px; border-radius: 50%; min-width: 42px; min-height: 42px; z-index: 10; display: flex; align-items: center; justify-content: center;" title="Back">
          <span style="width: 20px; height: 20px; display: flex;">
            ${j.arrowLeft}
          </span>
        </button>
        `:``}
        <button class="btn btn-secondary theme-toggle-btn" style="position: absolute; top: 20px; right: 20px; padding: 8px; border-radius: 50%; min-width: 42px; min-height: 42px; z-index: 10; display: flex; align-items: center; justify-content: center;" title="Toggle Theme">
          <span style="width: 20px; height: 20px; display: flex;">
            ${a===`dark`?j.sun:j.moon}
          </span>
        </button>
        <div class="auth-card">
          <div class="auth-logo">
            <img src="${ce}" alt="Networking Experts" onerror="this.style.display='none'" />
          </div>
          <h2 class="auth-title">${r===`login`?`Welcome Back`:`Create Account`}</h2>
          <p class="auth-subtitle">${r===`login`?`Sign in to continue`:`Register your account`}</p>
          <div id="auth-error" class="auth-error" style="display:none"></div>

          <form id="auth-form">
            ${r===`signup`?`
              <div class="form-group">
                <label>Full Name</label>
                <input type="text" id="full_name" placeholder="John Doe" required />
              </div>
              <div class="form-group">
                <label>Staff / Admin Access Key</label>
                <div class="password-field">
                  <input type="password" id="reg_key" placeholder="Enter staff or admin secret key" required />
                  <button type="button" class="password-toggle" data-target="reg_key" title="Show access key" aria-label="Show access key">${j.eye}</button>
                </div>
              </div>`:``}
            <div class="form-group">
              <label>Email Address</label>
              <input type="email" id="email" placeholder="you@example.com" required autocomplete="email"/>
            </div>
            <div class="form-group">
              <label>Password</label>
              <div class="password-field">
                <input type="password" id="password" placeholder="Password" required autocomplete="${r===`login`?`current-password`:`new-password`}"/>
                <button type="button" class="password-toggle" data-target="password" title="Show password" aria-label="Show password">${j.eye}</button>
              </div>
            </div>
            <button type="submit" class="btn btn-primary btn-wide" id="submit-btn">
              ${r===`login`?`Sign In →`:`Create Account →`}
            </button>
          </form>

          <div style="margin-top:24px;text-align:center;font-size:.88rem;color:var(--text-soft)">
            ${r===`login`?`Don't have an account? <a href="#" id="toggle-mode" style="color:var(--primary);font-weight:700">Sign up</a>`:`Already have an account? <a href="#" id="toggle-mode" style="color:var(--primary);font-weight:700">Sign in</a>`}
          </div>
        </div>
      </div>`,n.querySelector(`.theme-toggle-btn`).addEventListener(`click`,()=>{ee(),i()});let o=document.getElementById(`auth-back-btn`);o&&(o.onclick=t),n.querySelectorAll(`.password-toggle`).forEach(e=>{e.onclick=()=>{let t=document.getElementById(e.dataset.target),n=t.type===`text`;t.type=n?`password`:`text`,e.innerHTML=n?j.eye:j.eyeOff;let r=e.dataset.target===`reg_key`;e.title=n?r?`Show access key`:`Show password`:r?`Hide access key`:`Hide password`,e.setAttribute(`aria-label`,e.title)}}),document.getElementById(`toggle-mode`).onclick=e=>{e.preventDefault(),r=r===`login`?`signup`:`login`,i()},document.getElementById(`auth-form`).onsubmit=async t=>{t.preventDefault();let n=document.getElementById(`submit-btn`),a=document.getElementById(`auth-error`);a.style.display=`none`,n.disabled=!0,n.textContent=`Please wait…`;let o=document.getElementById(`email`).value.trim(),s=document.getElementById(`password`).value,c;if(c=r===`signup`?await p(o,s,document.getElementById(`full_name`).value.trim(),document.getElementById(`reg_key`).value.trim()):await f(o,s),c.error){a.textContent=c.error.message,a.style.display=`block`,n.disabled=!1,n.textContent=r===`login`?`Sign In →`:`Create Account →`;return}if(r===`signup`){let t=await f(o,s);if(t.error)_(`Account created! Please sign in.`,`success`),r=`login`,i();else{let n=t.data.user.role||await d(t.data.user.id);_(`Account created successfully!`,`success`),e(t.data.user,n)}}else{let t=c.data.user.role||await d(c.data.user.id);e(c.data.user,t)}}};i()}var ue=new URL(`/assets/logo-Cuxe_Kd5.png`,``+import.meta.url).href;function de({user:e,role:t,activePage:n,navItems:r,onNav:i,pageContent:a}){let o=document.getElementById(`app`),s=e?.user_metadata?.full_name||e?.email?.split(`@`)[0]||`User`,c=localStorage.getItem(`theme`)||`light`;o.innerHTML=`
    <div class="portal-layout">
      <div class="sidebar-overlay" id="sidebar-overlay"></div>
      <aside class="sidebar" id="sidebar">
        <div class="sidebar-logo">
          <img src="${ue}" alt="Networking Experts" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"/>
          <span class="logo-text" style="display:none">Networking Experts</span>
        </div>
        <nav class="sidebar-nav" id="sidebar-nav"></nav>
        <div class="sidebar-footer">
          <div class="user-info">
            <div class="user-avatar">${S(s)}</div>
            <div class="user-details">
              <div class="user-name">${s}</div>
              <div class="user-role">${t}</div>
            </div>
            <button class="logout-btn" id="logout-btn" title="Sign Out">${j.logout}</button>
          </div>
        </div>
      </aside>

      <div class="main-content">
        <div class="topbar">
          <button class="menu-toggle icon-btn" id="menu-toggle" aria-label="Toggle navigation">${j.menu}</button>
          <div class="topbar-title" id="topbar-title"></div>
          <div id="topbar-actions">
            <button class="icon-btn theme-toggle-btn" title="Toggle Theme">${c===`dark`?j.sun:j.moon}</button>
          </div>
        </div>
        <div class="page-content" id="page-content"></div>
      </div>
    </div>`,M(r,n,i),o.querySelector(`.theme-toggle-btn`).addEventListener(`click`,ee),document.getElementById(`logout-btn`).addEventListener(`click`,async()=>{await m(),location.reload()});let l=document.getElementById(`sidebar`),u=document.getElementById(`sidebar-overlay`),d=document.getElementById(`menu-toggle`),f=()=>{l.classList.remove(`open`),u.classList.remove(`active`)};d.onclick=()=>{l.classList.add(`open`),u.classList.add(`active`)},u.onclick=f,document.querySelectorAll(`.nav-item`).forEach(e=>e.addEventListener(`click`,f)),N(a,r,n)}function M(e,t,n){let r=document.getElementById(`sidebar-nav`);r.innerHTML=e.map(e=>e.type===`section`?`<div class="nav-section">${e.label}</div>`:`<div class="nav-item ${e.id===t?`active`:``}" data-nav="${e.id}">
      <span class="nav-icon">${e.icon}</span>
      <span>${e.label}</span>
    </div>`).join(``),r.querySelectorAll(`[data-nav]`).forEach(e=>{e.addEventListener(`click`,()=>n(e.dataset.nav))})}function N(e,t,n){let r=t.find(e=>e.id===n);document.getElementById(`topbar-title`).textContent=r?.label||``;let i=document.getElementById(`page-content`);i.innerHTML=``,typeof e==`function`?e(i):i.innerHTML=e||``}var P=`modulepreload`,fe=function(e){return`/`+e},pe={},F=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e=document.getElementsByTagName(`link`),i=document.querySelector(`meta[property=csp-nonce]`),a=i?.nonce||i?.getAttribute(`nonce`);function o(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}r=o(t.map(t=>{if(t=fe(t,n),t in pe)return;pe[t]=!0;let r=t.endsWith(`.css`),i=r?`[rel="stylesheet"]`:``;if(n)for(let n=e.length-1;n>=0;n--){let i=e[n];if(i.href===t&&(!r||i.rel===`stylesheet`))return}else if(document.querySelector(`link[href="${t}"]${i}`))return;let o=document.createElement(`link`);if(o.rel=r?`stylesheet`:P,r||(o.as=`script`),o.crossOrigin=``,o.href=t,a&&o.setAttribute(`nonce`,a),document.head.appendChild(o),r)return new Promise((e,n)=>{o.addEventListener(`load`,e),o.addEventListener(`error`,()=>n(Error(`Unable to preload CSS for ${t}`)))})}))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})},I=new URL(`/assets/logo-Cuxe_Kd5.png`,``+import.meta.url).href;function me({desiredAccuracy:e=25,maxWaitMs:t=12e3}={}){return new Promise((n,r)=>{if(!navigator.geolocation)return r(Error(`Geolocation not supported`));let i=null,a=!1,o=navigator.geolocation.watchPosition(t=>{(!i||t.coords.accuracy<i.coords.accuracy)&&(i=t),t.coords.accuracy<=e&&!a&&(a=!0,navigator.geolocation.clearWatch(o),clearTimeout(s),n(i))},e=>{a||(i?(a=!0,navigator.geolocation.clearWatch(o),clearTimeout(s),n(i)):(a=!0,r(e)))},{enableHighAccuracy:!0,timeout:t,maximumAge:0}),s=setTimeout(()=>{a||(a=!0,navigator.geolocation.clearWatch(o),i?n(i):r(Error(`Geolocation timed out`)))},t)})}async function L(e,t){return(await(await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${e}&lon=${t}&zoom=18&addressdetails=1`)).json()).display_name||``}function he(e,t){return`https://www.google.com/maps?q=${encodeURIComponent(`${e},${t}`)}`}function ge(e){return e?.customer_lat!=null&&e?.customer_lng!=null?he(e.customer_lat,e.customer_lng):`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(e?.location||``)}`}function _e(e,t=`Loading...`){if(!e)return()=>{};let n=e.innerHTML;return e.disabled=!0,e.classList.add(`is-loading`),e.innerHTML=`<span class="btn-spinner"></span><span>${t}</span>`,()=>{e.disabled=!1,e.classList.remove(`is-loading`),e.innerHTML=n}}async function R(e,t,n,r,i){let a=_e(e,`Loading`);try{await $e(t,n,r,i)}catch(e){console.error(e),_(`Could not open service manager`,`error`)}finally{a()}}var z={name:`Networking Experts`,tagline:`Service · Installation · Support`,address:`Srinagar, J&K, India`,phone:`+91 8899133144`,email:`support@networkingexperts.in`,gstin:`—`};function B(e){return e===`closed`?`resolved`:e||`open`}function ve(e){let t=B(e);return{pending:`received`,open:`received`,assigned:`assigned`,in_progress:`in progress`,resolved:`resolved`,issue_not_resolved:`issue not resolved`}[t]||t.replace(`_`,` `)}var ye=null;function be(e){return new Promise((t,n)=>{let r=0,i=()=>{let a=e[r++];if(!a)return n(Error(`Could not load PDF library`));let o=document.querySelector(`script[data-pdf-src="${a}"]`);if(o?.dataset.loaded===`true`)return t();let s=o||document.createElement(`script`);s.src=a,s.async=!0,s.dataset.pdfSrc=a,s.onload=()=>{s.dataset.loaded=`true`,t()},s.onerror=()=>{s.remove(),i()},o||document.head.appendChild(s)};i()})}function xe(){return window.html2canvas&&(window.jspdf?.jsPDF||window.jsPDF)?Promise.resolve({html2canvas:window.html2canvas,jsPDF:window.jspdf?.jsPDF||window.jsPDF}):ye||(ye=(async()=>{await be([`https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js`,`https://cdn.jsdelivr.net/npm/html2pdf.js@0.10.1/dist/html2pdf.bundle.min.js`,`https://unpkg.com/html2pdf.js@0.10.1/dist/html2pdf.bundle.min.js`]).catch(()=>{}),window.html2canvas||await be([`https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js`,`https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js`,`https://unpkg.com/html2canvas@1.4.1/dist/html2canvas.min.js`]),window.jspdf?.jsPDF||window.jsPDF||await be([`https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js`,`https://cdn.jsdelivr.net/npm/jspdf@2.5.1/dist/jspdf.umd.min.js`,`https://unpkg.com/jspdf@2.5.1/dist/jspdf.umd.min.js`]);let e=window.html2canvas,t=window.jspdf?.jsPDF||window.jsPDF;if(!e||!t)throw Error(`PDF renderer did not load correctly`);return{html2canvas:e,jsPDF:t}})().catch(e=>{throw ye=null,e}),ye)}function Se(e){let t=e=>`₹`+Math.round(Number(e)||0).toString().replace(/\B(?=(\d{3})+(?!\d))/g,`,`),n=e=>String(e??``).replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e]),r=new Date,i=`${r.getDate().toString().padStart(2,`0`)}/${(r.getMonth()+1).toString().padStart(2,`0`)}/${r.getFullYear()}`,a=`NX-${(e.customer?.ticket_no||Date.now()).toString().slice(-8)}`,o=Array.isArray(e.services)?e.services:[],s=o.map((e,r)=>`
    <tr style="display:table-row !important;">
      <td style="display:table-cell !important; padding:10px; border-bottom:1px solid #eee; color:#9CA3AF; width:30px;">${r+1}</td>
      <td style="display:table-cell !important; padding:10px; border-bottom:1px solid #eee; color:#1F2937;">${n(e.name)}</td>
      <td style="display:table-cell !important; padding:10px; border-bottom:1px solid #eee; color:#0F172A; text-align:right; font-weight:700;">${t(e.cost)}</td>
    </tr>`).join(``)||`<tr style="display:table-row !important;"><td colspan="3" style="display:table-cell !important; text-align:center;color:#9CA3AF;padding:20px;">No itemised services</td></tr>`,c=Number(e.extra)>0?`
    <tr style="display:table-row !important;">
      <td style="display:table-cell !important; padding:10px; border-bottom:1px solid #eee; color:#9CA3AF;">${o.length+1}</td>
      <td style="display:table-cell !important; padding:10px; border-bottom:1px solid #eee; color:#1F2937;">Additional charges${e.extraReason?` <small style="color:#6B7280">(${n(e.extraReason)})</small>`:``}</td>
      <td style="display:table-cell !important; padding:10px; border-bottom:1px solid #eee; color:#0F172A; text-align:right; font-weight:700;">${t(e.extra)}</td>
    </tr>`:``;return`
  <div class="premium-bill" id="premium-bill-print" style="font-family:Arial, sans-serif !important; background:#ffffff !important; color:#0F172A !important; padding:40px !important; width:794px !important; box-sizing:border-box !important; display:block !important; visibility:visible !important; opacity:1 !important;">
    <div class="pb-header" style="display:flex !important; flex-direction:row !important; justify-content:space-between !important; align-items:center !important; border-bottom:1px dashed #eee !important; padding-bottom:20px !important; margin-bottom:20px !important;">
      <div class="pb-brand" style="display:flex !important; align-items:center !important; gap:12px !important;">
        <img src="${I}" alt="${z.name}" style="width:50px; height:50px; object-fit:contain;" onerror="this.style.display='none'"/>
        <div>
          <div style="font-size:20px; font-weight:800; color:#064E3B;">${z.name}</div>
          <div style="font-size:11px; color:#6B7280; text-transform:uppercase; letter-spacing:1px;">${z.tagline}</div>
        </div>
      </div>
      <div class="pb-meta" style="text-align:right !important;">
        <div style="display:inline-block; background:#10B981; color:#fff; padding:4px 12px; border-radius:20px; font-size:10px; font-weight:800; margin-bottom:8px;">TAX INVOICE</div>
        <div style="font-size:12px; color:#4B5563;">Bill # <b style="color:#0F172A;">${n(a)}</b></div>
        <div style="font-size:12px; color:#4B5563;">Date: <b style="color:#0F172A;">${i}</b></div>
      </div>
    </div>

    <div class="pb-parties" style="display:grid !important; grid-template-columns:1fr 1fr !important; gap:30px !important; margin-bottom:20px !important; border-bottom:1px dashed #eee !important; padding-bottom:20px !important;">
      <div>
        <div style="font-size:10px; font-weight:800; color:#10B981; text-transform:uppercase; margin-bottom:6px;">Billed To</div>
        <div style="font-size:16px; font-weight:800; color:#0F172A;">${n(e.customer?.name||`—`)}</div>
        <div style="font-size:13px; color:#4B5563;">${n(e.customer?.phone||``)}</div>
        ${e.customer?.company?`<div style="font-size:13px; color:#4B5563;">${n(e.customer.company)}</div>`:``}
        <div style="font-size:13px; color:#6B7280; font-style:italic;">${n(e.customer?.location||``)}</div>
      </div>
      <div>
        <div style="font-size:10px; font-weight:800; color:#10B981; text-transform:uppercase; margin-bottom:6px;">Service Details</div>
        <div style="font-size:13px; color:#4B5563;"><b>Ticket:</b> ${n(e.customer?.ticket_no||`—`)}</div>
        <div style="font-size:13px; color:#4B5563;"><b>Service:</b> ${n(e.customer?.service_item||`—`)}</div>
        ${e.customer?.device_type?`<div style="font-size:13px; color:#4B5563;"><b>Device:</b> ${n(e.customer.device_type)}</div>`:``}
        ${e.technician?`<div style="font-size:13px; color:#4B5563;"><b>Technician:</b> ${n(e.technician)}</div>`:``}
      </div>
    </div>

    <table style="width:100% !important; border-collapse:collapse !important; margin-bottom:20px !important; display:table !important;">
      <thead>
        <tr style="background:#f9fafb; border-bottom:2px solid #10B981; display:table-row !important;">
          <th style="display:table-cell !important; padding:12px; text-align:left; font-size:11px; color:#064E3B; text-transform:uppercase; width:30px;">#</th>
          <th style="display:table-cell !important; padding:12px; text-align:left; font-size:11px; color:#064E3B; text-transform:uppercase;">Description</th>
          <th style="display:table-cell !important; padding:12px; text-align:right; font-size:11px; color:#064E3B; text-transform:uppercase;">Amount</th>
        </tr>
      </thead>
      <tbody style="display:table-row-group !important;">${s}${c}</tbody>
    </table>

    <div style="margin-left:auto; width:300px; background:#f9fafb; padding:15px; border-radius:12px; display:block !important;">
      <div style="display:inline-block; background:#10B981; color:#fff; padding:3px 10px; border-radius:15px; font-size:9px; font-weight:800; margin-bottom:12px;">AMOUNT BREAKDOWN</div>
      <table style="width:100% !important; border-collapse:collapse !important; font-size:13px !important; color:#374151 !important; display:table !important;">
        <tr style="display:table-row !important;"><td style="display:table-cell !important; padding:4px 0;">Services subtotal</td><td style="display:table-cell !important; text-align:right; font-weight:700; color:#0F172A;">${t(e.servicesSubtotal)}</td></tr>
        ${Number(e.extra)>0?`<tr style="display:table-row !important;"><td style="display:table-cell !important; padding:4px 0;">Extra charges</td><td style="display:table-cell !important; text-align:right; font-weight:700; color:#0F172A;">${t(e.extra)}</td></tr>`:``}
        <tr style="display:table-row !important;"><td style="display:table-cell !important; padding:4px 0;">Platform fee</td><td style="display:table-cell !important; text-align:right; font-weight:700; color:#0F172A;">${t(e.platform)}</td></tr>
        <tr style="display:table-row !important;"><td style="display:table-cell !important; padding:4px 0;">Transport</td><td style="display:table-cell !important; text-align:right; font-weight:700; color:#0F172A;">${t(e.transport)}</td></tr>
        ${Number(e.discount)>0?`<tr style="display:table-row !important;"><td style="display:table-cell !important; padding:4px 0; color:#059669;">${n(e.discountLabel||`Discount`)}</td><td style="display:table-cell !important; text-align:right; font-weight:700; color:#059669;">−${t(e.discount)}</td></tr>`:``}
        <tr style="display:table-row !important; border-top:1px solid #eee !important;"><td style="display:table-cell !important; padding:6px 0; font-weight:700;">Taxable</td><td style="display:table-cell !important; text-align:right; font-weight:700; color:#0F172A;">${t(e.taxable)}</td></tr>
        <tr style="display:table-row !important;"><td style="display:table-cell !important; padding:4px 0;">GST (18%)</td><td style="display:table-cell !important; text-align:right; font-weight:700; color:#0F172A;">${t(e.gst)}</td></tr>
        <tr style="display:table-row !important; border-top:2px solid #10B981 !important; font-size:16px !important;"><td style="display:table-cell !important; padding:10px 0; font-weight:800; color:#064E3B;">Total</td><td style="display:table-cell !important; text-align:right; font-weight:900; color:#10B981;">${t(e.total)}</td></tr>
      </table>
    </div>

    ${e.paymentLink?`
      <div style="margin-top:20px; padding:20px; border:1px dashed #10B981; border-radius:12px; text-align:center; background:rgba(16,185,129,0.02);">
        <div style="font-weight:800; font-size:11px; color:#064E3B; text-transform:uppercase; margin-bottom:10px;">💳 Secure Payment</div>
        <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(e.paymentLink)}" style="width:120px; height:120px; margin:0 auto 10px; display:block; border-radius:8px;"/>
        <div style="font-size:11px; color:#2563EB; word-break:break-all;">${n(e.paymentLink)}</div>
      </div>`:``}

    <div style="margin-top:30px; padding-top:20px; border-top:1px dashed #eee; text-align:center;">
      <div style="font-weight:800; color:#10B981; font-size:14px;">Thank you for your business!</div>
      <div style="font-size:11px; color:#6B7280; margin-top:5px;">
        ${z.address} · ${z.phone} · ${z.email}
      </div>
      <div style="font-size:10px; color:#9CA3AF; margin-top:5px;">GSTIN: ${z.gstin} · Computer Generated Invoice</div>
    </div>
  </div>`}async function Ce(e,t){let n=document.createElement(`div`);n.setAttribute(`aria-hidden`,`true`),n.classList.add(`pdf-rendering`),n.style.width=`794px`,n.style.cssText=[`position:fixed`,`left:-9999px`,`top:0`,`width:794px`,`min-height:1123px`,`background:#ffffff`,`pointer-events:none`,`z-index:-1`].join(`;`);let r=document.createElement(`div`);r.style.cssText=`width:794px;min-height:1123px;background:#ffffff;padding:0;box-sizing:border-box;`,r.innerHTML=e,n.appendChild(r),document.body.appendChild(n),await new Promise(e=>requestAnimationFrame(()=>requestAnimationFrame(e))),await new Promise(e=>setTimeout(e,50));let i=[...r.querySelectorAll(`img`)];await Promise.all(i.map(e=>e.complete&&e.naturalWidth>0?Promise.resolve():new Promise(t=>{e.addEventListener(`load`,t,{once:!0}),e.addEventListener(`error`,t,{once:!0}),setTimeout(t,2500)})));try{let{html2canvas:e,jsPDF:n}=await xe(),i=r.firstElementChild;i.style.display=`block`,i.style.overflow=`visible`,i.style.position=`relative`,i.style.width=`794px`,i.style.maxWidth=`794px`,i.style.minHeight=`1123px`;let a=await e(i,{scale:2,useCORS:!0,allowTaint:!1,backgroundColor:`#ffffff`,logging:!1,windowWidth:794,width:794,height:i.scrollHeight,scrollX:0,scrollY:0}),o=new n({unit:`px`,format:[794,1123],orientation:`portrait`,hotfixes:[`px_scaling`]}),s=o.internal.pageSize.getWidth(),c=o.internal.pageSize.getHeight(),l=s,u=a.height*l/a.width,d=a.toDataURL(`image/jpeg`,1),f=u,p=0;for(o.addImage(d,`JPEG`,0,p,l,u,void 0,`FAST`),f-=c;f>0;)p-=c,o.addPage([794,1123],`portrait`),o.addImage(d,`JPEG`,0,p,l,u,void 0,`FAST`),f-=c;let m=o.output(`blob`);return{blob:m,file:new File([m],t,{type:`application/pdf`})}}finally{n.remove()}}function we(e,t){let n=window.open(``,`_blank`,`width=900,height=1200`);if(!n)throw Error(`Allow popups to print or save this bill as PDF`);n.opener=null;let r=String(t||`invoice.pdf`).replace(/[<>&"]/g,``);n.document.open(),n.document.write(`<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${r}</title>
  <style>
    @page { size: A4; margin: 0; }
    html, body { margin: 0; padding: 0; background: #ffffff; }
    body {
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: flex-start;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }
    .print-shell { width: 794px; min-height: 1123px; background: #ffffff; }
    @media print {
      body { display: block; }
      .print-shell { width: 100%; min-height: auto; }
    }
  </style>
</head>
<body>
  <div class="print-shell">${e}</div>
  <script>
    const finish = () => setTimeout(() => window.print(), 150);
    const images = Array.from(document.images || []);
    if (!images.length) finish();
    else Promise.all(images.map(img => img.complete ? Promise.resolve() : new Promise(resolve => {
      img.onload = resolve;
      img.onerror = resolve;
      setTimeout(resolve, 2500);
    }))).then(finish);
  <\/script>
</body>
</html>`),n.document.close()}function V(e){let t=e.querySelector(`#bill-preview-stage`),n=e.querySelector(`#bill-preview-container`),r=e.querySelector(`.modal-body`);if(!t||!n||!r)return;n.style.transform=`scale(1)`,t.style.height=`auto`;let i=Math.max(260,r.clientWidth-16),a=Math.min(1,i/794);n.style.transform=`scale(${a})`,t.style.height=`${n.offsetHeight*a}px`}function Te(e){return new Promise((t,n)=>{let r=new FileReader;r.onload=()=>{let e=String(r.result||``);t(e.includes(`,`)?e.slice(e.indexOf(`,`)+1):e)},r.onerror=()=>n(r.error||Error(`Could not read PDF blob`)),r.readAsDataURL(e)})}async function Ee(e,t,n){let r=await Te(e),i=localStorage.getItem(`auth_token`),a=await fetch(`/api/bills/upload`,{method:`POST`,headers:{"Content-Type":`application/json`,Authorization:`Bearer ${i}`},body:JSON.stringify({dataBase64:r,filename:t,inquiry_id:n||null})});if(!a.ok){let e=await a.json().catch(()=>({}));throw Error(e.error||`Upload failed`)}let{url:o}=await a.json();return o}async function H(e,{inquiryId:t=null,existingUrl:n=null}={}){if(n)return n;let r=Se(e),i=`Invoice-${e.customer?.ticket_no||`service`}.pdf`,{blob:a}=await Ce(r,i);return Ee(a,i,t)}function U(e,t){let n=URL.createObjectURL(e),r=document.createElement(`a`);r.href=n,r.download=t,document.body.appendChild(r),r.click(),r.remove(),setTimeout(()=>URL.revokeObjectURL(n),1e3)}function De(e,t){let n=[`Hi ${e.customer?.name||``}! 👋`,`Your service invoice from *${z.name}* is ready.`,`Ticket: *${e.customer?.ticket_no||`—`}* · Total: *${(e=>`₹${Math.round(Number(e)||0).toLocaleString(`en-IN`)}`)(e.total)}*`];return t&&n.push(``,`📄 View / download bill PDF:`,t),e.paymentLink&&n.push(``,`💳 Pay here: ${e.paymentLink}`),n.push(``,`— ${z.name}`),n.join(`
`)}function Oe(e,t={}){let{onSent:n,allowShare:r=!0,title:i=`📄 Service Invoice Preview`,inquiryId:a=null}=t,o=Se(e),s=document.createElement(`div`);s.className=`modal-overlay premium-bill-modal`,s.innerHTML=`
    <div class="modal-card modal-large">
      <div class="modal-header">
        <h3>${i}</h3>
        <button class="btn-icon" id="pb-close">${j.close}</button>
      </div>
      <div class="modal-body" style="background:#F8FAFC; padding:20px; overflow-x:auto;">
        <div id="bill-preview-stage" style="width:100%; display:flex; justify-content:center;">
          <div id="bill-preview-container" style="background:white; box-shadow:0 10px 25px -5px rgba(0,0,0,0.1); border-radius:8px; width:794px; margin:0 auto; transform-origin: top center;">
            ${o}
          </div>
        </div>
      </div>
      <div class="modal-footer" style="gap:12px;">
        <button class="btn btn-secondary" id="pb-cancel">Close</button>
        <button class="btn btn-secondary" id="pb-print">Print / Save PDF</button>
        <button class="btn btn-secondary" id="pb-download">📥 Download PDF</button>
        ${r?`<button class="btn btn-primary" id="pb-whatsapp"><span>📱 Send via WhatsApp</span></button>`:``}
      </div>
    </div>`,document.body.appendChild(s);let c=()=>s.remove();s.querySelector(`#pb-close`).onclick=c,s.querySelector(`#pb-cancel`).onclick=c,requestAnimationFrame(()=>V(s));let l=()=>V(s);window.addEventListener(`resize`,l);let u=()=>{window.removeEventListener(`resize`,l),c()};s.querySelector(`#pb-close`).onclick=u,s.querySelector(`#pb-cancel`).onclick=u;let d=`Invoice-${e.customer?.ticket_no||`service`}.pdf`;s.querySelector(`#pb-print`).onclick=()=>{try{we(o,d)}catch(e){console.error(e),_(e.message||`Could not open print window`,`error`)}},s.querySelector(`#pb-download`).onclick=async()=>{let e=s.querySelector(`#pb-download`);e.disabled=!0,e.textContent=`… preparing PDF`;try{let{blob:e}=await Ce(o,d);U(e,d),_(`Bill PDF downloaded`,`success`)}catch(e){console.error(e),_(e.message||`Could not generate PDF`,`error`)}finally{e.disabled=!1,e.textContent=`📥 Download PDF`}},r&&(s.querySelector(`#pb-whatsapp`).onclick=async()=>{let t=s.querySelector(`#pb-whatsapp`);t.disabled=!0;let r=t.innerHTML,i=(e.customer?.phone||``).replace(/\D/g,``);if(!i){_(`Client phone number is missing on this inquiry`,`error`),t.disabled=!1,t.innerHTML=r;return}try{t.innerHTML=`<span>… preparing PDF</span>`;let{blob:r}=await Ce(o,d);t.innerHTML=`<span>… uploading bill</span>`;let s=await Ee(r,d,a),c=De(e,s),l=`https://wa.me/${i}?text=${encodeURIComponent(c)}`;if(window.open(l,`_blank`),_(`WhatsApp opened with PDF link — send the message to the client.`,`success`),typeof n==`function`)try{await n(s)}catch{}}catch(e){console.error(e),_(e.message||`Could not send bill`,`error`)}finally{t.disabled=!1,t.innerHTML=r}})}function ke(e=new Date){return e.toLocaleDateString(`en-CA`).slice(0,7)}function W(e){if(!e)return``;if(e instanceof Date)return Number.isNaN(e.getTime())?``:e.toLocaleDateString(`en-CA`);let t=String(e).trim(),n=/^(\d{4}-\d{2}-\d{2})/.exec(t);if(n)return n[1];let r=new Date(t.replace(` `,`T`));return Number.isNaN(r.getTime())?``:r.toLocaleDateString(`en-CA`)}function Ae(e){return W(e?.date||e?.clock_in)}function je(e,t){if(!e||!t)return 0;let n=W(e),r=W(t);if(!n||!r)return 0;let i=new Date(`${n}T00:00:00`),a=new Date(`${r}T00:00:00`);return Number.isNaN(i.getTime())||Number.isNaN(a.getTime())||a<i?0:Math.floor((a-i)/864e5)+1}function Me(e,t){if(!e||!t)return null;let n=new Date(t)-new Date(e);return!Number.isFinite(n)||n<0?null:`${Math.floor(n/36e5)}h ${Math.floor(n%36e5/6e4)}m`}var Ne=`18:00`,Pe=4;function Fe(e=Ne){let t=/^(\d{1,2}):(\d{2})$/.exec(String(e||``).trim());if(!t)return{hour:18,minute:0,label:`18:00`};let n=Math.min(23,Math.max(0,Number(t[1]))),r=Math.min(59,Math.max(0,Number(t[2])));return{hour:n,minute:r,label:`${String(n).padStart(2,`0`)}:${String(r).padStart(2,`0`)}`}}async function Ie(){let e=window.location.hostname!==`localhost`&&window.location.hostname!==`127.0.0.1`?`/api`:`http://localhost:5000/api`;try{let t=await fetch(`${e}/settings/attendance`,{headers:{Authorization:`Bearer ${localStorage.getItem(`auth_token`)||``}`}});t.ok&&(Ne=Fe((await t.json()).autoClockOutTime).label)}catch(e){console.warn(`[employee] could not load clock-out settings`,e)}return Fe()}function Le(e=new Date){let{hour:t,minute:n}=Fe(),r=new Date(e);return r.setHours(t,n,0,0),e>=r}function Re(e,t=new Date().toLocaleDateString(`en-CA`)){return!e?.clock_in||e?.clock_out?!1:Ae(e)!==t||Le()}function ze(e){return`\u20B9${Math.round(Number(e)||0).toLocaleString(`en-IN`)}`}function G(e,t){let n=e?.created_at||e?.inquiries?.[0]?.created_at||0,r=t?.created_at||t?.inquiries?.[0]?.created_at||0;return new Date(r)-new Date(n)}function Be(e,t=new Date){if(!e)return`-`;let n=new Date(e),r=new Date(t);if(Number.isNaN(n.getTime())||Number.isNaN(r.getTime()))return`-`;let i=Math.max(0,r.getTime()-n.getTime()),a=Math.floor(i/864e5),o=Math.floor(i%864e5/36e5),s=Math.floor(i%36e5/6e4);return a?`${a}d ${o}h`:o?`${o}h ${s}m`:`${s}m`}function K(e){return String(e??``).replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e])}function q(e){return K(e)}function Ve(e){let t=Math.round(Number(e)||0);return Array.from({length:5},(e,n)=>`<span style="color:${n<t?`var(--warning)`:`var(--border)`};display:inline-flex;width:14px;height:14px">${n<t?j.star:j.starOutline}</span>`).join(``)}async function He(){let{data:{user:e}}=await u.auth.getUser();if(!e)return{user:null};let[{data:t},{data:n},{data:r},{data:i}]=await Promise.all([u.from(`profiles`).select(`*`).eq(`id`,e.id).maybeSingle(),u.from(`attendance`).select(`*`).eq(`user_id`,e.id).order(`date`,{ascending:!1}),u.from(`leave_requests`).select(`*`).eq(`employee_id`,e.id).order(`created_at`,{ascending:!1}),u.from(`eod_reports`).select(`*`).eq(`employee_id`,e.id).order(`date`,{ascending:!1})]);return{user:e,profile:t||e,attendance:n||[],leaves:r||[],reports:i||[]}}async function Ue(e){let{read:t,utils:n}=await F(async()=>{let{read:e,utils:t}=await import(`https://cdn.sheetjs.com/xlsx-0.18.5/package/xlsx.mjs`);return{read:e,utils:t}},[]),r=t(await e.arrayBuffer()),i=r.Sheets[r.SheetNames[0]];if(!i)return[];let a=n.sheet_to_json(i,{header:1});return a.length>1?a.slice(1):[]}async function We(e){let t=0,n=0,r=[],i=[];for(let t of e){let[e,r,a,o]=Array.isArray(t)?t:[t.category,t.sub_category,t.sub_sub_category,t.cost];if(!e||!a){n++;continue}let s=parseFloat(o)||0;if(s<0){n++;continue}i.push({id:crypto.randomUUID?.()||`svc-${Date.now()}-${Math.random()}`,category:String(e).trim(),sub_category:r?String(r).trim():null,sub_sub_category:String(a).trim(),name:String(a).trim(),cost:s})}for(let e=0;e<i.length;e+=10){let a=i.slice(e,e+10),o=0;for(;o<3;){let{error:e}=await u.from(`service_pricing`).insert(a);if(e?.status===429){o++,await new Promise(e=>setTimeout(e,1e3*2**o));continue}e?(r.push(e.message),n+=a.length):t+=a.length;break}o===3&&(r.push(`Rate limited - batch skipped`),n+=a.length)}return{inserted:t,skipped:n,errors:r}}function Ge(){let e=[[`Main Category`,`Sub Category`,`Sub-Sub Category`,`Price`],[`Network Installation`,`Setup`,`Basic Setup`,`500`],[`Network Installation`,`Setup`,`Advanced Setup`,`1000`],[`Repair`,`Hardware`,`Cable Replacement`,`300`]].map(e=>e.map(e=>`"${e}"`).join(`,`)).join(`
`),t=new Blob([e],{type:`text/csv`}),n=URL.createObjectURL(t),r=document.createElement(`a`);r.href=n,r.download=`service-pricing-template.csv`,r.click(),URL.revokeObjectURL(n)}async function J(e){A(e);let{data:{user:t}}=await u.auth.getUser();if(!t){e.innerHTML=`<p>Please sign in.</p>`;return}let n=new Date().toLocaleDateString(`en-CA`),r=await Ie(),i,a=[],o,s,c=[],l=[],d=[];try{let e=await Promise.all([u.from(`attendance`).select(`*`).eq(`user_id`,t.id).eq(`date`,n).maybeSingle(),u.from(`tickets`).select(`*, inquiries(*)`).eq(`assigned_to`,t.id).order(`created_at`,{ascending:!1}),u.from(`eod_reports`).select(`*`).eq(`employee_id`,t.id).eq(`date`,n).maybeSingle(),u.from(`inquiries`).select(`*`).eq(`assigned_employee_id`,t.id).in(`assignment_status`,[`pending`,`accepted`]).order(`created_at`,{ascending:!1}),u.from(`attendance`).select(`*`).eq(`user_id`,t.id).order(`date`,{ascending:!1}),u.from(`notices`).select(`*`).eq(`active`,1).order(`created_at`,{ascending:!1})]);i=e[0].data,o=e[1].data,s=e[2].data,a=e[4].data||[],d=(e[5].data||[]).filter(e=>!e.expires_at||new Date(e.expires_at)>=new Date).slice(0,4);let r=e[3].data||[],f=new Set((o||[]).map(e=>e.inquiries?.[0]?.id).filter(Boolean));c=r.filter(e=>e.assignment_status===`pending`).sort(G),l=r.filter(e=>e.assignment_status===`accepted`&&!f.has(e.id)&&![`resolved`,`closed`].includes(e.status)).sort(G).map(e=>({...e,_company:e.company_name||null}))}catch(t){e.innerHTML=`<div class="card"><div class="card-body" style="text-align:center;padding:40px;"><h3 style="color:var(--danger);display:inline-flex;align-items:center;gap:8px;">${j.alert}<span>Error</span></h3><p>${t.message}</p></div></div>`;return}let f=o||[],p=f.filter(e=>{let t=B(e.status);if(t===`resolved`)return!1;let n=e.inquiries?.[0];return n?n.assignment_status===`accepted`&&B(n.status)!==`resolved`:t===`assigned`||t===`in_progress`||t===`open`}),m=!!i?.clock_in,h=!!i?.clock_out,g=Le(),v=m&&!h&&!!s,y=a.filter(e=>Re(e,n)),S=y.length>=Pe,C=[...p.filter(e=>W(e.inquiries?.[0]?.created_at||e.created_at)===n),...l.filter(e=>W(e.created_at)===n)].sort(G).slice(0,5);e.innerHTML=`
    <div class="page-header" style="display:flex; justify-content:space-between; align-items:center; gap:16px; flex-wrap:wrap;">
      <div>
        <h1 style="display:flex; align-items:center; gap:12px;">
          <span style="width:32px; height:32px; display:flex; color:var(--primary);">${j.staff}</span>
          <span>Employee Portal</span>
        </h1>
        <p>Today is ${new Date().toLocaleDateString(`en-US`,{weekday:`long`,year:`numeric`,month:`long`,day:`numeric`})}</p>
      </div>
    </div>

    ${y.length?`
      <div class="card" style="margin-bottom:18px;border:1px solid ${S?`var(--danger)`:`rgba(245,158,11,0.45)`};">
        <div class="card-body" style="display:flex;gap:14px;align-items:flex-start;">
          <span style="width:24px;height:24px;color:${S?`var(--danger)`:`var(--warning)`};display:flex;">${j.alert}</span>
          <div>
            <div style="font-weight:800;color:${S?`var(--danger)`:`var(--warning)`};">${S?`Clock-in restricted`:`Clock-out warning`}</div>
            <div style="color:var(--text-soft);font-size:0.88rem;line-height:1.45;margin-top:4px;">
              You have ${y.length} missed clock-out record${y.length===1?``:`s`}. ${S?`Please contact admin to fix attendance before starting a new shift.`:`Please avoid repeated missed clock-outs.`}
            </div>
          </div>
        </div>
      </div>
    `:``}

    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-value stat-value-inline" style="color:${m?`var(--success)`:`var(--text-dim)`};">
          <span style="width:24px; height:24px; display:flex;">${m?j.check:j.pause}</span>
          <span>${m?`Clocked In`:`Not Started`}</span>
        </div>
        <div class="stat-label">${m?`Since `+x(i.clock_in):g?`Closed after ${r.label}`:`Tap Clock In to start`}</div>
      </div>
      <div class="stat-card">
        <div class="stat-value stat-value-inline" style="color:var(--warning)">
          <span style="width:24px; height:24px; display:flex;">${j.wrench}</span>
          <span>${p.length}</span>
        </div>
        <div class="stat-label">Active Tasks</div>
      </div>
      <div class="stat-card">
        <div class="stat-value stat-value-inline" style="color:var(--primary)">
          <span style="width:24px; height:24px; display:flex;">${j.ticket}</span>
          <span>${l.length}</span>
        </div>
        <div class="stat-label">Accepted Requests</div>
      </div>
      <div class="stat-card">
        <div class="stat-value stat-value-inline" style="color:var(--success)">
          <span style="width:24px; height:24px; display:flex;">${j.check}</span>
          <span>${f.filter(e=>B(e.status)===`resolved`).length}</span>
        </div>
        <div class="stat-label">Completed</div>
      </div>
    </div>

    <div class="employee-dash-band">
      <section class="notice-board">
        <div class="notice-board-head">
          <span class="notice-board-icon">${j.clipboard}</span>
          <div>
            <h2>Notice Board</h2>
            <p>Latest updates from admin</p>
          </div>
        </div>
        <div class="notice-list">
          ${d.length===0?`
            <div class="notice-empty">${j.check}<span>No active notices right now.</span></div>
          `:d.map(e=>`
            <article class="notice-item notice-${q(e.priority||`normal`)}">
              <div class="notice-pin">${e.priority===`urgent`?j.alert:e.priority===`high`?j.star:j.clipboard}</div>
              <div>
                <div class="notice-title">${K(e.title)}</div>
                <p>${K(e.body)}</p>
                <small>${b(e.created_at)}${e.expires_at?` · Until ${b(e.expires_at)}`:``}</small>
              </div>
            </article>
          `).join(``)}
        </div>
      </section>

      <section class="employee-today-panel">
        <div class="employee-panel-head">
          <span>${j.wrench}</span>
          <div>
            <h2>Today's Tasks</h2>
            <p>${C.length} assigned today</p>
          </div>
        </div>
        <div class="employee-mini-list">
          ${C.length===0?`<div class="employee-mini-empty">${j.check}<span>No new task assigned today.</span></div>`:C.map(e=>{let t=e.inquiries?.[0]||e,n=e.inquiries?e.id:t.ticket_id||``;return`
              <div class="employee-mini-row">
                <div>
                  <b>${K(t.full_name||e.title||`Service task`)}</b>
                  <span>${K(t.service_item||e.description||`Service request`)}</span>
                  <small>${K(t.ticket_no||`No ticket`)} · ${b(t.created_at||e.created_at)}</small>
                </div>
                <button class="btn btn-secondary btn-sm task-btn" data-id="${q(n)}" data-inq-id="${q(t.id||``)}" data-status="${q(t.status||e.status||`assigned`)}">${j.edit}<span>Open</span></button>
              </div>
            `}).join(``)}
        </div>
      </section>
    </div>

    ${c.length?`
      <div class="card" style="margin-bottom:18px;border:1px solid rgba(245,158,11,0.28);">
        <div class="card-header">
          <span class="card-title sr-icon-title">${j.alert}<span>Requests Waiting For Accept</span></span>
        </div>
        <div class="card-body">
          ${c.map(e=>`
            <div class="employee-request-row">
              <div>
                <div class="employee-request-title">${K(e.full_name||`Client`)}</div>
                <div class="employee-request-sub">${K(e.service_item||`Service request`)}</div>
                <small>${K(e.ticket_no||`No ticket`)} · ${b(e.created_at)}</small>
              </div>
              <div class="employee-request-actions">
                <button class="btn btn-primary btn-sm accept-btn" data-id="${q(e.id)}" data-ticket-id="${q(e.ticket_id||``)}">${j.check}<span>Accept</span></button>
                <button class="btn btn-secondary btn-sm decline-btn" data-id="${q(e.id)}">${j.close}<span>Decline</span></button>
              </div>
            </div>
          `).join(``)}
        </div>
      </div>
    `:``}

    ${l.length?`
      <div class="card" style="margin-bottom:18px;">
        <div class="card-header">
          <span class="card-title sr-icon-title">${j.ticket}<span>Accepted Requests</span></span>
        </div>
        <div class="card-body">
          ${l.map(e=>`
            <div class="emp-job-card" data-status="${B(e.status)}" style="display:flex;justify-content:space-between;align-items:center;gap:14px;padding:14px 0;border-bottom:1px solid var(--border);">
              <div style="min-width:0;">
                <div style="font-weight:800;color:var(--primary);">${e.full_name||`Client`}</div>
                <div style="font-size:0.86rem;color:var(--text-soft);margin-top:3px;">${e.service_item||`Service request`}</div>
                <div style="font-size:0.78rem;color:var(--text-dim);margin-top:3px;">${e.ticket_no||`No ticket`} &bull; ${b(e.created_at)}</div>
              </div>
              <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;justify-content:flex-end;">
                <span class="badge badge-${B(e.status)}">${ve(e.status)}</span>
                <button class="btn btn-secondary btn-sm task-btn" data-id="${e.ticket_id||``}" data-inq-id="${e.id}" data-status="${e.status}">
                  ${j.edit}<span>Update</span>
                </button>
                <button class="btn btn-primary btn-sm" onclick="window.open('${q(ge(e))}')">
                  ${j.pin}<span>Map</span>
                </button>
              </div>
            </div>
          `).join(``)}
        </div>
      </div>
    `:``}

    <div class="employee-work-grid">
      <!-- Attendance Card -->
      <div class="card">
        <div class="card-header"><span class="card-title sr-icon-title">${j.clock}<span>Attendance</span></span></div>
        <div class="card-body attendance-card-body">
          <div id="live-clock" class="live-clock">--:--:--</div>
          <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;">
            <button class="btn btn-primary" id="btn-clock-in" ${m||S||g?`disabled`:``}>
              ${j.play}<span>Clock In</span>
            </button>
            <button class="btn btn-secondary" id="btn-clock-out" ${v?``:`disabled`} title="${!s&&m&&!h?`Submit EOD report before clocking out`:``}">
              ${j.pause}<span>Clock Out</span>
            </button>
          </div>
          ${m&&!h&&!s?`<p class="attendance-lock-note">${j.clipboard}<span>Submit today's EOD report to enable Clock Out.</span></p>`:``}
          ${g&&!m?`<p class="attendance-lock-note">${j.clock}<span>Clock-in is closed after ${r.label}. Please contact admin.</span></p>`:``}
          ${i?.location?`<p class="attendance-location">${j.pin}<span>${i.location}</span></p>`:``}
          ${h?`<div style="margin-top:20px;padding:14px;border-radius:14px;box-shadow:var(--neu-in);background:var(--bg);font-size:.88rem;color:var(--success);font-weight:600;display:inline-flex;align-items:center;gap:8px;">
            ${j.check}<span>Session: ${x(i.clock_in)} → ${x(i.clock_out)}</span>
          </div>`:``}
        </div>
      </div>

      <!-- EOD Report Card -->
      <div class="card">
        <div class="card-header"><span class="card-title sr-icon-title">${j.clipboard}<span>End of Day Summary</span></span></div>
        <div class="card-body">
          ${s?`
            <div class="eod-done">
              <div class="eod-done-ring">${j.check}</div>
              <h3 class="eod-done-title">All caught up!</h3>
              <p class="eod-done-sub">Your EOD report has been submitted.</p>
              <div class="eod-done-time">Submitted at ${x(s.created_at)}</div>
            </div>
          `:`
            <div class="form-group">
              <label class="sr-icon-label">${j.edit}<span>Today's progress</span></label>
              <textarea id="eod-content" rows="6"
                placeholder="What did you achieve today? Break it down briefly…"></textarea>
            </div>
            <button class="btn btn-primary btn-wide" id="btn-submit-eod" style="display:flex; align-items:center; justify-content:center; gap:10px;">
              <span>Submit Daily Report</span>
              <span style="width:18px; height:18px; display:flex;">${j.arrowRight}</span>
            </button>
            <p class="eod-fineprint">Reports are visible to your manager immediately.</p>
          `}
        </div>
      </div>

      <!-- Leave Request Card -->
      <div class="card" style="display:none">
        <div class="card-header"><span class="card-title sr-icon-title">${j.clock}<span>Request Leave</span></span></div>
        <div class="card-body">
          <p style="font-size:0.85rem; color:var(--text-dim); margin-bottom:16px;">Need time off? Submit your request here for approval.</p>
          <button class="btn btn-secondary btn-wide" id="btn-open-leave-modal">
            ${j.plus}<span>Submit Leave Request</span>
          </button>
        </div>
      </div>
    </div>
  `;let w=e.querySelector(`#live-clock`),ee=()=>{w&&(w.textContent=new Date().toLocaleTimeString())};ee(),setInterval(ee,1e3);let T=e.querySelector(`#emp-company-tabs`);T&&T.querySelectorAll(`.sr-filter`).forEach(t=>{t.onclick=()=>{T.querySelectorAll(`.sr-filter`).forEach(e=>e.classList.remove(`active`)),t.classList.add(`active`);let n=t.dataset.company;e.querySelectorAll(`.emp-job-card`).forEach(e=>{e.style.display=n===`all`||e.dataset.company===n?``:`none`})}});let E=(t,n)=>{let r=e.querySelector(t);r&&(r.onclick=n)};E(`#btn-clock-in`,async()=>{if(S){_(`Clock-in is restricted because you have 4 or more missed clock-outs. Contact admin.`,`error`);return}if(Le()){_(`Clock-in is closed after ${Fe().label}. Please contact admin.`,`error`);return}let r=e.querySelector(`#btn-clock-in`);r.disabled=!0,r.textContent=`Getting location…`;let i=`Unknown`,a={lat:null,lng:null,accuracy:null};try{let{latitude:e,longitude:t,accuracy:n}=(await me()).coords;a={lat:e,lng:t,accuracy:n};try{i=await L(e,t)||`${e.toFixed(6)}, ${t.toFixed(6)}`}catch{i=`${e.toFixed(6)}, ${t.toFixed(6)}`}}catch{}let{error:o}=await u.from(`attendance`).insert({user_id:t.id,clock_in:new Date().toISOString(),date:n,location:i,latitude:a.lat,longitude:a.lng,status:`present`});o?(_(o.message,`error`),r.disabled=!1,r.textContent=`✅ Clock In`):(_(`Clocked in!`,`success`),J(e))}),E(`#btn-clock-out`,async()=>{let{error:r}=await u.from(`attendance`).update({clock_out:new Date().toISOString()}).eq(`user_id`,t.id).eq(`date`,n);r?_(r.message,`error`):(_(`Clocked out!`,`success`),J(e))}),e.querySelector(`#btn-submit-eod`)&&E(`#btn-submit-eod`,async()=>{let r=e.querySelector(`#eod-content`).value.trim();if(!r){_(`Please write your report`,`warning`);return}let i=e.querySelector(`#btn-submit-eod`);i.disabled=!0,i.textContent=`Submitting…`;let{error:a}=await u.from(`eod_reports`).insert({employee_id:t.id,content:r,date:n});a?(_(a.message,`error`),i.disabled=!1,i.textContent=`Submit Report →`):(_(`EOD Report submitted!`,`success`),J(e))}),E(`#btn-open-leave-modal`,()=>et(t.id,()=>J(e))),e.querySelectorAll(`.task-btn`).forEach(t=>{t.onclick=()=>R(t,t.dataset.id,t.dataset.inqId,t.dataset.status,()=>J(e))}),e.querySelectorAll(`.accept-btn`).forEach(t=>{t.onclick=async()=>{let n=[u.from(`inquiries`).update({assignment_status:`accepted`,status:`in_progress`}).eq(`id`,t.dataset.id)];t.dataset.ticketId&&n.push(u.from(`tickets`).update({status:`in_progress`}).eq(`id`,t.dataset.ticketId));let r=(await Promise.all(n)).find(e=>e.error)?.error;r?_(r.message,`error`):(_(`Task accepted!`,`success`),J(e))}}),e.querySelectorAll(`.decline-btn`).forEach(t=>{t.onclick=()=>{let n=prompt(`Please provide a reason for declining:`);if(n!==null){if(!n.trim()){_(`Reason is required to decline`,`warning`);return}(async()=>{let{error:r}=await u.from(`inquiries`).update({assignment_status:`declined`,decline_reason:n.trim(),status:`open`}).eq(`id`,t.dataset.id);r?_(r.message,`error`):(_(`Task declined`,`info`),J(e))})()}}});let D=u.channel(`employee-jobs-${t.id}`).on(`postgres_changes`,{event:`*`,schema:`public`,table:`inquiries`,filter:`assigned_employee_id=eq.${t.id}`},t=>{let n=t.new;t.eventType===`INSERT`||t.eventType===`UPDATE`&&n?.assignment_status===`pending`?k({title:`🔔 New Job Assigned`,body:`${n?.full_name||`A client`} — ${n?.service_item||`new service`}`,type:`alert`,tag:`assign-${n?.id||``}`}):t.eventType===`UPDATE`&&n?.payment_status===`paid`&&k({title:`💰 Payment Received`,body:`${n?.full_name||`Client`} paid for ticket ${n?.ticket_no||``}`,type:`payment`,tag:`pay-${n?.id||``}`}),J(e)}).subscribe(),O=setInterval(()=>{document.body.contains(e)||(u.removeChannel(D),clearInterval(O))},5e3)}async function Ke(e){A(e);let{user:t,attendance:n}=await He();if(!t){e.innerHTML=`<p>Please sign in.</p>`;return}let r=ke(),i=n.filter(e=>String(e.date||``).startsWith(r)),a=new Set(i.map(e=>e.date)).size,o=i.filter(e=>e.clock_in&&e.clock_out),s=n.filter(e=>Re(e)),c=s.length>=Pe,l=o.reduce((e,t)=>e+Math.max(0,new Date(t.clock_out)-new Date(t.clock_in))/6e4,0),u=`${Math.floor(l/60)}h ${Math.round(l%60)}m`;e.innerHTML=`
    <div class="page-header">
      <h1>Attendance Records</h1>
      <p>Your check-ins, locations, and monthly attendance count</p>
    </div>
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-value">${a}</div><div class="stat-label">Days Present This Month</div></div>
      <div class="stat-card"><div class="stat-value" style="color:var(--success)">${i.filter(e=>e.clock_in&&!e.clock_out&&!Re(e)).length}</div><div class="stat-label">Active Sessions</div></div>
      <div class="stat-card"><div class="stat-value" style="color:${s.length?`var(--danger)`:`var(--success)`}">${s.length}</div><div class="stat-label">${c?`Strict Warning`:`Missed Clock-outs`}</div></div>
      <div class="stat-card"><div class="stat-value" style="font-size:1.7rem;color:var(--warning)">${u}</div><div class="stat-label">Logged Hours This Month</div></div>
    </div>
    <div class="card">
      <div class="table-wrap">
        <table>
          <thead><tr><th>Date</th><th>Clock In</th><th>Clock Out</th><th>Hours</th><th>Location</th></tr></thead>
          <tbody>
            ${n.length===0?`<tr><td colspan="5" style="text-align:center;padding:32px;color:var(--text-dim)">No attendance records yet</td></tr>`:n.map(e=>`<tr>
                <td>${y(e.date)}</td>
                <td><span class="badge badge-open">${x(e.clock_in)}</span></td>
                <td>${e.clock_out?`<span class="badge badge-resolved">${x(e.clock_out)}</span>`:Re(e)?`<span class="badge badge-danger">Forgot clock-out</span>`:`<span class="badge badge-open">Active</span>`}</td>
                <td>${Me(e.clock_in,e.clock_out)||`—`}</td>
                <td><small>${e.location||`—`}</small></td>
              </tr>`).join(``)}
          </tbody>
        </table>
      </div>
    </div>
  `}async function qe(e){A(e);let{user:t,leaves:n}=await He();if(!t){e.innerHTML=`<p>Please sign in.</p>`;return}let r=n.filter(e=>e.status===`pending`).length,i=n.filter(e=>e.status===`approved`).reduce((e,t)=>e+je(t.start_date,t.end_date),0);e.innerHTML=`
    <div class="page-header" style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;">
      <div>
        <h1>Leave Requests</h1>
        <p>Submit leave and track approval from admin</p>
      </div>
      <button class="btn btn-primary" id="leave-new">${j.plus}<span>New Request</span></button>
    </div>
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-value">${r}</div><div class="stat-label">Pending Requests</div></div>
      <div class="stat-card"><div class="stat-value" style="color:var(--success)">${i}</div><div class="stat-label">Approved Leave Days</div></div>
    </div>
    <div class="card">
      <div class="table-wrap">
        <table>
          <thead><tr><th>Dates</th><th>Days</th><th>Reason</th><th>Status</th></tr></thead>
          <tbody>
            ${n.length===0?`<tr><td colspan="4" style="text-align:center;padding:32px;color:var(--text-dim)">No leave requests yet</td></tr>`:n.map(e=>`<tr>
                <td><small>${y(e.start_date)} to ${y(e.end_date)}</small></td>
                <td>${je(e.start_date,e.end_date)}</td>
                <td style="max-width:360px;white-space:normal">${e.reason}</td>
                <td><span class="badge badge-${e.status}">${e.status}</span></td>
              </tr>`).join(``)}
          </tbody>
        </table>
      </div>
    </div>
  `,e.querySelector(`#leave-new`).onclick=()=>et(t.id,()=>qe(e))}async function Je(e){A(e);let{user:t,reports:n}=await He();if(!t){e.innerHTML=`<p>Please sign in.</p>`;return}let r=new Date().toLocaleDateString(`en-CA`),i=n.find(e=>e.date===r);e.innerHTML=`
    <div class="page-header">
      <h1>EOD Reports</h1>
      <p>View every daily summary you have submitted</p>
    </div>
    <div class="card">
      <div class="card-header"><span class="card-title sr-icon-title">${j.clipboard}<span>Today's Summary</span></span></div>
      <div class="card-body">
        ${i?`
          <div class="eod-done">
            <div class="eod-done-ring">${j.check}</div>
            <h3 class="eod-done-title">Submitted today</h3>
            <p class="eod-done-sub">${i.content}</p>
          </div>
        `:`
          <div class="form-group">
            <label class="sr-icon-label">${j.edit}<span>Today's progress</span></label>
            <textarea id="employee-eod-content" rows="5" placeholder="What did you complete today?"></textarea>
          </div>
          <button class="btn btn-primary btn-wide" id="employee-eod-submit">Submit Daily Report</button>
        `}
      </div>
    </div>
    <div class="card">
      <div class="table-wrap">
        <table>
          <thead><tr><th>Date</th><th>Submitted</th><th>Summary</th></tr></thead>
          <tbody>
            ${n.length===0?`<tr><td colspan="3" style="text-align:center;padding:32px;color:var(--text-dim)">No reports yet</td></tr>`:n.map(e=>`<tr>
                <td>${y(e.date)}</td>
                <td>${x(e.created_at)}</td>
                <td style="max-width:560px;white-space:normal;line-height:1.5">${e.content}</td>
              </tr>`).join(``)}
          </tbody>
        </table>
      </div>
    </div>
  `;let a=e.querySelector(`#employee-eod-submit`);a&&(a.onclick=async()=>{let n=e.querySelector(`#employee-eod-content`).value.trim();if(!n){_(`Please write your report`,`warning`);return}a.disabled=!0,a.textContent=`Submitting...`;let{error:i}=await u.from(`eod_reports`).insert({employee_id:t.id,content:n,date:r});i?(_(i.message,`error`),a.disabled=!1,a.textContent=`Submit Daily Report`):(_(`EOD Report submitted!`,`success`),Je(e))})}async function Ye(e){A(e);let{data:{user:t}}=await u.auth.getUser();if(!t){e.innerHTML=`<p>Please sign in.</p>`;return}let{data:n}=await u.from(`inquiries`).select(`*`).eq(`assigned_employee_id`,t.id).eq(`payment_method`,`cash`).eq(`payment_status`,`paid`).order(`cash_collected_at`,{ascending:!1}),r=(Array.isArray(n)?n:[]).filter(e=>e.cash_collected_at),i=r.filter(e=>!e.cash_submitted_at),a=r.filter(e=>e.cash_submitted_at),o=i.reduce((e,t)=>e+(Number(t.bill_total)||0),0),s=a.reduce((e,t)=>e+(Number(t.bill_total)||0),0),c=o+s,l=e=>{if(!e)return`—`;try{let t=new Date(String(e).replace(` `,`T`));return Number.isNaN(t.getTime())?e:t.toLocaleString(`en-IN`,{dateStyle:`medium`,timeStyle:`short`})}catch{return e}},d=e=>e.length===0?`<tr><td colspan="6" style="text-align:center;padding:32px;color:var(--text-dim)">No cash collections yet</td></tr>`:e.map(e=>`
      <tr>
        <td><small style="color:var(--text-dim)">${l(e.cash_collected_at)}</small></td>
        <td><code style="font-size:0.75rem;">${e.ticket_no||(e.id||``).slice(0,8)}</code></td>
        <td><b>${e.full_name||`—`}</b><br/><small style="color:var(--text-dim)">${e.phone||``}</small></td>
        <td><small>${e.service_item||`—`}</small></td>
        <td><b>₹${Math.round(Number(e.bill_total)||0).toLocaleString(`en-IN`)}</b></td>
        <td>${e.cash_submitted_at?`<span class="badge badge-resolved">Submitted</span><br/><small style="color:var(--text-dim)">${l(e.cash_submitted_at)}</small>`:`<span class="badge badge-medium">Pending</span>`}</td>
      </tr>`).join(``);e.innerHTML=`
    <div class="page-header" style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;">
      <div>
        <h1>My Cash</h1>
        <p>Cash you've collected from clients. Hand it to admin to clear the pending balance.</p>
      </div>
      <button class="btn btn-secondary" id="cash-refresh">${j.refresh}<span>Refresh</span></button>
    </div>

    <div class="stats-grid" style="margin-bottom:24px;">
      <div class="stat-card">
        <div class="stat-value" style="color:var(--warning); font-size:1.9rem;">₹${Math.round(o).toLocaleString(`en-IN`)}</div>
        <div class="stat-label">Pending Submission</div>
      </div>
      <div class="stat-card">
        <div class="stat-value" style="color:var(--success); font-size:1.9rem;">₹${Math.round(s).toLocaleString(`en-IN`)}</div>
        <div class="stat-label">Already Submitted</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">${r.length}</div>
        <div class="stat-label">Total Cash Jobs</div>
      </div>
      <div class="stat-card">
        <div class="stat-value" style="font-size:1.7rem;">₹${Math.round(c).toLocaleString(`en-IN`)}</div>
        <div class="stat-label">Total Collected (All Time)</div>
      </div>
    </div>

    ${o>0?`
      <div style="padding:14px 16px; border-radius:14px; background:rgba(245,158,11,0.08); border:1px dashed var(--warning); margin-bottom:18px; font-size:0.88rem; color:var(--text);">
        💵 You have <b>₹${Math.round(o).toLocaleString(`en-IN`)}</b> in cash to hand over to admin. Once admin records the submission in their Cash Collections tab, these entries will move to <b>Submitted</b>.
      </div>`:``}

    <div class="filter-bar" style="margin-bottom:16px;">
      <div class="sr-filter-bar" id="cash-tabs">
        <button class="sr-filter active" data-tab="pending">Pending <span class="sr-filter-count">${i.length}</span></button>
        <button class="sr-filter" data-tab="submitted">Submitted <span class="sr-filter-count">${a.length}</span></button>
        <button class="sr-filter" data-tab="all">All <span class="sr-filter-count">${r.length}</span></button>
      </div>
    </div>

    <div class="card">
      <div class="table-wrap">
        <table>
          <thead><tr><th>Date</th><th>Ticket</th><th>Customer</th><th>Service</th><th>Amount</th><th>Status</th></tr></thead>
          <tbody>${d(i)}</tbody>
        </table>
      </div>
    </div>
  `,e.querySelector(`#cash-refresh`).onclick=()=>Ye(e);let f={pending:i,submitted:a,all:r};e.querySelectorAll(`#cash-tabs .sr-filter`).forEach(t=>{t.onclick=()=>{e.querySelectorAll(`#cash-tabs .sr-filter`).forEach(e=>e.classList.remove(`active`)),t.classList.add(`active`);let n=f[t.dataset.tab]||r;e.querySelector(`tbody`).innerHTML=d(n)}})}async function Xe(e){A(e);let{user:t,profile:n,attendance:r,leaves:i}=await He();if(!t){e.innerHTML=`<p>Please sign in.</p>`;return}let a=ke(),o=r.filter(e=>String(e.date||``).startsWith(a)),s=new Set(o.map(e=>e.date)).size,c=i.filter(e=>e.status===`approved`&&String(e.start_date||``).startsWith(a)).reduce((e,t)=>e+je(t.start_date,t.end_date),0),l=new Date(new Date().getFullYear(),new Date().getMonth()+1,0).getDate(),u=Number(n?.salary)||0,d=u/l,f=s+c,p=d*f;e.innerHTML=`
    <div class="page-header">
      <h1>Salary</h1>
      <p>Month-to-date salary estimate based on attendance and approved leave</p>
    </div>
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-value" style="font-size:1.8rem">${ze(u)}</div><div class="stat-label">Monthly Salary</div></div>
      <div class="stat-card"><div class="stat-value">${s}</div><div class="stat-label">Days Present</div></div>
      <div class="stat-card"><div class="stat-value" style="color:var(--success)">${c}</div><div class="stat-label">Approved Leave Days</div></div>
      <div class="stat-card"><div class="stat-value" style="font-size:1.8rem;color:var(--warning)">${ze(p)}</div><div class="stat-label">Estimated Earned</div></div>
    </div>
    <div class="card">
      <div class="card-body">
        <div class="salary-breakdown">
          <div><span>Payable days</span><b>${f} / ${l}</b></div>
          <div><span>Per day value</span><b>${ze(d)}</b></div>
          <div><span>Formula</span><b>Present + approved leave</b></div>
        </div>
      </div>
    </div>
  `}async function Ze(e){A(e);let{data:{user:t}}=await u.auth.getUser();if(!t){e.innerHTML=`<p>Please sign in.</p>`;return}let n=ke(),[{data:r},{data:i}]=await Promise.all([u.from(`inquiries`).select(`*`).order(`feedback_at`,{ascending:!1}),u.from(`profiles`).select(`id,full_name,role`)]),a=new Map((i||[]).filter(e=>e.role===`employee`).map(e=>[e.id,e])),o=(r||[]).filter(e=>e.feedback_rating!=null),s=o.filter(e=>String(e.feedback_at||e.updated_at||``).startsWith(n)),c=e=>{let t=new Map;return e.forEach(e=>{let n=e.feedback_employee_id||e.assigned_employee_id;if(!n||!a.has(n))return;let r=Number(e.employee_rating||e.feedback_rating||0);if(!r)return;t.has(n)||t.set(n,{total:0,count:0,fiveStars:0});let i=t.get(n);i.total+=r,i.count+=1,r>=5&&(i.fiveStars+=1)}),[...t.entries()].map(([e,t])=>({id:e,name:a.get(e)?.full_name||`Employee`,avg:t.total/t.count,count:t.count,fiveStars:t.fiveStars})).sort((e,t)=>t.avg-e.avg||t.count-e.count||t.fiveStars-e.fiveStars)},l=c(s),d=c(o),f=l[0]||null,p=l.find(e=>e.id===t.id),m=d.find(e=>e.id===t.id),h=l.findIndex(e=>e.id===t.id)+1;e.innerHTML=`
    <div class="page-header">
      <h1>Leaderboard</h1>
      <p>Employee of the month is calculated from resolved service feedback.</p>
    </div>
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-value" style="color:var(--warning);font-size:1.8rem">${f?K(f.name):`-`}</div><div class="stat-label">Employee of Month</div></div>
      <div class="stat-card"><div class="stat-value" style="color:var(--primary)">${h||`-`}</div><div class="stat-label">Your Monthly Rank</div></div>
      <div class="stat-card"><div class="stat-value" style="color:var(--warning)">${p?p.avg.toFixed(2):`0.00`} <span style="font-size:1rem">/ 5</span></div><div class="stat-label">Your Month Rating</div></div>
      <div class="stat-card"><div class="stat-value" style="color:var(--success)">${m?m.count:0}</div><div class="stat-label">Your Total Reviews</div></div>
    </div>
    <div class="card">
      <div class="card-header"><span class="card-title">This Month</span></div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Rank</th><th>Employee</th><th>Rating</th><th>Reviews</th><th>5-Star</th></tr></thead>
          <tbody>
            ${l.length===0?`<tr><td colspan="5" style="text-align:center;padding:28px;color:var(--text-dim)">No feedback this month yet</td></tr>`:l.map((e,n)=>`<tr style="${e.id===t.id?`background:rgba(16,185,129,0.06)`:``}">
                <td><b>#${n+1}</b></td>
                <td><b>${K(e.name)}</b>${e.id===t.id?` <span class="badge badge-open">You</span>`:``}</td>
                <td>${Ve(e.avg)} <span style="margin-left:6px;font-weight:700">${e.avg.toFixed(2)}</span></td>
                <td>${e.count}</td>
                <td><span class="badge badge-resolved">${e.fiveStars}</span></td>
              </tr>`).join(``)}
          </tbody>
        </table>
      </div>
    </div>
    <div class="card" style="margin-top:24px">
      <div class="card-header"><span class="card-title">All-Time Ranking</span></div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Rank</th><th>Employee</th><th>Rating</th><th>Reviews</th></tr></thead>
          <tbody>
            ${d.length===0?`<tr><td colspan="4" style="text-align:center;padding:28px;color:var(--text-dim)">No ratings yet</td></tr>`:d.map((e,n)=>`<tr style="${e.id===t.id?`background:rgba(16,185,129,0.06)`:``}">
                <td><b>#${n+1}</b></td>
                <td><b>${K(e.name)}</b>${e.id===t.id?` <span class="badge badge-open">You</span>`:``}</td>
                <td>${Ve(e.avg)} <span style="margin-left:6px;font-weight:700">${e.avg.toFixed(2)}</span></td>
                <td>${e.count}</td>
              </tr>`).join(``)}
          </tbody>
        </table>
      </div>
    </div>
  `}async function Qe(e){let{data:{user:t}}=await u.auth.getUser();if(!t){e.innerHTML=`<p>Please sign in.</p>`;return}e.innerHTML=`
    <div class="employee-task-loader" role="status" aria-live="polite">
      <div class="employee-task-loader-card">
        <span class="employee-task-loader-spinner"></span>
        <div>
          <div class="employee-task-loader-title">Loading your tasks</div>
          <div class="employee-task-loader-sub">Fetching assigned jobs, active services, and pending requests...</div>
        </div>
      </div>
    </div>
  `;let n,r,i;try{let[e,a]=await Promise.all([u.from(`tickets`).select(`*, inquiries(*)`).eq(`assigned_to`,t.id).order(`created_at`,{ascending:!1}),u.from(`inquiries`).select(`*`).eq(`assigned_employee_id`,t.id).in(`assignment_status`,[`pending`,`accepted`]).order(`created_at`,{ascending:!1})]);n=e.data||[];let o=a.data||[],s=new Set(n.map(e=>e.inquiries?.[0]?.id).filter(Boolean));r=o.filter(e=>e.assignment_status===`pending`).sort(G),i=o.filter(e=>e.assignment_status===`accepted`&&!s.has(e.id)).sort(G).map(e=>({...e,_company:e.company_name||null}))}catch(t){e.innerHTML=`<div class="card"><div class="card-body" style="text-align:center;padding:40px;"><h3 style="color:var(--danger);display:inline-flex;align-items:center;gap:8px;">${j.alert}<span>Error</span></h3><p>${t.message}</p></div></div>`;return}let a=n.filter(e=>{let t=B(e.status);if(t===`resolved`)return!1;let n=e.inquiries?.[0];return n?n.assignment_status===`accepted`&&B(n.status)!==`resolved`:t===`assigned`||t===`in_progress`||t===`open`}),o=n.filter(e=>B(e.status)===`resolved`),s=n.filter(e=>B(e.status)===`issue_not_resolved`),c=i.filter(e=>![`resolved`,`closed`].includes(e.status)),l=i.filter(e=>[`resolved`,`closed`].includes(e.status)),d={all:n.length+i.length,active:a.length+c.length,completed:o.length+l.length,issues:s.length},f=e=>`
    <div class="emp-job-card" data-status="${B(e.status)}" data-company="${e._company||``}" style="padding:20px; border-radius:20px; background:var(--bg); box-shadow:var(--neu-sm); margin-bottom:20px; border:1px solid var(--border);">
       <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:16px;">
         <div>
           <div style="font-weight:800; font-size:1.15rem; color:var(--primary)">${e.full_name}</div>
           ${e._company?`<div style="font-size:0.75rem;font-weight:700;color:var(--text-dim);margin-top:2px;text-transform:uppercase;letter-spacing:0.5px">${e._company}</div>`:``}
           <div style="font-size:0.85rem; color:var(--text-soft); margin-top:4px;"><b>Ticket:</b> ${e.ticket_no||`—`}</div>
           <div style="font-size:0.82rem; color:var(--text-dim); margin-top:4px;"><b>Created:</b> ${b(e.created_at)}</div>
           <div style="font-size:0.85rem; color:var(--text-soft); margin-top:4px;">${e.service_item}</div>
         </div>
         <span class="badge badge-${B(e.status)}" style="font-size:0.75rem">${ve(e.status)}</span>
       </div>

       <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap:16px; margin-top:16px; padding-top:16px; border-top:1px solid rgba(16,185,129,0.1);">
         <div>
           <div style="font-size:0.7rem; color:var(--text-dim); text-transform:uppercase; font-weight:800; letter-spacing:0.5px;">Contact Info</div>
           <div style="display:flex; align-items:center; gap:10px; margin-top:8px;">
             <span style="font-weight:700; font-size:0.95rem">${e.phone}</span>
             <div style="display:flex; gap:6px;">
               <a href="tel:${e.phone}" style="display:flex; align-items:center; justify-content:center; width:32px; height:32px; border-radius:50%; background:var(--primary); color:white;">
                 <span style="width:16px;height:16px;display:flex;">${j.phone}</span>
               </a>
               <a href="https://wa.me/${e.phone.replace(/\D/g,``)}" target="_blank" style="display:flex; align-items:center; justify-content:center; width:32px; height:32px; border-radius:50%; background:#25D366; color:white;">
                 <span style="width:16px;height:16px;display:flex;">${j.whatsapp}</span>
               </a>
             </div>
           </div>
         </div>
         <div>
           <div style="font-size:0.7rem; color:var(--text-dim); text-transform:uppercase; font-weight:800; letter-spacing:0.5px;">Service Location</div>
           <div style="font-size:0.88rem; font-weight:600; margin-top:8px; display:flex; align-items:flex-start; gap:6px;">
             <span style="width:18px;height:18px;display:flex;flex-shrink:0;color:var(--primary)">${j.pin}</span>
             <span style="line-height:1.4">${e.location||`—`}</span>
           </div>
         </div>
         <div>
           <div style="font-size:0.7rem; color:var(--text-dim); text-transform:uppercase; font-weight:800; letter-spacing:0.5px;">Preferred Time</div>
           <div style="font-size:0.88rem; font-weight:700; margin-top:8px; color:var(--primary)">${e.preferred_time||`Flexible`}</div>
         </div>
       </div>

       <div style="margin-top:20px; display:flex; gap:10px;">
         <button class="btn btn-secondary btn-sm task-btn" data-id="${e.ticket_id}" data-inq-id="${e.id}" data-status="${e.status}" style="flex:1; height:40px; font-weight:700; display:flex; align-items:center; justify-content:center; gap:8px;">
           <span style="width:16px;height:16px;display:flex;">${j.edit}</span> Update Status
         </button>
         <button class="btn btn-primary btn-sm" onclick="window.open('${q(ge(e))}')" style="flex:1; height:40px; font-weight:700; display:flex; align-items:center; justify-content:center; gap:8px;">
           <span style="width:16px;height:16px;display:flex;">${j.pin}</span> Open Maps
         </button>
       </div>
    </div>
  `,p=e=>{let t=e.inquiries?.[0],n=B(e.status);return`
      <div class="emp-task-card" data-status="${n}" style="padding:20px; border-radius:20px; background:var(--bg); box-shadow:var(--neu-sm); margin-bottom:20px; border:1px solid var(--border);">
        <div style="display:flex; justify-content:space-between; align-items:flex-start;">
          <div style="flex:1">
            <div style="font-weight:800; font-size:1.1rem; color:var(--text)">${e.title}</div>
            <div style="font-size:0.82rem; color:var(--text-dim); margin-top:4px;"><b>Created:</b> ${b(t?.created_at||e.created_at)}</div>
            <div style="font-size:0.85rem; color:var(--text-soft); margin-top:4px;">${e.description||`No description provided.`}</div>
          </div>
          <div style="display:flex; flex-direction:column; align-items:flex-end; gap:6px;">
            <span class="badge badge-${n}">${ve(e.status)}</span>
            <span class="badge badge-${e.priority||`medium`}">${e.priority||`medium`}</span>
          </div>
        </div>
        
        ${t?`
          <div style="margin-top:16px; padding:14px; background:var(--bg-soft); border-radius:14px; border:1px dashed var(--primary);">
            <div style="font-size:0.75rem; color:var(--primary); font-weight:800; text-transform:uppercase; margin-bottom:10px;">Linked Service Request</div>
            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:12px;">
              <div>
                <div style="font-size:0.7rem; color:var(--text-dim)">Client</div>
                <div style="font-size:0.9rem; font-weight:700">${t.full_name}</div>
              </div>
              <div>
                <div style="font-size:0.7rem; color:var(--text-dim)">Ticket</div>
                <div style="font-size:0.9rem; font-weight:700; color:var(--primary)">${t.ticket_no||`—`}</div>
              </div>
              <div>
                <div style="font-size:0.7rem; color:var(--text-dim)">Contact</div>
                <div style="font-size:0.9rem; font-weight:700; display:flex; align-items:center; gap:6px;">
                  ${t.phone}
                  <a href="tel:${t.phone}" style="color:var(--primary); display:flex;"><span style="width:14px;height:14px;display:flex;">${j.phone}</span></a>
                  <a href="https://wa.me/${(t.phone||``).replace(/\\D/g,``)}" target="_blank" style="color:#25D366; display:flex;"><span style="width:14px;height:14px;display:flex;">${j.whatsapp}</span></a>
                </div>
              </div>
              <div>
                <div style="font-size:0.7rem; color:var(--text-dim)">Service</div>
                <div style="font-size:0.9rem; font-weight:600">${t.service_item||`—`}</div>
              </div>
              <div style="grid-column: span 2">
                <div style="font-size:0.7rem; color:var(--text-dim)">Location</div>
                <div style="font-size:0.88rem; font-weight:600; display:flex; align-items:flex-start; gap:6px;">
                  <span style="width:14px;height:14px;display:flex;flex-shrink:0;color:var(--primary);margin-top:2px;">${j.pin}</span>
                  ${t.location||`—`}
                </div>
              </div>
            </div>
          </div>
        `:``}
        
        <div style="margin-top:16px; display:flex; gap:10px; flex-wrap:wrap;">
          <button class="btn btn-secondary btn-sm task-btn" data-id="${e.id}" data-inq-id="${t?t.id:``}" data-status="${e.status}" style="flex:1; min-width:120px; height:42px; display:flex; align-items:center; justify-content:center; gap:6px; font-weight:700;">
            <span style="width:16px;height:16px;display:flex;">${j.edit}</span> Update Status
          </button>
          ${t?`
            <button class="btn btn-primary btn-sm" onclick="window.open('${q(ge(t))}')" style="flex:1; min-width:120px; height:42px; display:flex; align-items:center; justify-content:center; gap:6px; font-weight:700;">
              <span style="width:16px;height:16px;display:flex;">${j.pin}</span> Open Maps
            </button>
          `:``}
        </div>
      </div>
    `},m=[...c,...a].sort(G),h=[...l,...o].sort(G);e.innerHTML=`
    <div class="page-header" style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;">
      <div>
        <h1 style="display:flex; align-items:center; gap:12px;">
          <span style="width:32px; height:32px; display:flex; color:var(--primary);">${j.ticket}</span>
          <span>My Tasks</span>
        </h1>
        <p>All your assigned tasks, service jobs, and pending assignments</p>
      </div>
      <div style="display:flex; gap:10px; align-items:center;">
        <button class="btn btn-secondary" id="tasks-refresh">${j.refresh}<span>Refresh</span></button>
      </div>
    </div>

    <div class="stats-grid" style="margin-bottom:24px;">
      <div class="stat-card">
        <div class="stat-value" style="color:var(--primary)">${n.length+i.length}</div>
        <div class="stat-label">Total Jobs</div>
      </div>
      <div class="stat-card">
        <div class="stat-value" style="color:var(--warning)">${a.length+c.length}</div>
        <div class="stat-label">Active</div>
      </div>
      <div class="stat-card">
        <div class="stat-value" style="color:var(--success)">${o.length+l.length}</div>
        <div class="stat-label">Completed</div>
      </div>
      <div class="stat-card">
        <div class="stat-value" style="color:var(--danger)">${s.length}</div>
        <div class="stat-label">Issues</div>
      </div>
    </div>

    ${r.length>0?`
      <div style="margin-bottom:24px;">
        <div style="display:flex; align-items:center; gap:8px; margin-bottom:16px;">
          <span style="width:24px;height:24px;color:var(--primary);display:flex;">${j.alert}</span>
          <h2 style="margin:0; color:var(--primary); font-size:1.3rem;">New Assignments Pending</h2>
          <span style="background:var(--primary);color:white;border-radius:50%;width:28px;height:28px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:0.9rem;">${r.length}</span>
        </div>
        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(320px, 1fr)); gap:16px;">
          ${r.map(e=>`
            <div style="background:linear-gradient(135deg, rgba(16, 185, 129, 0.1) 0%, rgba(16, 185, 129, 0.05) 100%); border:2px solid var(--primary); border-radius:16px; padding:20px; box-shadow:0 4px 12px rgba(16, 185, 129, 0.1);">
              <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:14px;">
                <div>
                  <div style="font-size:0.75rem; color:var(--primary); font-weight:800; text-transform:uppercase; letter-spacing:0.5px; margin-bottom:6px;">Service Request</div>
                  <div style="font-size:1.1rem; font-weight:800; color:var(--text);">${K(e.full_name)}</div>
                </div>
                <span style="background:var(--primary); color:white; padding:6px 12px; border-radius:20px; font-size:0.75rem; font-weight:700;">${K(e.service_item)}</span>
              </div>

              <div style="background:rgba(16, 185, 129, 0.08); border-left:3px solid var(--primary); padding:12px; border-radius:8px; margin-bottom:14px;">
                <div style="font-size:0.72rem; color:var(--text-dim); font-weight:700; text-transform:uppercase; letter-spacing:0.5px; margin-bottom:4px;">Ticket</div>
                <div style="font-size:0.95rem; font-weight:700; color:var(--primary);">${K(e.ticket_no||`NE-`+Math.random().toString(36).substring(2,10).toUpperCase())}</div>
              </div>

              <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:14px;">
                <div>
                  <div style="font-size:0.7rem; color:var(--text-dim); font-weight:700; text-transform:uppercase; letter-spacing:0.5px; margin-bottom:4px;">Created</div>
                  <div style="font-size:0.85rem; font-weight:600;">${b(e.created_at)}</div>
                </div>
                <div>
                  <div style="font-size:0.7rem; color:var(--text-dim); font-weight:700; text-transform:uppercase; letter-spacing:0.5px; margin-bottom:4px;">Preferred Time</div>
                  <div style="font-size:0.85rem; font-weight:600; color:var(--primary);">${K(e.preferred_time||`Flexible`)}</div>
                </div>
              </div>

              <div style="margin-bottom:14px;">
                <div style="font-size:0.7rem; color:var(--text-dim); font-weight:700; text-transform:uppercase; letter-spacing:0.5px; margin-bottom:4px;">Location</div>
                <div style="font-size:0.85rem; font-weight:600; display:flex; align-items:flex-start; gap:6px;">
                  <span style="color:var(--primary); flex-shrink:0; margin-top:2px; width:14px; height:14px; display:flex;">${j.pin}</span>
                  <span>${K(e.location||`Not specified`)}</span>
                </div>
              </div>

              <div style="display:flex; gap:8px;">
                <button class="btn btn-primary btn-sm accept-btn" data-id="${e.id}" data-ticket-id="${e.ticket_id||``}" style="flex:1; height:40px; display:flex; align-items:center; justify-content:center; gap:6px; font-weight:700;">${j.check}<span>Accept</span></button>
                <button class="btn btn-danger btn-sm decline-btn" data-id="${e.id}" style="flex:1; height:40px; display:flex; align-items:center; justify-content:center; gap:6px; font-weight:700;">${j.close}<span>Decline</span></button>
              </div>
            </div>
          `).join(``)}
        </div>
      </div>
    `:``}

    <div class="filter-bar" style="margin-bottom:24px; display:flex; gap:12px; flex-wrap:wrap; align-items:center;">
      <div class="sr-filter-bar" id="task-filter-tabs">
        <button class="sr-filter active" data-filter="all"><span>All</span><span class="sr-filter-count">${d.all}</span></button>
        <button class="sr-filter" data-filter="active"><span>Active</span><span class="sr-filter-count">${d.active}</span></button>
        <button class="sr-filter" data-filter="completed"><span>Completed</span><span class="sr-filter-count">${d.completed}</span></button>
        <button class="sr-filter" data-filter="issues"><span>Issues</span><span class="sr-filter-count">${d.issues}</span></button>
      </div>
      <div class="search-input-wrap" style="flex:1; min-width:200px;">
        <span>${j.search||`🔍`}</span>
        <input class="search-input" id="task-search" placeholder="Search tasks by title, client, or ticket…"/>
      </div>
    </div>

    <div id="task-list">
      ${n.length===0&&i.length===0?`<div class="card"><div class="card-body" style="text-align:center;padding:48px;color:var(--text-dim)"><div style="font-size:2rem;margin-bottom:12px;">📋</div><p style="font-weight:600;">No tasks assigned yet</p><p style="font-size:0.85rem;">Tasks will appear here once admin assigns service requests to you.</p></div></div>`:`
          <div class="card">
            <div class="card-header"><span class="card-title">Active Services</span></div>
            <div class="card-body emp-scroll-list">
              ${m.length===0?`<div style="text-align:center;padding:28px;color:var(--text-dim)">No active services</div>`:m.map(e=>e.inquiries?p(e):f(e)).join(``)}
            </div>
          </div>
          <div class="card">
            <div class="card-header"><span class="card-title">Resolved Services</span></div>
            <div class="card-body emp-scroll-list">
              ${h.length===0?`<div style="text-align:center;padding:28px;color:var(--text-dim)">No resolved services yet</div>`:h.map(e=>e.inquiries?p(e):f(e)).join(``)}
            </div>
          </div>
        `}
    </div>
  `,e.querySelector(`#tasks-refresh`).onclick=async()=>{let t=_e(e.querySelector(`#tasks-refresh`),`Loading`);try{await Qe(e)}finally{t()}};let g=`all`,v=``,y=()=>{let t=e.querySelectorAll(`.emp-task-card, .emp-job-card`),n=v.toLowerCase();t.forEach(e=>{let t=e.dataset.status,r=e.textContent.toLowerCase(),i=g===`all`||g===`active`&&t!==`resolved`&&t!==`issue_not_resolved`||g===`completed`&&t===`resolved`||g===`issues`&&t===`issue_not_resolved`,a=!n||r.includes(n);e.style.display=i&&a?``:`none`})};e.querySelectorAll(`#task-filter-tabs .sr-filter`).forEach(t=>{t.onclick=()=>{e.querySelectorAll(`#task-filter-tabs .sr-filter`).forEach(e=>e.classList.remove(`active`)),t.classList.add(`active`),g=t.dataset.filter,y()}});let x=e.querySelector(`#task-search`);x&&(x.oninput=e=>{v=e.target.value,y()}),e.querySelectorAll(`.task-btn`).forEach(t=>{t.onclick=()=>R(t,t.dataset.id,t.dataset.inqId,t.dataset.status,()=>Qe(e))}),e.querySelectorAll(`.accept-btn`).forEach(t=>{t.onclick=async()=>{let n=[u.from(`inquiries`).update({assignment_status:`accepted`,status:`in_progress`}).eq(`id`,t.dataset.id)];t.dataset.ticketId&&n.push(u.from(`tickets`).update({status:`in_progress`}).eq(`id`,t.dataset.ticketId));let r=(await Promise.all(n)).find(e=>e.error)?.error;r?_(r.message,`error`):(_(`Task accepted!`,`success`),Qe(e))}}),e.querySelectorAll(`.decline-btn`).forEach(t=>{t.onclick=()=>{let n=prompt(`Please provide a reason for declining:`);if(n!==null){if(!n.trim()){_(`Reason is required to decline`,`warning`);return}(async()=>{let{error:r}=await u.from(`inquiries`).update({assignment_status:`declined`,decline_reason:n.trim(),status:`open`}).eq(`id`,t.dataset.id);r?_(r.message,`error`):(_(`Task declined`,`info`),Qe(e))})()}}})}function $e(e,t,n,r){return(async()=>{let{data:i}=await u.from(`service_pricing`).select(`*`).order(`category`),{data:a}=await u.from(`discount_presets`).select(`*`).eq(`active`,1).order(`created_at`,{ascending:!1}),{data:o}=await u.from(`device_types`).select(`name`).order(`name`),s=Array.isArray(o)?o:[],{data:c}=await u.from(`companies`).select(`*`).order(`name`),l=Array.isArray(c)?c:[],d=Array.isArray(a)?a:[],f={status:`unpaid`,received_at:null},p=null;if(t){let{data:e}=await u.from(`inquiries`).select(`*`).eq(`id`,t).single();e&&(p=e,f={status:e.payment_status||`unpaid`,received_at:e.payment_received_at||null})}let{data:{user:m}}=await u.auth.getUser(),h=m?(await u.from(`profiles`).select(`*`).eq(`id`,m.id).single()).data:null,g=new Date().toLocaleDateString(`en-CA`),v={lat:null,lng:null,location:null};if(m){let{data:e}=await u.from(`attendance`).select(`latitude,longitude,location,clock_in`).eq(`user_id`,m.id).eq(`date`,g).order(`clock_in`,{ascending:!1});Array.isArray(e)&&e[0]&&(v={lat:e[0].latitude,lng:e[0].longitude,location:e[0].location})}let y={};(i||[]).forEach(e=>{let t=e.category||`Uncategorized`,n=e.sub_category&&e.sub_category.trim()||``,r=e.sub_sub_category||e.name||``;r&&(y[t]??={},y[t][n]??=[],y[t][n].push({id:e.id,leaf:r,cost:Number(e.cost)||0}))});let S=Object.keys(y).sort(),C=B(n),w=C===`resolved`,ee=C===`resolved`,T=p?.created_at?E(p.created_at):null;Be(p?.created_at,p?.updated_at||new Date),[`resolved`,`closed`].includes(B(p?.status))&&Be(p?.created_at,p?.updated_at||p?.bill_generated_at||new Date);let D=document.createElement(`div`);D.className=`modal-overlay`,D.innerHTML=`
      <div class="modal" style="max-width:720px">
        <div class="modal-header">
          <span class="modal-title">Manage Service</span>
          <button class="modal-close" id="cm">✕</button>
        </div>
        <div class="modal-body" style="padding-top:14px;">
          <div class="mst-tabs" role="tablist">
            <button type="button" class="mst-tab active" data-tab="status">📌 Status</button>
            <button type="button" class="mst-tab" data-tab="device">🔧 Device Info</button>
            <button type="button" class="mst-tab" data-tab="bill">📄 Bill</button>
          </div>

          ${p?`
            <div style="margin:0 0 16px;padding:16px;border-radius:14px;background:var(--bg-soft);border:1px solid var(--border);">
              <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:16px;margin-bottom:14px;">
                <div>
                  <div style="font-size:0.72rem;color:var(--text-dim);font-weight:800;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px;">Ticket</div>
                  <div style="font-size:0.95rem;font-weight:700;color:var(--primary);">${K(p.ticket_no||`No ticket`)}</div>
                </div>
                <span class="badge badge-${B(p.status)}">${ve(p.status)}</span>
              </div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px;padding-bottom:14px;border-bottom:1px solid rgba(16,185,129,0.1);">
                <div>
                  <div style="font-size:0.7rem;color:var(--text-dim);font-weight:800;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;">Service Created</div>
                  <div style="font-size:0.88rem;font-weight:600;">${b(p.created_at)}</div>
                </div>
                <div>
                  <div style="font-size:0.7rem;color:var(--text-dim);font-weight:800;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;">Last Updated</div>
                  <div style="font-size:0.88rem;font-weight:600;">${p.updated_at?b(p.updated_at):b(p.created_at)}</div>
                </div>
              </div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px;">
                <div>
                  <div style="font-size:0.7rem;color:var(--text-dim);font-weight:800;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;">Name</div>
                  <div style="font-size:0.88rem;font-weight:600;">${K(p.full_name||`Client`)}</div>
                </div>
                <div>
                  <div style="font-size:0.7rem;color:var(--text-dim);font-weight:800;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;">Phone</div>
                  <div style="font-size:0.88rem;font-weight:600;">${K(p.phone||`-`)}</div>
                </div>
              </div>
              <div style="margin-bottom:14px;">
                <div style="font-size:0.7rem;color:var(--text-dim);font-weight:800;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;">Service Item</div>
                <div style="font-size:0.88rem;font-weight:600;">${K(p.service_item||`Service request`)}</div>
              </div>
              ${p.description?`
                <div style="margin-bottom:14px;padding:10px;background:rgba(16,185,129,0.05);border-radius:10px;border-left:3px solid var(--primary);">
                  <div style="font-size:0.7rem;color:var(--text-dim);font-weight:800;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;">Customer Description</div>
                  <div style="font-size:0.82rem;line-height:1.4;color:var(--text);">${K(p.description)}</div>
                </div>
              `:``}
              <div style="margin-bottom:14px;">
                <div style="font-size:0.7rem;color:var(--text-dim);font-weight:800;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;">Location</div>
                <div style="font-size:0.88rem;font-weight:600;display:flex;align-items:flex-start;gap:6px;">
                  <span style="color:var(--primary);flex-shrink:0;margin-top:2px;width:16px;height:16px;display:flex;">${j.pin}</span>
                  <span style="line-height:1.4;">${K(p.location||`-`)}</span>
                </div>
              </div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
                <div>
                  <div style="font-size:0.7rem;color:var(--text-dim);font-weight:800;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;">Preferred Time</div>
                  <div style="font-size:0.88rem;font-weight:600;color:var(--primary);">${K(p.preferred_time||`Flexible`)}</div>
                </div>
                <div>
                  <div style="font-size:0.7rem;color:var(--text-dim);font-weight:800;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;">SLA Deadline</div>
                  <div style="font-size:0.88rem;font-weight:600;">${[`resolved`,`closed`].includes(p?.status)?`Service Completed`:T?se(T):`-`}</div>
                </div>
              </div>
            </div>
          `:``}

          ${v.lat!=null||p?.customer_lat!=null?`
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:0 0 12px;">
              <a href="${v.lat==null?`#`:q(he(v.lat,v.lng))}" target="_blank" rel="noopener"
                 style="padding:10px;border-radius:10px;background:var(--bg-soft);border:1px solid var(--border);text-decoration:none;color:var(--text);font-size:0.78rem;${v.lat==null?`pointer-events:none;opacity:.55;`:``}">
                <b style="display:block;color:var(--primary);margin-bottom:3px;">Employee pin</b>
                <span>${K(v.location||`Clock-in GPS`)}</span>
              </a>
              <a href="${p?.customer_lat==null?`#`:q(he(p.customer_lat,p.customer_lng))}" target="_blank" rel="noopener"
                 style="padding:10px;border-radius:10px;background:var(--bg-soft);border:1px solid var(--border);text-decoration:none;color:var(--text);font-size:0.78rem;${p?.customer_lat==null?`pointer-events:none;opacity:.55;`:``}">
                <b style="display:block;color:var(--primary);margin-bottom:3px;">Client pin</b>
                <span>${K(p?.location||`Customer GPS`)}</span>
              </a>
            </div>
          `:``}

          ${p?.description?`
            <div style="margin:0 0 14px;padding:12px;border-radius:10px;background:var(--bg-soft);border:1px solid var(--border);">
              <div style="font-size:0.72rem;font-weight:700;color:var(--primary);letter-spacing:0.04em;text-transform:uppercase;margin-bottom:6px;">Client's reported issue</div>
              <div style="white-space:pre-wrap;line-height:1.45;font-size:0.86rem;">${K(p.description)}</div>
            </div>
          `:``}

          <!-- TAB 1: STATUS -->
          <div class="mst-pane active" data-pane="status">
            <div class="form-group">
              <label>New Status</label>
              <select id="new-status" ${w?`disabled`:``}>
                <option value="open" ${C===`open`?`selected`:``}>Received</option>
                <option value="in_progress" ${C===`in_progress`?`selected`:``}>In Progress</option>
                <option value="resolved" ${C===`resolved`?`selected`:``}>Resolved</option>
              </select>
            </div>

            <div class="form-group">
              <label>Work Details / Progress Update <span style="color:var(--danger)">*</span></label>
              <textarea id="progress-detail" rows="5" placeholder="Describe what you did... (Mandatory)"></textarea>
            </div>

            <div id="feedback-link-box" style="display:none; padding:12px; border-radius:12px; background:rgba(16,185,129,0.07); border:1px solid var(--primary);">
              <div style="font-size:0.78rem; font-weight:700; color:var(--primary); margin-bottom:6px;">📋 Feedback Link for Client</div>
              <div style="display:flex; gap:8px;">
                <input id="feedback-url" type="text" readonly style="flex:1; font-size:0.78rem; background:var(--bg);"/>
                <button class="btn btn-secondary btn-sm" id="copy-feedback-url">Copy</button>
              </div>
              <button class="btn btn-primary btn-sm" id="share-feedback-wa" style="width:100%; margin-top:8px; justify-content:center; gap:8px;">
                ${j.whatsapp}<span>Share Feedback Link via WhatsApp</span>
              </button>
            </div>
          </div>

          <!-- TAB 2: DEVICE INFO -->
          <div class="mst-pane" data-pane="device">
            <div class="form-group">
              <label>Company Name <span style="color:var(--danger)">*</span></label>
              <select id="resolve-company" style="margin-bottom:8px;">
                <option value="">Select Company…</option>
                ${l.map(e=>{let t=(p?.company_name||`networking experts`).toLowerCase()===e.name.toLowerCase();return`<option value="${e.name.replace(/"/g,`&quot;`)}" ${t?`selected`:``}>${e.name}</option>`}).join(``)}
                <option value="Other">Other (Type manually)</option>
              </select>
              <input type="text" id="resolve-company-custom" placeholder="Type custom company name (Mandatory)" style="display:none;"/>
            </div>
            <div class="form-group">
              <label>Device Type</label>
              <input type="text" id="device-type" list="emp-device-types" placeholder="${s.length?`Start typing or pick…`:`e.g. Video Door Phone`}" value="${(p?.device_type??``).replace(/"/g,`&quot;`)}"/>
              <datalist id="emp-device-types">
                ${s.map(e=>`<option value="${(e.name||``).replace(/"/g,`&quot;`)}"></option>`).join(``)}
              </datalist>
              ${s.length===0?`<small style="display:block; margin-top:6px; color:var(--text-dim); font-size:0.75rem;">Tip: ask admin to add device types so this becomes a quick-pick list.</small>`:``}
            </div>
            <div class="form-group">
              <label>Device Serial No</label>
              <input type="text" id="device-serial" placeholder="e.g. SN-12345" value="${(p?.device_serial_no??``).replace(/"/g,`&quot;`)}"/>
            </div>
            <small style="display:block; color:var(--text-dim); font-size:0.78rem; margin-top:-4px;">These are saved on the inquiry whenever you press Save Changes — and they appear on the bill template.</small>
          </div>

          <!-- TAB 3: BILL -->
          <div class="mst-pane" data-pane="bill">
            <div id="bill-locked-hint" style="display:${ee?`none`:`block`}; padding:14px; border-radius:12px; background:var(--bg-soft); border:1px dashed var(--border); margin-bottom:14px; font-size:0.85rem; color:var(--text-soft);">
              ℹ️ Set status to <b>Resolved</b> on the Status tab to enable billing.
            </div>
            <div id="pricing-section" style="display:${ee?`block`:`none`};">
              <label style="font-weight:700; margin-bottom:8px; display:block;">Diagnose Issue & Add Services</label>
              ${S.length===0?`
                <p style="font-size:0.8rem; color:var(--text-dim); padding:10px; background:var(--bg-soft); border-radius:10px;">No standard services defined by Admin.</p>
              `:`
                <div class="svc-picker-wrap">
                  <select id="svc-main" class="svc-picker">
                    <option value="">Select Main Category…</option>
                    ${S.map(e=>`<option value="${e.replace(/"/g,`&quot;`)}">${e}</option>`).join(``)}
                  </select>
                  <select id="svc-sub" class="svc-picker" disabled>
                    <option value="">Select Sub Category…</option>
                  </select>
                  <select id="svc-sub-sub" class="svc-picker" disabled>
                    <option value="">Select Specific Issue…</option>
                  </select>
                  <div class="svc-picker-actions">
                    <div class="svc-preview-text" id="svc-preview">Pick an issue to see the price.</div>
                    <button type="button" class="btn btn-primary btn-sm" id="svc-add" disabled style="white-space:nowrap;">+ Add</button>
                  </div>
                </div>
                <div id="svc-selected" style="display:none; margin-bottom:12px;"></div>
              `}

              <div class="form-group">
                <label>Additional Charges (Optional)</label>
                <input type="number" id="extra-cost" placeholder="₹0" style="margin-bottom:8px;"/>
                <input type="text" id="extra-reason" placeholder="Reason for extra charge..."/>
              </div>

              <div class="form-group">
                <label>Discount</label>
                <select id="admin-discount-preset" class="svc-picker" style="margin-bottom:8px;">
                  <option value="">No admin discount</option>
                  ${d.map(e=>`<option value="${q(e.id)}" data-amount="${Number(e.amount)||0}" data-name="${q(e.name||`Discount`)}">${K(e.name||`Discount`)} - Rs.${Math.round(Number(e.amount)||0).toLocaleString(`en-IN`)}</option>`).join(``)}
                </select>
                <div style="display:grid;grid-template-columns:1fr 1.4fr;gap:8px;">
                  <input type="number" id="manual-discount" min="0" step="1" placeholder="Employee discount Rs.0"/>
                  <input type="text" id="discount-reason" placeholder="Reason required for employee discount"/>
                </div>
                <small style="display:block;margin-top:6px;color:var(--text-dim);font-size:0.75rem;">Admin dropdown discounts do not need a reason. Employee/manual discount requires a reason and appears in Admin Discount Details.</small>
              </div>

              <div class="form-group">
                <label>Transport Distance (km)</label>
                <div style="display:flex; gap:8px; flex-wrap:wrap;">
                  <input type="number" id="transport-km" min="0" step="0.1" placeholder="0" style="flex:1; min-width:120px;"/>
                  <button type="button" class="btn btn-secondary btn-sm" id="capture-loc" style="white-space:nowrap" title="Capture your precise GPS location right now (you should be at the customer site)">📍 Capture My Location</button>
                  <button type="button" class="btn btn-secondary btn-sm" id="auto-km" style="white-space:nowrap" title="Calculate km from your clock-in location to the precise location">🧮 Auto km</button>
                </div>
                <small id="transport-km-hint" style="display:block; margin-top:6px; color:var(--text-dim); font-size:0.75rem;">₹5 per km · capture your precise location at the customer site, then click 🧮 Auto km.</small>
                <small id="bill-loc-status" style="display:none; margin-top:4px; color:var(--primary); font-size:0.75rem; font-weight:600;"></small>
              </div>

              <div class="bill-breakdown" id="bill-breakdown">
                <div class="bill-row"><span>Services subtotal</span><b id="br-services">₹0</b></div>
                <div class="bill-row"><span>Additional charges</span><b id="br-extra">₹0</b></div>
                <div class="bill-row"><span>Platform fee</span><b id="br-platform">₹50</b></div>
                <div class="bill-row"><span>Transport (<span id="br-km">0</span> km × ₹5)</span><b id="br-transport">₹0</b></div>
                <div class="bill-row bill-row-discount" id="br-discount-row" style="display:none;"><span>Loyalty discount (over ₹250)</span><b id="br-discount">−₹30</b></div>
                <div class="bill-row"><span>GST (18%)</span><b id="br-gst">₹0</b></div>
                <div class="bill-row bill-row-total"><span>Final total</span><b id="br-total">₹0</b></div>
                <input type="hidden" id="total-bill-display" value="0"/>
              </div>

              <button type="button" class="btn btn-primary btn-wide" id="open-bill-modal" style="margin-bottom:14px;">📄 Generate &amp; Send Premium Bill</button>

              <!-- Payment Method choice -->
              <div class="form-group" style="margin-bottom:14px;">
                <label>How will the client pay?</label>
                <div class="pay-method-toggle" id="pay-method-toggle">
                  <button type="button" class="pay-method-btn active" data-method="online">💳 Online (Razorpay)</button>
                  <button type="button" class="pay-method-btn" data-method="cash">💵 Cash on Service</button>
                </div>
              </div>

              <!-- Cash collection section (hidden until method=cash) -->
              <div id="cash-section" style="display:none; padding:14px; background:rgba(245,158,11,0.06); border-radius:14px; border:1px solid var(--warning); margin-bottom:14px;">
                <div style="font-weight:700; font-size:0.9rem; color:var(--text); margin-bottom:8px;">💵 Cash Collection</div>
                <div style="font-size:0.82rem; color:var(--text-soft); margin-bottom:12px;">
                  Mark this once you have <b>physically received</b> the cash from the client. The amount will appear in your <b>My Cash</b> tab as <i>pending submission</i> until you hand it to admin.
                </div>
                <button type="button" class="btn btn-primary btn-wide" id="mark-cash-btn" style="background:var(--warning); box-shadow:0 8px 24px rgba(245,158,11,0.32);">
                  ✓ Mark Cash Collected — <span id="cash-amount-display">₹0</span>
                </button>
                <div id="cash-collected-banner" style="display:none; margin-top:10px; padding:10px 12px; border-radius:10px; background:rgba(16,185,129,0.08); border:1px solid var(--success); font-size:0.85rem; color:var(--success); font-weight:700;">
                  ✓ Cash collected — appears in your My Cash tab.
                </div>
              </div>

              <!-- Payment Link + QR -->
              <div style="padding:14px; background:var(--bg-soft); border-radius:14px; border:1px solid var(--border);">
                <div style="font-weight:700; font-size:0.85rem; margin-bottom:10px; color:var(--text)">💳 Payment Link & QR</div>
                <div style="display:flex; gap:8px; margin-bottom:10px;">
                  <input id="emp-pay-link" type="url" placeholder="Payment link will appear here…" style="flex:1; font-size:0.82rem;" readonly/>
                  <button class="btn btn-secondary btn-sm" id="emp-gen-link" style="white-space:nowrap">✨ Generate</button>
                </div>
                <div id="emp-qr-wrap" style="display:none; text-align:center; margin-bottom:10px;">
                  <img id="emp-qr-img" src="" alt="QR Code" style="width:160px; height:160px; border-radius:12px; border:2px solid var(--primary);"/>
                  <div style="font-size:0.75rem; color:var(--text-dim); margin-top:6px;">Client can scan to pay</div>
                </div>
                <button class="btn btn-primary btn-sm" id="emp-share-wa" style="width:100%; display:none; gap:8px; justify-content:center;">
                  ${j.whatsapp}<span>Share via WhatsApp</span>
                </button>

                <div id="emp-pay-status" style="margin-top:12px; padding:12px; border-radius:12px; background:var(--bg); border:2px solid var(--border); display:flex; align-items:center; gap:10px;">
                  <div id="emp-pay-status-icon" style="width:32px; height:32px; display:flex; align-items:center; justify-content:center; color:var(--text-dim);">${j.clock}</div>
                  <div style="flex:1">
                    <div id="emp-pay-status-title" style="font-weight:800; font-size:0.9rem; color:var(--text)">Payment: Unpaid</div>
                    <div id="emp-pay-status-sub" style="font-size:0.75rem; color:var(--text-dim);">Generate a link, then wait for the client to pay.</div>
                  </div>
                  <button class="btn btn-secondary btn-sm" id="emp-pay-check" title="Re-check payment" style="white-space:nowrap">↻</button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" id="cm2">Cancel</button>
          <button class="btn btn-primary" id="save-update">Save Changes</button>
        </div>
      </div>`,document.body.appendChild(D);let O=[`status`,`device`,`bill`],te=()=>D.querySelector(`.mst-tab.active`)?.dataset.tab||O[0],ne=()=>te()===O[O.length-1],re=e=>{D.querySelectorAll(`.mst-tab`).forEach(t=>t.classList.toggle(`active`,t.dataset.tab===e)),D.querySelectorAll(`.mst-pane`).forEach(t=>t.classList.toggle(`active`,t.dataset.pane===e)),G()};D.querySelectorAll(`.mst-tab`).forEach(e=>{e.onclick=()=>re(e.dataset.tab)});let ie=D.querySelector(`#new-status`),ae=D.querySelector(`#pricing-section`),oe=D.querySelector(`#total-bill-display`),A=D.querySelector(`#extra-cost`),ce=D.querySelector(`#admin-discount-preset`),le=D.querySelector(`#manual-discount`),ue=D.querySelector(`#discount-reason`),de=D.querySelector(`#transport-km`),M=D.querySelector(`#save-update`),N=e=>`₹${Math.round(Number(e)||0).toLocaleString(`en-IN`)}`,P=()=>{let e=D.querySelector(`#resolve-company`),t=D.querySelector(`#resolve-company-custom`);return e?e.value===`Other`?t?.value.trim()||``:e.value:``},fe=()=>P().toLowerCase().replace(/\s+/g,` `)===`networking experts`?50:100,pe=async e=>{if(!e)return;let t=e.trim();if(t.toLowerCase()===`networking experts`||l.some(e=>e.name.toLowerCase()===t.toLowerCase()))return;let{data:n}=await u.from(`companies`).select(`name`).eq(`name`,t).maybeSingle();if(n)return;let{error:r}=await u.from(`companies`).insert({id:crypto.randomUUID?crypto.randomUUID():String(Math.random()),name:t});r||l.push({name:t})},F=[],I={servicesSubtotal:0,extra:0,platform:fe(),km:0,transport:0,autoDiscount:0,presetDiscount:0,manualDiscount:0,discount:0,discountLabel:``,discountReason:``,discountPresetId:null,taxable:0,gst:0,total:0},L=()=>{I.servicesSubtotal=F.reduce((e,t)=>e+(Number(t.cost)||0),0),I.extra=Number(A.value)||0,I.km=Math.max(0,Number(de.value)||0),I.transport=Math.round(I.km*5),I.platform=fe();let e=I.servicesSubtotal+I.extra+I.platform+I.transport;I.autoDiscount=e>250?30:0;let t=ce?.selectedOptions?.[0];I.discountPresetId=ce?.value||null,I.presetDiscount=I.discountPresetId&&Number(t?.dataset.amount)||0,I.manualDiscount=Math.max(0,Number(le?.value)||0),I.discount=Math.min(e,I.autoDiscount+I.presetDiscount+I.manualDiscount);let n=[];I.autoDiscount&&n.push(`Loyalty discount`),I.presetDiscount&&n.push(t?.dataset.name||`Admin discount`),I.manualDiscount&&n.push(`Employee discount`),I.discountLabel=n.join(` + `)||``,I.discountReason=ue?.value.trim()||``,I.taxable=e-I.discount,I.gst=Math.round(I.taxable*.18),I.total=I.taxable+I.gst,D.querySelector(`#br-services`).textContent=N(I.servicesSubtotal),D.querySelector(`#br-extra`).textContent=N(I.extra),D.querySelector(`#br-platform`).textContent=N(I.platform),D.querySelector(`#br-km`).textContent=I.km.toString(),D.querySelector(`#br-transport`).textContent=N(I.transport);let r=D.querySelector(`#br-discount-row`);r.style.display=I.discount>0?`flex`:`none`,r.querySelector(`span`).textContent=I.discountLabel||`Discount`,D.querySelector(`#br-discount`).textContent=`−${N(I.discount)}`,D.querySelector(`#br-gst`).textContent=N(I.gst),D.querySelector(`#br-total`).textContent=N(I.total),oe.value=String(I.total);let i=D.querySelector(`#cash-amount-display`);i&&(i.textContent=N(I.total))},ge=()=>(L(),I.manualDiscount>0&&!I.discountReason?(_(`Please enter reason for employee discount`,`warning`),!1):!0),_e=(e,t,n,r)=>{let i=e=>e*Math.PI/180,a=i(n-e),o=i(r-t),s=Math.sin(a/2)**2+Math.cos(i(e))*Math.cos(i(n))*Math.sin(o/2)**2;return 2*6371*Math.asin(Math.sqrt(s))},R={lat:null,lng:null,accuracy:null},z=D.querySelector(`#auto-km`),ye=D.querySelector(`#capture-loc`),be=D.querySelector(`#transport-km-hint`),xe=D.querySelector(`#bill-loc-status`),Se=()=>{let e=v.lat,t=v.lng,n=R.lat!=null,r=p?.customer_lat!=null&&p?.customer_lng!=null;if(e==null||t==null){be.textContent=`₹5 per km · enter manually (no clock-in GPS on record for today).`,z.disabled=!0,z.style.opacity=`0.5`;return}if(!n&&!r){be.textContent=`₹5 per km · capture your precise location at the customer site to enable Auto km.`,z.disabled=!0,z.style.opacity=`0.5`;return}z.disabled=!1,z.style.opacity=`1`,be.textContent=n?`₹5 per km · 🧮 Auto km uses clock-in GPS → your captured precise location.`:`₹5 per km · 🧮 Auto km uses clock-in GPS → customer GPS (capture precise location for higher accuracy).`};Se(),ye.onclick=async()=>{ye.disabled=!0;let e=ye.textContent;ye.innerHTML=`<span class="srf-spin"></span> Locating…`;try{let{latitude:e,longitude:t,accuracy:n}=(await me()).coords;R.lat=e,R.lng=t,R.accuracy=n,xe.style.display=`block`,xe.textContent=`📍 Captured: ${e.toFixed(6)}, ${t.toFixed(6)} (±${Math.round(n)}m)`,_(`Precise location captured (±${Math.round(n)}m)`,`success`),Se()}catch(e){_(`Could not capture location — check GPS permission`,`error`),console.error(`Capture location failed:`,e)}finally{ye.disabled=!1,ye.textContent=e}},z.onclick=()=>{let e=v.lat,t=v.lng;if(e==null||t==null)return;let n,r,i;if(R.lat!=null&&R.lng!=null)n=R.lat,r=R.lng,i=`precise capture`;else if(p?.customer_lat!=null&&p?.customer_lng!=null)n=p.customer_lat,r=p.customer_lng,i=`customer GPS`;else return;let a=_e(Number(e),Number(t),Number(n),Number(r));de.value=a.toFixed(1),L(),G(),_(`Distance: ${a.toFixed(1)} km (from ${i})`,`success`)},de.oninput=()=>{L(),G()};let Ce=D.querySelector(`#progress-detail`);Ce&&(Ce.oninput=()=>{G()});let we=D.querySelector(`#resolve-company`),V=D.querySelector(`#resolve-company-custom`),Te=()=>{we.value===`Other`?V.style.display=`block`:(V.style.display=`none`,V.value=``),L(),G()};if(we){we.onchange=Te;let e=p?.company_name||`networking experts`;l.some(t=>t.name.toLowerCase()===e.toLowerCase())?(we.value=l.find(t=>t.name.toLowerCase()===e.toLowerCase())?.name||e,V.style.display=`none`,V.value=``):(we.value=`Other`,V.style.display=`block`,V.value=e)}V&&(V.oninput=()=>{L(),G()});let Ee=D.querySelector(`#svc-main`),H=D.querySelector(`#svc-sub`),U=D.querySelector(`#svc-sub-sub`),De=D.querySelector(`#svc-preview`),ke=D.querySelector(`#svc-add`),W=D.querySelector(`#svc-selected`),Ae=e=>String(e??``).replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e]),je=()=>{if(W){if(F.length===0){W.style.display=`none`,W.innerHTML=``;return}W.style.display=`block`,W.innerHTML=`
        <div style="font-size:0.78rem; font-weight:700; color:var(--text-dim); margin-bottom:6px;">Services performed (${F.length})</div>
        ${F.map((e,t)=>`
          <div style="display:flex; align-items:center; gap:8px; padding:8px 10px; background:var(--bg); border:1px solid var(--border); border-radius:10px; margin-bottom:6px;">
            <div style="flex:1; font-size:0.85rem;">
              <b>${Ae(e.main)}</b>${e.sub?` › ${Ae(e.sub)}`:``} › ${Ae(e.leaf)}
            </div>
            <span style="font-weight:700; color:var(--primary);">₹${Number(e.cost).toLocaleString(`en-IN`)}</span>
            <button type="button" class="btn btn-danger btn-sm svc-remove" data-idx="${t}" title="Remove">✕</button>
          </div>
        `).join(``)}
      `,W.querySelectorAll(`.svc-remove`).forEach(e=>{e.onclick=()=>{F.splice(Number(e.dataset.idx),1),je(),L(),G()}})}},Me=()=>{if(!H)return;let e=Ee.value;if(H.innerHTML=`<option value="">Select Sub Category…</option>`,U.innerHTML=`<option value="">Select Specific Issue…</option>`,U.disabled=!0,De.textContent=`Pick an issue to see the price.`,ke.disabled=!0,!e||!y[e]){H.disabled=!0;return}let t=Object.keys(y[e]).sort();t.forEach(e=>{let t=document.createElement(`option`);t.value=e,t.textContent=e||`— (no sub-group)`,H.appendChild(t)}),H.disabled=!1,t.length===1&&(H.value=t[0],Ne())},Ne=()=>{if(!U)return;let e=Ee.value,t=H.value;if(U.innerHTML=`<option value="">Select Specific Issue…</option>`,De.textContent=`Pick an issue to see the price.`,ke.disabled=!0,!e||!y[e]||y[e][t]===void 0){U.disabled=!0;return}y[e][t].forEach((e,t)=>{let n=document.createElement(`option`);n.value=String(t),n.textContent=`${e.leaf} (₹${e.cost.toLocaleString(`en-IN`)})`,n.dataset.id=e.id,n.dataset.cost=e.cost,U.appendChild(n)}),U.disabled=!1};Ee&&(Ee.onchange=Me,H.onchange=Ne,U.onchange=()=>{let e=Ee.value,t=H.value,n=U.value;if(n===``||!y[e]?.[t]?.[Number(n)]){De.textContent=`Pick an issue to see the price.`,ke.disabled=!0;return}De.innerHTML=`Price: <b style="color:var(--primary)">₹${y[e][t][Number(n)].cost.toLocaleString(`en-IN`)}</b>`,ke.disabled=!1},ke.onclick=()=>{let e=Ee.value,t=H.value,n=U.value,r=y[e]?.[t]?.[Number(n)];if(r){if(F.some(e=>e.id===r.id)){_(`Already added`,`warning`);return}F.push({id:r.id,main:e,sub:t,leaf:r.leaf,cost:r.cost}),je(),L(),G(),U.value=``,De.textContent=`Pick an issue to see the price.`,ke.disabled=!0}});let Pe=D.querySelector(`#emp-pay-status`),Fe=D.querySelector(`#emp-pay-status-icon`),Ie=D.querySelector(`#emp-pay-status-title`),Le=D.querySelector(`#emp-pay-status-sub`),Re=!1,ze=!1,G=()=>{let e=ie.value===`resolved`,t=Number(oe.value)||0,n=e&&t>0,r=f.status===`paid`;r?(Pe.style.borderColor=`var(--success)`,Pe.style.background=`rgba(16,185,129,0.08)`,Fe.innerHTML=j.check,Fe.style.color=`var(--success)`,Ie.textContent=`✓ Payment Received`,Ie.style.color=`var(--success)`,Le.textContent=f.received_at?`Received at ${x(f.received_at)} — you can now submit.`:`You can now submit the resolution.`):Re?(Pe.style.borderColor=`var(--warning)`,Pe.style.background=`rgba(245,158,11,0.06)`,Fe.innerHTML=j.clock,Fe.style.color=`var(--warning)`,Ie.textContent=`⏳ Waiting for Payment`,Ie.style.color=`var(--warning)`,Le.textContent=`Auto-checking every 3s — Save unlocks the moment Razorpay confirms.`):(Pe.style.borderColor=`var(--border)`,Pe.style.background=`var(--bg)`,Fe.innerHTML=j.clock,Fe.style.color=`var(--text-dim)`,Ie.textContent=`Payment: ${f.status===`paid`?`Paid`:`Unpaid`}`,Ie.style.color=`var(--text)`,Le.textContent=n?`Generate a link, then wait for the client to pay before submitting.`:`Generate a link, then wait for the client to pay.`);let i=D.querySelector(`#progress-detail`)?.value.trim()||``,a=P(),o=i.length>0,s=a.length>0;if(ne())!o||!s?(M.disabled=!0,M.textContent=`Save Changes`,M.style.opacity=`0.6`,M.style.cursor=`not-allowed`,M.title=`Please fill out all mandatory fields in previous tabs (Status and Device Info).`):w?(M.disabled=!0,M.textContent=`Resolved`,M.style.opacity=`0.6`,M.style.cursor=`not-allowed`,M.title=`Resolved tasks are read-only.`):n&&!r?(M.disabled=!0,M.textContent=`Awaiting Payment…`,M.style.opacity=`0.6`,M.style.cursor=`not-allowed`,M.title=`Payment must be detected automatically, or marked paid by admin, before you can submit a resolution.`):(M.disabled=!1,M.textContent=ze?`💰 Save & Resolve`:`Save Changes`,M.style.opacity=`1`,M.style.cursor=`pointer`,M.title=``);else{let e=te(),t=!0,n=``;e===`status`?(t=o,n=`Please fill out the Work Details / Progress Update first.`):e===`device`&&(t=s,n=`Please fill out the Company Name first.`),t?(M.disabled=!1,M.textContent=`Next →`,M.style.opacity=`1`,M.style.cursor=`pointer`,M.title=``):(M.disabled=!0,M.textContent=`Next →`,M.style.opacity=`0.6`,M.style.cursor=`not-allowed`,M.title=n)}};ie.onchange=()=>{let e=ie.value===`resolved`;ae.style.display=e?`block`:`none`;let t=D.querySelector(`#bill-locked-hint`);t&&(t.style.display=e?`none`:`block`),G()},A.oninput=()=>{L(),G()},ce&&(ce.onchange=()=>{L(),G()}),le&&(le.oninput=()=>{L(),G()}),ue&&(ue.oninput=()=>{L(),G()});let Ve=async e=>{if(!t)return;let n=null;try{let e=localStorage.getItem(`auth_token`)||(await u.auth.getSession()).data.session?.access_token,r=await fetch(`/api/payments/check-status`,{method:`POST`,headers:{"Content-Type":`application/json`,Authorization:`Bearer ${e}`},body:JSON.stringify({inquiry_id:t})});r.ok&&(n=await r.json())}catch{}if(n||=(await u.from(`inquiries`).select(`payment_status,payment_received_at`).eq(`id`,t).single()).data,!n)return;let r=f.status===`paid`;f={status:n.payment_status||`unpaid`,received_at:n.payment_received_at||null},!r&&f.status===`paid`?(ze=!0,k({title:`💰 Payment Received`,body:`You can now submit the resolution.`,type:`payment`,tag:`pay-${t}`})):e&&_(f.status===`paid`?`Payment confirmed`:`Still waiting for client to pay…`,f.status===`paid`?`success`:`info`),G()};D.querySelector(`#emp-pay-check`).onclick=()=>Ve(!0);let He=null,Ue=()=>{He&&=(clearInterval(He),null)};f.status!==`paid`&&(He||!t||(He=setInterval(async()=>{if(f.status===`paid`)return Ue();await Ve(!1)},3e3)));let We=u.channel(`task-modal-${t||e}`).on(`postgres_changes`,{event:`UPDATE`,schema:`public`,table:`inquiries`,filter:t?`id=eq.${t}`:``},e=>{let n=e.new;if(!n||t&&n.id!==t)return;let r=f.status===`paid`;n.payment_status&&(f.status=n.payment_status),n.payment_received_at&&(f.received_at=n.payment_received_at),!r&&f.status===`paid`&&(ze=!0,k({title:`💰 Payment Received!`,body:`Client just paid. You can submit the resolution now.`,type:`payment`,tag:`pay-${t}`})),G()}).subscribe();L(),G(),w&&(D.querySelector(`#progress-detail`).disabled=!0,D.querySelectorAll(`#pricing-section input, #pricing-section select, #pricing-section textarea, #pricing-section button`).forEach(e=>{e.disabled=!0,e.style.opacity=`0.6`,e.style.cursor=`not-allowed`}));let Ge=``,J=D.querySelector(`#emp-gen-link`),Ke=D.querySelector(`#emp-pay-link`),qe=D.querySelector(`#emp-qr-wrap`),Je=D.querySelector(`#emp-qr-img`),Ye=D.querySelector(`#emp-share-wa`),Xe=e=>{Ge=e,Ke.value=e,Je.src=`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(e)}`,qe.style.display=`block`,Ye.style.display=`flex`};J&&(J.onclick=async()=>{let e=Number(oe.value)||0;if(!e){_(`Select services or enter a bill amount first`,`warning`);return}if(!ge())return;let{data:n}=await u.from(`inquiries`).select(`full_name,phone,service_item,ticket_no`).eq(`id`,t).single();if(!n){_(`Could not load inquiry details`,`error`);return}J.disabled=!0,J.textContent=`…`;try{let r=P();await pe(r);let i=localStorage.getItem(`auth_token`)||(await u.auth.getSession()).data.session?.access_token,a=await fetch(`/api/payments/create-link`,{method:`POST`,headers:{"Content-Type":`application/json`,Authorization:`Bearer ${i}`},body:JSON.stringify({amount:e,description:`Service: ${n.service_item}`,ticket_no:n.ticket_no,customer:{name:n.full_name,phone:n.phone}})}),o=await a.json();if(!a.ok)throw Error(o.error||`Failed`);Xe(o.short_url),await u.from(`inquiries`).update({payment_link:o.short_url,payment_link_id:o.id||null,bill_amount:I.servicesSubtotal+I.extra,transport_km:I.km,transport_fee:I.transport,platform_fee:I.platform,discount_amount:I.discount,discount_label:I.discountLabel||null,discount_reason:I.manualDiscount>0?I.discountReason:null,discount_preset_id:I.discountPresetId||null,gst_amount:I.gst,bill_total:I.total,bill_generated_at:new Date().toISOString().slice(0,19).replace(`T`,` `),device_type:D.querySelector(`#device-type`)?.value.trim()||null,device_serial_no:D.querySelector(`#device-serial`)?.value.trim()||null,company_name:r||null,employee_bill_lat:R.lat,employee_bill_lng:R.lng}).eq(`id`,t),Re=!0,G(),_(`Payment link generated! Waiting for client to pay…`,`success`)}catch(e){_(e.message,`error`)}finally{J.disabled=!1,J.textContent=`✨ Generate`}});let Ze=D.querySelector(`#open-bill-modal`);Ze&&(Ze.onclick=async()=>{if(I.total<=0){_(`Add services or charges first to generate a bill`,`warning`);return}if(!ge())return;let{data:e}=t?await u.from(`inquiries`).select(`*`).eq(`id`,t).single():{data:p},n=e||p||{},r={...I,customer:{name:n.full_name||``,phone:n.phone||``,location:n.location||``,company:P()||n.company_name||``,device_type:D.querySelector(`#device-type`)?.value.trim()||n.device_type||``,device_serial:D.querySelector(`#device-serial`)?.value.trim()||n.device_serial_no||``,service_item:n.service_item||``,ticket_no:n.ticket_no||``},technician:h?.full_name||`Technician`,services:F.map(e=>({name:`${e.main}${e.sub?` › `+e.sub:``} › ${e.leaf}`,cost:e.cost})),extraReason:D.querySelector(`#extra-reason`)?.value.trim()||``,discountLabel:I.discountLabel,discountReason:I.manualDiscount>0?I.discountReason:``,paymentLink:Ge||n.payment_link||``};Oe(r,{inquiryId:t||null,onSent:async e=>{if(!t)return;let n={bill_amount:I.servicesSubtotal+I.extra,transport_km:I.km,transport_fee:I.transport,platform_fee:I.platform,discount_amount:I.discount,discount_label:I.discountLabel||null,discount_reason:I.manualDiscount>0?I.discountReason:null,discount_preset_id:I.discountPresetId||null,gst_amount:I.gst,bill_total:I.total,bill_generated_at:new Date().toISOString().slice(0,19).replace(`T`,` `),device_type:r.customer.device_type||null,device_serial_no:r.customer.device_serial||null,company_name:P()||null,employee_bill_lat:R.lat,employee_bill_lng:R.lng};e&&(n.bill_pdf_url=e),await u.from(`inquiries`).update(n).eq(`id`,t)}})}),Ye&&(Ye.onclick=()=>{Ge&&window.open(`https://wa.me/?text=${encodeURIComponent(`Please use this link to pay for your service: `+Ge)}`,`_blank`)});let Qe=D.querySelector(`#pay-method-toggle`),$e=D.querySelector(`#cash-section`),et=D.querySelector(`#emp-pay-link`)?.closest(`div[style*="background:var(--bg-soft)"]`),tt=D.querySelector(`#cash-amount-display`),nt=D.querySelector(`#cash-collected-banner`),Y=D.querySelector(`#mark-cash-btn`),rt=p?.payment_method===`cash`?`cash`:`online`,it=()=>{Qe.querySelectorAll(`.pay-method-btn`).forEach(e=>{e.classList.toggle(`active`,e.dataset.method===rt)}),$e.style.display=rt===`cash`?`block`:`none`,et&&(et.style.display=rt===`cash`?`none`:`block`),tt&&(tt.textContent=`₹${Math.round(I.total).toLocaleString(`en-IN`)}`),p?.payment_method===`cash`&&p?.payment_status===`paid`&&nt&&(nt.style.display=`block`,Y&&(Y.disabled=!0,Y.style.opacity=`0.55`))};Qe.querySelectorAll(`.pay-method-btn`).forEach(e=>{e.onclick=()=>{rt=e.dataset.method,it()}}),it(),Y&&(Y.onclick=async()=>{if(!t){_(`Cannot mark cash on a task without an inquiry record`,`error`);return}if(I.total<=0){_(`Add services or charges first`,`warning`);return}if(!ge())return;let e=P();Y.disabled=!0;let n=Y.innerHTML;Y.innerHTML=`<span>Saving…</span>`;try{await pe(e);let n=new Date().toISOString().slice(0,19).replace(`T`,` `),r={payment_method:`cash`,payment_status:`paid`,payment_received_at:n,cash_collected_at:n,bill_amount:I.servicesSubtotal+I.extra,extra_cost:I.extra,extra_cost_reason:D.querySelector(`#extra-reason`)?.value.trim()||null,transport_km:I.km,transport_fee:I.transport,platform_fee:I.platform,discount_amount:I.discount,discount_label:I.discountLabel||null,discount_reason:I.manualDiscount>0?I.discountReason:null,discount_preset_id:I.discountPresetId||null,gst_amount:I.gst,bill_total:I.total,bill_generated_at:n,device_type:D.querySelector(`#device-type`)?.value.trim()||null,device_serial_no:D.querySelector(`#device-serial`)?.value.trim()||null,company_name:e||null,employee_bill_lat:R.lat,employee_bill_lng:R.lng},{error:i}=await u.from(`inquiries`).update(r).eq(`id`,t);if(i)throw Error(i.message);f={status:`paid`,received_at:n},p={...p||{},...r},ze=!0,G(),it(),_(`✓ Cash recorded — visible in My Cash as pending submission`,`success`)}catch(e){_(e.message||`Could not mark cash`,`error`),Y.disabled=!1,Y.innerHTML=n}});let at=()=>{Ue();try{u.removeChannel(We)}catch{}D.remove()};D.querySelector(`#cm`).onclick=D.querySelector(`#cm2`).onclick=at,D.querySelector(`#save-update`).onclick=async()=>{if(!ne()){re(O[O.indexOf(te())+1]);return}if(w){_(`Resolved tasks are read-only`,`info`);return}let n=ie.value,i=D.querySelector(`#progress-detail`).value.trim(),a=P();if(!i){_(`Please provide details of your work`,`warning`);return}if(!a){_(`Please provide the company name`,`warning`);return}if(!ge())return;let o=D.querySelector(`#save-update`);o.disabled=!0,o.textContent=`Saving...`;try{await pe(a)}catch(e){console.error(`Failed to ensure company:`,e)}let s=[],c=n===`resolved`;c&&F.forEach(e=>{s.push(e.id)});let{data:{user:l}}=await u.auth.getUser(),d=[u.from(`tickets`).update({status:n}).eq(`id`,e)],f={status:n},p=D.querySelector(`#device-type`)?.value.trim(),m=D.querySelector(`#device-serial`)?.value.trim();if(a&&(f.company_name=a),p&&(f.device_type=p),m&&(f.device_serial_no=m),c&&I.total>0&&(f.bill_amount=I.servicesSubtotal+I.extra,f.extra_cost=I.extra,f.extra_cost_reason=D.querySelector(`#extra-reason`).value.trim()||null,f.transport_km=I.km,f.transport_fee=I.transport,f.platform_fee=I.platform,f.discount_amount=I.discount,f.discount_label=I.discountLabel||null,f.discount_reason=I.manualDiscount>0?I.discountReason:null,f.discount_preset_id=I.discountPresetId||null,f.gst_amount=I.gst,f.bill_total=I.total,f.employee_bill_lat=R.lat,f.employee_bill_lng=R.lng),t?d.push(u.from(`inquiries`).update(f).eq(`id`,t)):d.push(u.from(`inquiries`).update(f).eq(`ticket_id`,e)),t&&s.length>0&&d.push(u.from(`inquiry_services`).insert(s.map(e=>({inquiry_id:t,service_id:e})))),d.push(u.from(`ticket_comments`).insert({ticket_id:e,user_id:l.id,content:`[Status: ${n.replace(`_`,` `)}] ${i}${c&&I.total>0?` (Bill: ₹${I.total})`:``}`})),await Promise.all(d),_(`Task updated!`,`success`),n===`resolved`){let{data:n}=t?await u.from(`inquiries`).select(`ticket_no,phone`).eq(`id`,t).single():await u.from(`inquiries`).select(`ticket_no,phone`).eq(`ticket_id`,e).single();if(n?.ticket_no){let e=`${window.location.origin}/?tab=track&ticket=${n.ticket_no}&phone=${n.phone||``}`,t=D.querySelector(`#feedback-link-box`),r=D.querySelector(`#feedback-url`),i=D.querySelector(`#copy-feedback-url`),a=D.querySelector(`#share-feedback-wa`);if(t&&r){r.value=e,t.style.display=`block`,i.onclick=()=>{navigator.clipboard.writeText(e),_(`Copied!`,`success`)},a.onclick=()=>window.open(`https://wa.me/${(n.phone||``).replace(/\D/g,``)}?text=${encodeURIComponent(`Thank you for choosing our service! Please share your feedback here: `+e)}`,`_blank`),o.disabled=!1,o.textContent=`Done`;return}}}at(),r()}})()}function et(e,t){let n=document.createElement(`div`);n.className=`modal-overlay`,n.innerHTML=`
    <div class="modal" style="max-width:450px">
      <div class="modal-header">
        <span class="modal-title">Submit Leave Request</span>
        <button class="modal-close" id="cl">✕</button>
      </div>
      <div class="modal-body">
        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
          <div class="form-group"><label>Start Date</label><input type="date" id="l-start" required/></div>
          <div class="form-group"><label>End Date</label><input type="date" id="l-end" required/></div>
        </div>
        <div class="form-group">
          <label>Reason for Leave</label>
          <textarea id="l-reason" rows="4" placeholder="Explain your reason..."></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" id="cl2">Cancel</button>
        <button class="btn btn-primary" id="btn-submit-leave">Submit Request</button>
      </div>
    </div>`,document.body.appendChild(n),n.querySelector(`#cl`).onclick=n.querySelector(`#cl2`).onclick=()=>n.remove(),n.querySelector(`#btn-submit-leave`).onclick=async()=>{let r=n.querySelector(`#l-start`).value,i=n.querySelector(`#l-end`).value,a=n.querySelector(`#l-reason`).value.trim();if(!r||!i||!a){_(`Please fill in all fields`,`warning`);return}let o=n.querySelector(`#btn-submit-leave`);o.disabled=!0,o.textContent=`Submitting...`;let{error:s}=await u.from(`leave_requests`).insert({employee_id:e,start_date:r,end_date:i,reason:a,status:`pending`});s?(_(s.message,`error`),o.disabled=!1,o.textContent=`Submit Request`):(_(`Leave request submitted!`,`success`),n.remove(),t())}}async function tt(e){A(e);try{let{data:t,error:n}=await u.from(`service_pricing`).select(`*`).order(`category`);if(n)throw n;let r=t||[],i=[...new Set(r.map(e=>e.category||`Service`))].sort(),a=[...new Set(r.map(e=>e.sub_category||``).filter(Boolean))].sort(),o=e=>e.length===0?`<tr><td colspan="6" style="text-align:center;padding:32px;color:var(--text-dim)">No services match this filter</td></tr>`:e.map(e=>`
          <tr data-main="${q(e.category||`Service`)}" data-sub="${q(e.sub_category||``)}" data-search="${q(`${e.category||``} ${e.sub_category||``} ${e.sub_sub_category||``} ${e.name||``}`.toLowerCase())}">
            <td><input type="checkbox" class="service-checkbox" data-id="${e.id}"></td>
            <td><span class="badge badge-open">${K(e.category||`Service`)}</span></td>
            <td>${e.sub_category?K(e.sub_category):`<span style="color:var(--text-dim)">-</span>`}</td>
            <td><b>${K(e.sub_sub_category||e.name||``)}</b></td>
            <td>${ze(e.cost)}</td>
            <td style="display:flex;gap:6px;"><button class="btn btn-secondary btn-sm edit-price" data-id="${e.id}" title="Edit">${j.edit||`Edit`}</button><button class="btn btn-danger btn-sm del-price" data-id="${e.id}" title="Delete">${j.close}</button></td>
          </tr>
        `).join(``);e.innerHTML=`
      <div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:16px;">
        <div style="flex:1;min-width:250px;">
          <h1 style="display:flex;align-items:center;gap:12px;margin:0 0 8px;">
            <span style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;color:var(--primary);font-size:1.4rem;flex-shrink:0;">${j.receipt||``}</span>
            <span>Service Pricing</span>
          </h1>
          <p style="margin:0;font-size:0.95rem;">Manage and filter service rates</p>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end;">
          <button class="btn btn-secondary" id="dl-template" style="white-space:nowrap;">${j.download||``}<span>Template</span></button>
          <button class="btn btn-secondary" id="upload-price" style="white-space:nowrap;">${j.upload||``}<span>Upload</span></button>
          <button class="btn btn-primary" id="add-price" style="white-space:nowrap;">${j.plus}<span>Add</span></button>
          <input type="file" id="upload-price-file" accept=".xlsx,.xls,.csv" style="display:none">
          <button class="btn btn-primary" id="emp-pricing-export" style="white-space:nowrap;">${j.download||``}<span>Export</span></button>
        </div>
      </div>

      <div class="card" style="margin-bottom:12px;padding:12px 16px;font-size:13px;color:var(--text-dim);">
        Excel/CSV columns: <b>Main Category</b>, <b>Sub Category</b>, <b>Sub-Sub Category</b>, <b>Price</b>. Sub Category is optional — a 3-column file is also accepted.
      </div>

      <div class="card" style="margin-bottom:14px;">
        <div class="card-body" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;align-items:end;">
          <div class="form-group" style="margin:0;">
            <label>Main Category</label>
            <select id="emp-price-main">
              <option value="all">All categories</option>
              ${i.map(e=>`<option value="${q(e)}">${K(e)}</option>`).join(``)}
            </select>
          </div>
          <div class="form-group" style="margin:0;">
            <label>Sub Category</label>
            <select id="emp-price-sub">
              <option value="all">All sub categories</option>
              ${a.map(e=>`<option value="${q(e)}">${K(e)}</option>`).join(``)}
            </select>
          </div>
          <div class="form-group" style="margin:0;">
            <label>Search</label>
            <input id="emp-price-search" type="search" placeholder="Search service or issue"/>
          </div>
          <button class="btn btn-secondary" id="emp-price-reset">${j.refresh||``}<span>Reset</span></button>
        </div>
      </div>

      <div class="card">
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;" id="bulk-actions">
          <button class="btn btn-danger btn-sm" id="del-selected" style="display:none;">Delete Selected</button>
          <button class="btn btn-warning btn-sm" id="remove-dupes">Remove Duplicates</button>
        </div>
        <div class="card-header">
          <span class="card-title">Services</span>
          <span id="emp-price-count" style="font-size:0.82rem;color:var(--text-dim);font-weight:700;">${r.length} item${r.length===1?``:`s`}</span>
        </div>
        <div class="table-wrap">
          <table>
            <thead>
              <tr><th style="width:30px;"><input type="checkbox" id="select-all" title="Select all"></th><th>Main Category</th><th>Sub Category</th><th>Service / Issue</th><th>Price</th><th>Actions</th></tr>
            </thead>
            <tbody id="emp-price-body">${o(r)}</tbody>
          </table>
        </div>
      </div>
    `;let s=e.querySelector(`#emp-price-main`),c=e.querySelector(`#emp-price-sub`),l=e.querySelector(`#emp-price-search`),d=e.querySelector(`#emp-price-body`),f=e.querySelector(`#emp-price-count`),p=e.querySelector(`#select-all`),m=e.querySelector(`#del-selected`),h=[...r],g=()=>{let e=s.value;c.innerHTML=`<option value="all">All sub categories</option>`+(e===`all`?a:[...new Set(r.filter(t=>t.category===e).map(e=>e.sub_category||``).filter(Boolean))].sort()).map(e=>`<option value="${e}">${e}</option>`).join(``),c.value=`all`,v()},v=()=>{let e=s.value,t=c.value,n=l.value.trim().toLowerCase();h=r.filter(r=>{let i=r.category||`Service`,a=r.sub_category||``,o=`${r.category||``} ${r.sub_category||``} ${r.sub_sub_category||``} ${r.name||``}`.toLowerCase();return(e===`all`||i===e)&&(t===`all`||a===t)&&(!n||o.includes(n))}),d.innerHTML=o(h),f.textContent=`${h.length} item${h.length===1?``:`s`}`,b(),y()},y=()=>{let t=e.querySelectorAll(`.service-checkbox:checked`).length;m.style.display=t>0?``:`none`},b=()=>{e.querySelectorAll(`.service-checkbox`).forEach(e=>{e.onchange=y}),e.querySelectorAll(`.edit-price`).forEach(t=>{t.onclick=async()=>{let n=r.find(e=>e.id===t.dataset.id);if(!n)return;let i=prompt(`Main Category:`,n.category||`Service`);if(i===null)return;let a=prompt(`Sub Category:`,n.sub_category||``);if(a===null)return;let o=prompt(`Sub-Sub Category:`,n.sub_sub_category||n.name||``);if(!o)return;let s=prompt(`Price (₹):`,String(n.cost||0)),c=parseFloat(s);if(!Number.isFinite(c)||c<0){_(`Invalid price`,`error`);return}let{error:l}=await u.from(`service_pricing`).update({category:i||`Uncategorized`,sub_category:a.trim()||null,sub_sub_category:o,name:o,cost:c}).eq(`id`,n.id);l?_(l.message,`error`):(_(`Service updated`,`success`),tt(e))}}),e.querySelectorAll(`.del-price`).forEach(t=>{t.onclick=async()=>{if(!confirm(`Delete this service?`))return;let{error:n}=await u.from(`service_pricing`).delete().eq(`id`,t.dataset.id);n?_(n.message,`error`):(_(`Service deleted`,`success`),tt(e))}})};s.onchange=g,c.onchange=v,l.oninput=v,p.onchange=()=>{e.querySelectorAll(`.service-checkbox`).forEach(e=>e.checked=p.checked),y()},e.querySelector(`#emp-price-reset`).onclick=()=>{s.value=`all`,c.value=`all`,l.value=``,v()},m.onclick=async()=>{let t=Array.from(e.querySelectorAll(`.service-checkbox:checked`)).map(e=>e.dataset.id);if(!t.length||!confirm(`Delete ${t.length} service${t.length===1?``:`s`}?`))return;let n=0;for(let e of t){let{error:t}=await u.from(`service_pricing`).delete().eq(`id`,e);t||n++}_(`Deleted ${n} service${n===1?``:`s`}`,`success`),tt(e)},e.querySelector(`#remove-dupes`).onclick=async()=>{let t=new Map,n=[];if(r.forEach(e=>{let r=`${e.category}||${e.sub_category}||${e.sub_sub_category}`;t.has(r)?n.push(e.id):t.set(r,e.id)}),!n.length){_(`No duplicates found`,`info`);return}if(!confirm(`Found ${n.length} duplicate service${n.length===1?``:`s`}. Delete them?`))return;let i=0;for(let e of n){let{error:t}=await u.from(`service_pricing`).delete().eq(`id`,e);t||i++}_(`Removed ${i} duplicate${i===1?``:`s`}`,`success`),tt(e)};let x=!1;e.querySelector(`#add-price`).onclick=()=>{if(x)return;let t=prompt(`Enter Main Category:`);if(t===null)return;let n=prompt(`Enter Sub Category (optional):`);if(n===null)return;let r=prompt(`Enter Sub-Sub Category (specific issue):`);if(!r)return;let i=prompt(`Enter Price (₹):`),a=parseFloat(i);if(!Number.isFinite(a)||a<0){_(`Invalid price`,`error`);return}x=!0,(async()=>{try{let{error:i}=await u.from(`service_pricing`).insert({id:crypto.randomUUID?.()||`svc-${Date.now()}`,category:t||`Uncategorized`,sub_category:n.trim()||null,sub_sub_category:r,name:r,cost:a});i?.status===429?_(`Server is busy — please try again in a few seconds`,`error`):i?_(i.message||`Failed to add service`,`error`):(_(`Service added`,`success`),tt(e))}finally{x=!1}})()};let S=e.querySelector(`#upload-price-file`),w=!1;e.querySelector(`#upload-price`).onclick=()=>{if(w){_(`Upload in progress...`,`info`);return}S.click()},S.onchange=async()=>{let t=S.files?.[0];if(t){if(w){_(`Upload already in progress`,`warning`);return}w=!0,S.value=``,_(`Reading ${t.name}...`,`info`);try{let n=await Ue(t);if(!n.length){_(`File is empty`,`warning`);return}let{inserted:r,skipped:i}=await We(n);r?_(`Imported ${r} service${r===1?``:`s`}${i?` (${i} skipped)`:``}`,`success`):_(`No rows imported${i?` — ${i} skipped`:``}`,`warning`),tt(e)}catch(e){console.error(`[pricing import] failed`,e),_(e.message||`Failed to read file`,`error`)}finally{w=!1}}},e.querySelector(`#dl-template`).onclick=Ge,e.querySelector(`#emp-pricing-export`).onclick=()=>{if(!h.length){_(`No services to export`,`warning`);return}C(`service-pricing-${s.value===`all`?`all-main-categories`:s.value.toLowerCase().replace(/[^a-z0-9]+/g,`-`).replace(/^-+|-+$/g,``)}.csv`,h.map(e=>({main_category:e.category||`Service`,sub_category:e.sub_category||``,service:e.sub_sub_category||e.name||``,price:Number(e.cost)||0})))},b(),y()}catch(t){console.error(`[employee pricing] initialization failed:`,t),e.innerHTML=`
      <div class="card" style="padding:32px;text-align:center;">
        <p style="color:var(--danger);margin:0;font-weight:600;">Could not load service pricing</p>
        <small style="color:var(--text-dim);">${K(t?.message||`An unexpected error occurred`)}</small>
      </div>
    `}}function nt(e){return Z(e)}function Y(e,t=`Loading...`){if(!e)return()=>{};let n=e.innerHTML;return e.disabled=!0,e.classList.add(`is-loading`),e.innerHTML=`<span class="btn-spinner"></span><span>${t}</span>`,()=>{e.disabled=!1,e.classList.remove(`is-loading`),e.innerHTML=n}}async function rt(e,t,n){let r=Y(e,`Loading`);try{await kt(t,n)}catch(e){console.error(e),_(`Could not open request details`,`error`)}finally{r()}}function it(){let e=new Date;return`NE-${String(e.getFullYear()).slice(-2)}${String(e.getMonth()+1).padStart(2,`0`)}${String(e.getDate()).padStart(2,`0`)}-${String(Math.floor(1e3+Math.random()*9e3))}`}function at(e){let t=String(e||``).replace(/\D/g,``),n=t.length>10?t.slice(-10):t;return n.length===10?`+91${n}`:null}function ot({desiredAccuracy:e=25,maxWaitMs:t=12e3}={}){return new Promise((n,r)=>{if(!navigator.geolocation)return r(Error(`Geolocation not supported`));let i=null,a=!1,o=navigator.geolocation.watchPosition(t=>{(!i||t.coords.accuracy<i.coords.accuracy)&&(i=t),t.coords.accuracy<=e&&!a&&(a=!0,navigator.geolocation.clearWatch(o),clearTimeout(s),n(i))},e=>{a||(a=!0,navigator.geolocation.clearWatch(o),clearTimeout(s),i?n(i):r(e))},{enableHighAccuracy:!0,timeout:t,maximumAge:0}),s=setTimeout(()=>{a||(a=!0,navigator.geolocation.clearWatch(o),i?n(i):r(Error(`Geolocation timed out`)))},t)})}async function st(e,t){return(await(await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${e}&lon=${t}&zoom=18&addressdetails=1`)).json()).display_name||``}function ct(e,t){return`https://www.google.com/maps?q=${encodeURIComponent(`${e},${t}`)}`}function lt(e){let t=String(e||``).trim();return{value:t.toLowerCase().replace(/[^a-z0-9]+/g,`-`).replace(/^-+|-+$/g,``)||`service`,label:t}}function ut(e,t){if(!e||!t)return null;let n=new Date(t)-new Date(e);return`${Math.floor(n/36e5)}h ${Math.floor(n%36e5/6e4)}m`}function dt(e,t){if(!e||!t)return 0;let n=wt(e),r=wt(t);if(!n||!r)return 0;let i=new Date(`${n}T00:00:00`),a=new Date(`${r}T00:00:00`);return Number.isNaN(i.getTime())||Number.isNaN(a.getTime())||a<i?0:Math.floor((a-i)/864e5)+1}function X(e){return`₹`+Math.round(Number(e)||0).toString().replace(/\B(?=(\d{3})+(?!\d))/g,`,`)}var ft=18,pt=4;function mt(e=new Date){let t=new Date(e);return t.setHours(ft,0,0,0),e>=t}function ht(e){return wt(e?.date||e?.clock_in)}function gt(e,t=new Date().toLocaleDateString(`en-CA`)){return!!(e?.clock_in&&!e?.clock_out&&ht(e)===t&&!mt())}function _t(e,t=new Date().toLocaleDateString(`en-CA`)){return!e?.clock_in||e?.clock_out?!1:ht(e)!==t||mt()}function vt(e=[]){let t=new Map;return e.filter(_t).forEach(e=>{let n=e.user_id||`unknown`;t.has(n)||t.set(n,[]),t.get(n).push(e)}),t}function yt(e){let t=new Date(e?.clock_in||Date.now()).getTime(),n=new Date().toLocaleDateString(`en-CA`),r=new Date(`${e?.date||n}T00:00:00`);r.setHours(ft,0,0,0);let i=r.getTime(),a=e?.date===n?Date.now():Math.max(Number.isFinite(t)?t:i,i);return new Date(a).toISOString()}var bt={pending:`Received`,open:`Received`,assigned:`Assigned`,in_progress:`In Progress`,resolved:`Resolved`,closed:`Resolved`,issue_not_resolved:`Issue Not Resolved`};function xt(e){return e===`closed`?`resolved`:e||`open`}function St(e){let t=xt(e);return`<span class="badge ${t===`resolved`?`badge-resolved`:t===`in_progress`?`badge-in_progress`:t===`assigned`?`badge-assigned`:t===`issue_not_resolved`?`badge-danger`:`badge-open`}">${bt[t]||t}</span>`}function Ct(e,t){return new Date(t.created_at||0)-new Date(e.created_at||0)}function wt(e){if(!e)return``;if(e instanceof Date)return Number.isNaN(e.getTime())?``:e.toLocaleDateString(`en-CA`);let t=String(e).trim(),n=/^(\d{4}-\d{2}-\d{2})/.exec(t);if(n)return n[1];let r=new Date(t.replace(` `,`T`));return Number.isNaN(r.getTime())?``:r.toLocaleDateString(`en-CA`)}function Tt(e,{from:t=``,to:n=``,status:r=`all`}={}){let i=wt(e.created_at);return t&&i&&i<t||n&&i&&i>n?!1:r===`active`?![`resolved`,`closed`].includes(e.status):r===`resolved`?[`resolved`,`closed`].includes(e.status):r===`paid`?e.payment_status===`paid`:r===`unpaid`?e.bill_amount&&e.payment_status!==`paid`:!0}function Et(e,t={}){let n={payment_status:`paid`,payment_received_at:e?.payment_received_at||new Date().toISOString().slice(0,19).replace(`T`,` `),...t};return[`resolved`,`closed`].includes(e?.status)||(n.status=`resolved`),n}async function Dt(e,t={}){let n=Et(e,t),r=[u.from(`inquiries`).update(n).eq(`id`,e.id)];return e.ticket_id&&n.status===`resolved`&&r.push(u.from(`tickets`).update({status:`resolved`}).eq(`id`,e.ticket_id)),(await Promise.all(r)).find(e=>e.error)?.error||null}async function Ot(e){A(e),e._adminDashboardChannel&&=(u.removeChannel(e._adminDashboardChannel),null),e._adminDashboardCleanup&&=(clearInterval(e._adminDashboardCleanup),null);let t=new Date().toLocaleDateString(`en-CA`),n={from:e.dataset.companyFrom||``,to:e.dataset.companyTo||``,status:e.dataset.companyStatus||`all`},r,i,a,o,s,c;try{let e=await Promise.all([u.from(`tickets`).select(`*`).order(`created_at`,{ascending:!1}),u.from(`inquiries`).select(`*`).in(`status`,[`pending`,`open`,`assigned`,`in_progress`]).order(`created_at`,{ascending:!1}),u.from(`attendance`).select(`*, profiles(full_name)`).order(`clock_in`,{ascending:!1}),u.from(`stocks`).select(`*`),u.from(`profiles`).select(`*`),u.from(`complaints`).select(`*`).order(`created_at`,{ascending:!1})]);r=e[0].data,i=e[1].data,a=e[2].data,o=e[3].data,s=e[4].data,c=e[5].data;let t=e.find(e=>e.error)?.error;t&&console.warn(`[Admin] Partial load issue:`,t.message)}catch(t){e.innerHTML=`<div class="card" style="text-align:center;padding:40px;"><h2 style="color:var(--primary);">Initialization Error</h2><p>${t.message}</p></div>`;return}let l=r||[],d=i||[],f=a||[],p=o||[],m=s||[],h=c||[],g=f.filter(e=>gt(e,t)),_=p.filter(e=>e.quantity<=e.min_stock).length,v=new Map,y=new Map;m.forEach(e=>{e.phone&&e.company&&v.set(e.phone,e.company)}),m.forEach(e=>{e.id&&y.set(e.id,e)});let x=[...vt(f).entries()].map(([e,t])=>({userId:e,count:t.length,latest:t.sort((e,t)=>new Date(t.clock_in||0)-new Date(e.clock_in||0))[0],employee:y.get(e)})).sort((e,t)=>t.count-e.count||new Date(t.latest?.clock_in||0)-new Date(e.latest?.clock_in||0)),S=new Set(x.filter(e=>e.count>=pt).map(e=>e.userId));g=g.filter(e=>!S.has(e.user_id));let{data:w}=await u.from(`inquiries`).select(`*`).order(`created_at`,{ascending:!1}),ee=(w||[]).filter(e=>Tt(e,n)),T=new Map;ee.forEach(e=>{let t=e.company_name||v.get(e.phone)||`Walk-in / Unregistered`;T.has(t)||T.set(t,{total:0,active:0,resolved:0});let n=T.get(t);n.total++,[`resolved`,`closed`].includes(e.status)?n.resolved++:n.active++});let E=[...T.entries()].sort((e,t)=>t[1].total-e[1].total).slice(0,10),D=[...d].sort(Ct),O=w||[],te=(w||[]).filter(e=>[`resolved`,`closed`].includes(e.status)).sort(Ct),ne=O.filter(e=>wt(e.created_at)===t).length,re=O.filter(e=>!e.assigned_employee_id&&![`resolved`,`closed`].includes(e.status)).length,ie=O.filter(e=>xt(e.status)===`in_progress`).length,oe=O.filter(e=>[`resolved`,`closed`].includes(e.status)&&wt(e.updated_at||e.bill_generated_at||e.created_at)===t).length,se=O.filter(e=>e.bill_amount&&e.payment_status!==`paid`).length,ce=O.filter(e=>e.payment_method===`cash`&&e.payment_status===`paid`&&e.cash_collected_at&&!e.cash_submitted_at).reduce((e,t)=>e+(Number(t.bill_total)||0),0),le=h.filter(e=>![`resolved`,`closed`].includes(String(e.status||``).toLowerCase())),ue=[...h].sort(Ct).slice(0,5),de=D.filter(e=>!e.assigned_employee_id||[`pending`,`open`].includes(xt(e.status))||e.assignment_status===`declined`).map(e=>({...e,_reason:e.assignment_status===`declined`?`Declined`:e.assigned_employee_id?`Needs update`:`Unassigned`}));e.innerHTML=`    <div class="page-header" style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;">      <div>        <h1>Admin Hub</h1>        <p>Real-time operations monitoring</p>      </div>      <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">        <button class="btn btn-primary" id="admin-dashboard-register">${j.plus}<span>Register Request</span></button>        <button class="btn btn-secondary" id="admin-enable-alerts">Enable Alerts</button>        <button class="btn btn-secondary" id="admin-refresh">Refresh</button>      </div>    </div>    <div class="stats-grid">      <div class="stat-card">        <div class="stat-value" style="color:var(--primary)">${g.length}</div>        <div class="stat-label">Employees In</div>      </div>      <div class="stat-card">        <div class="stat-value" style="color:var(--warning)">${d.length}</div>        <div class="stat-label">Active Service Requests</div>      </div>      <div class="stat-card">        <div class="stat-value" style="color:var(--danger)">${_}</div>        <div class="stat-label">Low Stock</div>      </div>      <div class="stat-card">        <div class="stat-value" style="color:var(--success)">${l.filter(e=>e.status===`open`).length}</div>        <div class="stat-label">Open Tasks</div>      </div>    </div>    <div class="stats-grid" style="margin-top:18px">      <div class="stat-card">        <div class="stat-value" style="color:var(--primary)">${ne}</div>        <div class="stat-label">New Today</div>      </div>      <div class="stat-card">        <div class="stat-value" style="color:var(--warning)">${re}</div>        <div class="stat-label">Pending Assignment</div>      </div>      <div class="stat-card">        <div class="stat-value" style="color:var(--info)">${ie}</div>        <div class="stat-label">In Progress</div>      </div>      <div class="stat-card">        <div class="stat-value" style="color:var(--success)">${oe}</div>        <div class="stat-label">Resolved Today</div>      </div>      <div class="stat-card">        <div class="stat-value" style="color:var(--danger)">${se}</div>        <div class="stat-label">Unpaid Bills</div>      </div>      <div class="stat-card">        <div class="stat-value" style="color:var(--warning);font-size:1.7rem">${X(ce)}</div>        <div class="stat-label">Cash Pending</div>      </div>      <div class="stat-card">        <div class="stat-value" style="color:var(--danger)">${le.length}</div>        <div class="stat-label">Open Complaints</div>      </div>      <div class="stat-card">        <div class="stat-value" style="color:${x.length?`var(--danger)`:`var(--success)`}">${x.length}</div>        <div class="stat-label">Clock-out Warnings</div>      </div>    </div>      ${x.length?`      <div class="card">        <div class="card-header"><span class="card-title">Clock-out Warnings</span></div>        <div class="table-wrap recent-requests-scroll">          <table>            <thead><tr><th>Employee</th><th>Missed</th><th>Last Open Shift</th><th>Action</th></tr></thead>            <tbody>              ${x.slice(0,5).map(e=>`<tr>                <td><b>${Z(e.employee?.full_name||`Employee`)}</b></td>                <td><span class="badge ${e.count>=pt?`badge-danger`:`badge-medium`}">${e.count} day${e.count===1?``:`s`}</span></td>                <td><small>${b(e.latest?.clock_in)}</small></td>                <td>${e.count>=pt?`<span class="badge badge-danger">Strict: block clock-in</span>`:`<span class="badge badge-medium">Warn employee</span>`}</td>              </tr>`).join(``)}            </tbody>          </table>        </div>      </div>`:``}      <!-- Actionable service queue -->      <div class="card">        <div class="card-header"><span class="card-title">Needs Attention</span></div>        <div class="table-wrap recent-requests-scroll">          <table>            <thead><tr><th>Ticket</th><th>Customer</th><th>Reason</th><th></th></tr></thead>            <tbody>              ${de.length===0?`<tr><td colspan="4" style="text-align:center;padding:28px;color:var(--text-dim)">No requests need attention</td></tr>`:de.map(e=>`<tr>                  <td><code style="font-size:0.78rem;color:var(--primary)">${e.ticket_no||`â€”`}</code><br/><small style="color:var(--text-dim)">${b(e.created_at)}</small></td>                  <td><b>${e.full_name}</b><br/><small style="color:var(--text-dim)">${e.company_name||e.service_item||`Service request`}</small></td>                  <td><span class="badge badge-${e._reason===`Declined`?`danger`:`medium`}">${e._reason}</span></td>                  <td><button class="btn btn-primary btn-sm inq-btn" data-id="${e.id}">Manage</button></td>                </tr>`).join(``)}            </tbody>          </table>        </div>      </div>      <!-- Service Requests Card (From Guests) -->      <div class="card">        <div class="card-header"><span class="card-title">Recent Service Requests</span></div>        <div class="table-wrap recent-requests-scroll">          <table>            <thead><tr><th>Ticket</th><th>Customer</th><th>Company</th><th>Status</th><th></th></tr></thead>            <tbody>              ${D.length===0?`<tr><td colspan="5" style="text-align:center;padding:20px;color:var(--text-dim)">No active requests</td></tr>`:D.map(e=>`<tr>                  <td><code style="font-size:0.78rem;color:var(--primary)">${e.ticket_no||`—`}</code><br/><small style="color:var(--text-dim)">${b(e.created_at)}</small></td>                  <td><b>${e.full_name}</b></td>                  <td>${e.company_name?`<b>${e.company_name}</b>`:`<span style="color:var(--text-dim)">—</span>`}</td>                  <td>${St(e.status)}</td>                  <td><button class="btn btn-primary btn-sm inq-btn" data-id="${e.id}">Manage</button></td>                </tr>`).join(``)}            </tbody>          </table>        </div>      </div>      <div class="card">        <div class="card-header"><span class="card-title">Recent Complaints</span></div>        <div class="table-wrap recent-requests-scroll">          <table>            <thead><tr><th>Ticket</th><th>Phone</th><th>Status</th><th></th></tr></thead>            <tbody>              ${ue.length===0?`<tr><td colspan="4" style="text-align:center;padding:20px;color:var(--text-dim)">No complaints yet</td></tr>`:ue.map(e=>`<tr>                  <td><code style="font-size:0.78rem;color:var(--primary)">${Z(e.ticket_no||`-`)}</code><br/><small style="color:var(--text-dim)">${b(e.created_at)}</small></td>                  <td><b>${Z(e.phone||`-`)}</b><br/><small style="color:var(--text-dim);display:block;max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${Z(e.complaint_text||`Complaint`)}</small></td>                  <td>${St(e.status)}</td>                  <td><button class="btn btn-primary btn-sm cmp-dash-btn" data-id="${Z(e.id)}">Respond</button></td>                </tr>`).join(``)}            </tbody>          </table>        </div>      </div>      <div class="card" style="margin-top:24px">        <div class="card-header"><span class="card-title">Resolved Services</span></div>        <div class="table-wrap recent-requests-scroll">        <table>          <thead><tr><th>Ticket</th><th>Service Date</th><th>Company</th><th>Name</th><th>Status</th><th></th></tr></thead>          <tbody>            ${te.length===0?`<tr><td colspan="6" style="text-align:center;padding:20px;color:var(--text-dim)">No resolved services yet</td></tr>`:te.map(e=>`<tr>                  <td><code style="font-size:0.78rem;color:var(--primary)">${e.ticket_no||`â€”`}</code></td>                  <td><small>${b(e.created_at)}</small></td>                  <td>${e.company_name?`<b>${e.company_name}</b>`:`<span style="color:var(--text-dim)">â€”</span>`}</td>                  <td><b>${e.full_name}</b></td>                  <td>${St(e.status)}</td>                  <td><button class="btn btn-primary btn-sm inq-btn" data-id="${e.id}">Manage</button></td>                </tr>`).join(``)}          </tbody>        </table>      </div>    </div>    <div class="card" style="margin-top:24px" id="company-svc-card">      <div class="card-header" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;">        <span class="card-title">${j.building}<span style="margin-left:8px">Services by Company</span></span>        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">          <select id="company-status-filter" style="padding:8px 12px;border-radius:12px;border:1px solid var(--border);background:var(--bg);color:var(--text);font-weight:700;">            <option value="all" ${n.status===`all`?`selected`:``}>All</option>            <option value="active" ${n.status===`active`?`selected`:``}>Active</option>            <option value="resolved" ${n.status===`resolved`?`selected`:``}>Resolved</option>            <option value="paid" ${n.status===`paid`?`selected`:``}>Paid</option>            <option value="unpaid" ${n.status===`unpaid`?`selected`:``}>Unpaid</option>          </select>          <input type="date" id="company-from" value="${n.from}" style="padding:8px 12px;border-radius:12px;border:1px solid var(--border);background:var(--bg);color:var(--text);"/>          <input type="date" id="company-to" value="${n.to}" style="padding:8px 12px;border-radius:12px;border:1px solid var(--border);background:var(--bg);color:var(--text);"/>        <div class="search-input-wrap" style="min-width:160px;max-width:260px;">          <span>??</span>          <input class="search-input" id="company-search" placeholder="Filter company…" style="padding:6px 10px;font-size:0.82rem;"/>        </div>        <button class="btn btn-secondary btn-sm" id="company-export">Export All</button>        <button class="btn btn-secondary btn-sm" id="company-clear-filters">Clear</button>        </div>      </div>      <div class="table-wrap" id="company-table-wrap">        <table id="company-svc-table">          <thead><tr><th>Company</th><th>Total</th><th>Active</th><th>Resolved</th><th></th></tr></thead>          <tbody>            ${E.length===0?`<tr><td colspan="5" style="text-align:center;padding:20px;color:var(--text-dim)">No service data yet</td></tr>`:E.map(([e,t])=>`<tr data-company="${e}">                  <td><b>${e}</b></td>                  <td><span class="badge badge-open">${t.total}</span></td>                  <td style="color:var(--warning);font-weight:700">${t.active}</td>                  <td style="color:var(--success);font-weight:700">${t.resolved}</td>                  <td><button class="btn btn-secondary btn-sm view-company-btn" data-company="${e}" style="white-space:nowrap">View All</button></td>                </tr>`).join(``)}          </tbody>        </table>      </div>    </div>  `;let M=(t,n)=>{let r=e.querySelector(t);r&&(r.onclick=n)};M(`#admin-refresh`,()=>Ot(e)),M(`#admin-dashboard-register`,()=>jt(()=>Ot(e))),M(`#admin-enable-alerts`,async()=>{k({title:`Alerts enabled`,body:await ae()===`granted`?`Live admin alerts will show with sound.`:`In-app alerts will show with sound after browser interaction.`,type:`success`,tag:`admin-alerts-test`})});let N=e.querySelector(`#company-search`);N&&(N.oninput=()=>{let t=N.value.toLowerCase();e.querySelectorAll(`#company-svc-table tbody tr[data-company]`).forEach(e=>{e.style.display=e.dataset.company.toLowerCase().includes(t)?``:`none`})});let P=e.querySelector(`#company-export`);P&&(P.onclick=()=>{let e=(N?.value||``).toLowerCase();C(`services-by-company.csv`,E.filter(([t])=>!e||t.toLowerCase().includes(e)).map(([e,t])=>({company:e,total:t.total,active:t.active,resolved:t.resolved})))});let fe=e.querySelector(`#company-status-filter`),pe=e.querySelector(`#company-from`),F=e.querySelector(`#company-to`),I=()=>{e.dataset.companyStatus=fe?.value||`all`,e.dataset.companyFrom=pe?.value||``,e.dataset.companyTo=F?.value||``,Ot(e)};fe&&(fe.onchange=I),pe&&(pe.onchange=I),F&&(F.onchange=I);let me=e.querySelector(`#company-clear-filters`);me&&(me.onclick=()=>{e.dataset.companyStatus=`all`,e.dataset.companyFrom=``,e.dataset.companyTo=``,Ot(e)});let L=new Map;m.forEach(e=>{e.phone&&e.company&&(L.has(e.company)||L.set(e.company,new Set),L.get(e.company).add(e.phone))}),e.querySelectorAll(`.view-company-btn`).forEach(t=>{t.onclick=async()=>{let r=t.dataset.company,i=r===`Walk-in / Unregistered`?null:[...L.get(r)||[]],a;if(!i){let e=[...v.keys()],{data:t}=await u.from(`inquiries`).select(`*`).order(`created_at`,{ascending:!1});a=(t||[]).filter(t=>!e.includes(t.phone))}else if(i.length>0){let{data:e}=await u.from(`inquiries`).select(`*`).in(`phone`,i).order(`created_at`,{ascending:!1});a=e||[]}else a=[];a=(w||[]).filter(e=>(e.company_name||v.get(e.phone)||`Walk-in / Unregistered`)===r).filter(e=>Tt(e,n)).sort(Ct);let o=document.createElement(`div`);o.className=`modal-overlay`,o.innerHTML=`        <div class="modal" style="max-width:700px">          <div class="modal-header">            <span class="modal-title">${j.building}<span style="margin-left:8px">${r}</span></span>            <button class="modal-close" id="cm-co">?</button>          </div>          <div class="modal-body" style="padding:0">            <div class="table-wrap">              <table>                <thead><tr><th>Ticket</th><th>Service Date</th><th>Customer</th><th>Service</th><th>Status</th><th>Bill</th><th></th></tr></thead>                <tbody>                  ${a.length===0?`<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-dim)">No inquiries found</td></tr>`:a.map(e=>`<tr>                        <td><code style="font-size:0.75rem;color:var(--primary)">${e.ticket_no||`—`}</code></td>                        <td><small>${b(e.created_at)}</small></td>                        <td><b>${e.full_name}</b><br/><small>${e.phone}</small></td>                        <td style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${e.service_item||`—`}</td>                        <td>${St(e.status)}</td>                        <td>${e.bill_amount?`?`+Number(e.bill_amount).toLocaleString(`en-IN`):`—`}</td>                        <td><button class="btn btn-primary btn-sm co-inq-btn" data-id="${e.id}">Manage</button></td>                      </tr>`).join(``)}                </tbody>              </table>            </div>          </div>          <div class="modal-footer">            <button class="btn btn-secondary" id="co-export">Export This Company</button>            <button class="btn btn-secondary" id="cm-co2">Close</button>          </div>        </div>`,document.body.appendChild(o),o.querySelector(`#cm-co`).onclick=o.querySelector(`#cm-co2`).onclick=()=>o.remove(),o.querySelector(`#co-export`).onclick=()=>C(`${r.replace(/[^a-z0-9]+/gi,`-`).toLowerCase()}-services.csv`,a.map(e=>({ticket:e.ticket_no||e.id,service_date:e.created_at||``,company:r,customer:e.full_name||``,phone:e.phone||``,service:e.service_item||``,status:e.status||``,bill_amount:e.bill_amount||``,payment_status:e.payment_status||``,location:e.location||``}))),o.querySelectorAll(`.co-inq-btn`).forEach(t=>{t.onclick=()=>{o.remove(),rt(t,t.dataset.id,()=>Ot(e))}})}}),e.querySelectorAll(`.inq-btn`).forEach(t=>{t.onclick=()=>rt(t,t.dataset.id,()=>Ot(e))}),e.querySelectorAll(`.cmp-dash-btn`).forEach(t=>{t.onclick=()=>nn(h.find(e=>String(e.id)===String(t.dataset.id)),()=>Ot(e))});let he=()=>{document.getElementById(`admin-refresh`)&&Ot(e)},ge=u.channel(`admin-dashboard-live`).on(`postgres_changes`,{event:`INSERT`,schema:`public`,table:`inquiries`},e=>{let t=e.new||{};k({title:`New service request`,body:`${t.ticket_no||`New ticket`} from ${t.full_name||`client`}`,type:`alert`,tag:`new-request-${t.id||Date.now()}`}),he()}).on(`postgres_changes`,{event:`UPDATE`,schema:`public`,table:`inquiries`},e=>{let t=e.new||{};t.payment_status===`paid`?k({title:`?? Payment Received`,body:`${t.full_name||`Client`} paid \u20B9${t.bill_amount||``} for ${t.ticket_no||``}`,type:`payment`,tag:`pay-${t.id||``}`}):t.feedback_rating!=null&&k({title:`? New Feedback`,body:`${t.full_name||`Client`} rated ${t.feedback_rating}/5`,type:`info`,tag:`fb-${t.id||``}`}),he()}).on(`postgres_changes`,{event:`INSERT`,schema:`public`,table:`complaints`},e=>{let t=e.new||{};k({title:`New complaint`,body:`${t.ticket_no||`Ticket`}: ${t.complaint_text||`Customer complaint received`}`,type:`alert`,tag:`complaint-${t.id||Date.now()}`}),he()}).on(`postgres_changes`,{event:`UPDATE`,schema:`public`,table:`complaints`},()=>{he()}).on(`postgres_changes`,{event:`INSERT`,schema:`public`,table:`attendance`},e=>{let t=e.new||{};k({title:`Employee online`,body:`${y.get(t.user_id)?.full_name||`Employee`} clocked in`,type:`success`,tag:`attendance-in-${t.id||t.user_id||Date.now()}`}),he()}).on(`postgres_changes`,{event:`UPDATE`,schema:`public`,table:`attendance`},e=>{let t=e.new||{},n=e.old||{},r=y.get(t.user_id);t.clock_out&&!n.clock_out?k({title:`Employee offline`,body:`${r?.full_name||`Employee`} clocked out`,type:`info`,tag:`attendance-out-${t.id||t.user_id||Date.now()}`}):t.clock_in&&!t.clock_out&&k({title:`Employee online`,body:`${r?.full_name||`Employee`} is online`,type:`success`,tag:`attendance-online-${t.id||t.user_id||Date.now()}`}),he()}).subscribe();e._adminDashboardChannel=ge;let _e=setInterval(()=>{document.body.contains(e)||(u.removeChannel(ge),e._adminDashboardChannel===ge&&(e._adminDashboardChannel=null),e._adminDashboardCleanup===_e&&(e._adminDashboardCleanup=null),clearInterval(_e))},5e3);e._adminDashboardCleanup=_e}async function kt(e,t){let{data:n}=await u.from(`inquiries`).select(`*`).eq(`id`,e).single(),{data:r}=await u.from(`profiles`).select(`*`).eq(`role`,`employee`),i=new Date().toLocaleDateString(`en-CA`),{data:a}=await u.from(`attendance`).select(`user_id,clock_in,clock_out,date`),o=vt(a||[]),s=new Set([...o.entries()].filter(([,e])=>e.length>=pt).map(([e])=>e)),c=new Set((a||[]).filter(e=>gt(e,i)&&!s.has(e.user_id)).map(e=>e.user_id)),l=(r||[]).map(e=>({...e,_clockedIn:c.has(e.id)})),d=(r||[]).find(e=>e.id===n.assigned_employee_id)?.full_name||``,f=!!(n.assigned_employee_id&&n.assignment_status===`pending`),p=!!(n.assigned_employee_id&&n.assignment_status!==`declined`),m=f?`${d||`Assigned technician`} must accept or decline before admin can change this assignment.`:`${d||`This technician`} is already assigned. Reassignment is locked unless the employee declines.`,h=[];if(n.bill_total){let{data:e}=await u.from(`inquiry_services`).select(`service_id, service_pricing(name, category, sub_category, sub_sub_category, cost)`).eq(`inquiry_id`,n.id);h=(e||[]).map(e=>{let t=e.service_pricing||{};return{name:[t.category,t.sub_category,t.sub_sub_category||t.name].filter(Boolean).join(` › `),cost:Number(t.cost)||0}})}let g=Number(n.bill_total)>0,v=document.createElement(`div`);v.className=`modal-overlay`;let y=n.created_at?E(n.created_at):null,x=[`resolved`,`closed`].includes(n.status)?`Service Completed`:y?se(y):`-`;v.innerHTML=`    <div class="modal" style="max-width:560px">      <div class="modal-header">        <span class="modal-title">${j.ticket}<span style="margin-left:8px">Service Request</span></span>        <button class="modal-close" id="ci">${j.close}</button>      </div>      <div class="modal-body">        <div class="sr-meta">          <div class="sr-meta-row">            <div><div class="sr-meta-label">Ticket</div><div class="sr-meta-value sr-mono">${n.ticket_no||`—`}</div></div>            <div><div class="sr-meta-label">Status</div><div>${St(n.status)}</div></div>          </div>          <div class="sr-meta-row">            <div><div class="sr-meta-label">Service Created</div><div class="sr-meta-value">${b(n.created_at)}</div></div>            <div><div class="sr-meta-label">Last Updated</div><div class="sr-meta-value">${b(n.updated_at||n.created_at)}</div></div>          </div>          <div class="sr-meta-row">            <div><div class="sr-meta-label">Name</div><div class="sr-meta-value">${n.full_name}</div></div>            <div><div class="sr-meta-label">Phone</div><div class="sr-meta-value">${n.phone}</div></div>          </div>          <div><div class="sr-meta-label">Service item</div><div class="sr-meta-value">${n.service_item||`—`}</div></div>          ${n.description?`<div><div class="sr-meta-label">Customer description</div><div class="sr-meta-value" style="white-space:pre-wrap;line-height:1.45;">${Z(n.description)}</div></div>`:``}          <div><div class="sr-meta-label">Location</div><div class="sr-meta-value">${n.location||`—`}</div></div>          <div class="sr-meta-row">            <div><div class="sr-meta-label">Preferred Time</div><div class="sr-meta-value">${n.preferred_time||`Flexible`}</div></div>            <div><div class="sr-meta-label">SLA Deadline</div><div class="sr-meta-value">${x}</div></div>          </div>          ${n.company_name?`<div><div class="sr-meta-label">Company</div><div class="sr-meta-value">${n.company_name}</div></div>`:``}          ${n.customer_lat!=null&&n.customer_lng!=null?`            <a href="${ct(n.customer_lat,n.customer_lng)}" target="_blank" rel="noopener" class="btn btn-secondary btn-sm" style="display:inline-flex;align-items:center;justify-content:center;gap:8px;margin-top:8px;text-decoration:none;">              ${j.pin}<span>Open exact client pin</span>            </a>`:``}          ${n.device_type||n.device_serial_no?`            <div class="sr-meta-row">              <div><div class="sr-meta-label">Device Type</div><div class="sr-meta-value">${n.device_type||`—`}</div></div>              <div><div class="sr-meta-label">Serial No</div><div class="sr-meta-value sr-mono">${n.device_serial_no||`—`}</div></div>            </div>`:``}          <div class="sr-meta-row">            <div><div class="sr-meta-label">Preferred Time</div><div class="sr-meta-value" style="color:var(--primary)">${n.preferred_time||`Flexible`}</div></div>            <div><div class="sr-meta-label">SLA Timer</div><div class="sr-meta-value">${oe(E(n.created_at))}</div></div>          </div>          ${n.extra_cost>0?`            <div style="padding:12px; border-radius:12px; background:rgba(16,185,129,0.05); border:1px solid var(--primary); margin-top:10px;">              <div class="sr-meta-label">Additional Charges</div>              <div class="sr-meta-value">\u20B9${n.extra_cost} - <span style="font-size:0.8rem">${n.extra_cost_reason||`No reason`}</span></div>            </div>`:``}          ${n.assignment_status===`declined`?`            <div style="padding:12px;border-radius:12px;background:rgba(239,68,68,0.1);border:1px solid var(--danger);margin-top:10px;">              <div class="sr-meta-label" style="color:var(--danger)">Employee Declined</div>              <div class="sr-meta-value" style="font-size:0.85rem">${n.decline_reason||`No reason provided`}</div>            </div>`:``}          ${p?`            <div style="padding:12px;border-radius:12px;background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.35);margin-top:10px;">              <div class="sr-meta-label" style="color:var(--warning)">${f?`Waiting for employee response`:`Assignment locked`}</div>              <div class="sr-meta-value" style="font-size:0.85rem">${m}</div>            </div>`:``}          ${n.feedback_rating?`            <div class="sr-fb-shown">              ${j.star}              <div>                <div class="sr-meta-label">Customer feedback (${n.feedback_rating}/5)</div>                <div class="sr-meta-value">${n.feedback_comment||`No comment.`}</div>              </div>            </div>`:``}        </div>        ${g?`          <div class="bill-breakdown" style="margin-bottom:16px; background:#f8fafc; padding:15px; border-radius:12px; border:1px solid #eef2f7;">            <div style="font-size:0.7rem; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.05em; margin-bottom:10px;">Generated Bill Detail</div>            <div class="bill-row" style="display:flex; justify-content:space-between; font-size:0.85rem; margin-bottom:4px;"><span>Services subtotal</span><b style="color:#0f172a;">${X(n.bill_amount)}</b></div>            <div class="bill-row" style="display:flex; justify-content:space-between; font-size:0.85rem; margin-bottom:4px;"><span>Platform fee</span><b style="color:#0f172a;">${X(n.platform_fee)}</b></div>            <div class="bill-row" style="display:flex; justify-content:space-between; font-size:0.85rem; margin-bottom:4px;"><span>Transport (${Number(n.transport_km||0).toFixed(1)} km)</span><b style="color:#0f172a;">${X(n.transport_fee)}</b></div>            ${Number(n.discount_amount)>0?`<div class="bill-row" style="display:flex; justify-content:space-between; font-size:0.85rem; margin-bottom:4px; color:#059669;"><span>Loyalty discount</span><b>-${X(n.discount_amount)}</b></div>`:``}            <div class="bill-row" style="display:flex; justify-content:space-between; font-size:0.85rem; margin-bottom:4px;"><span>GST (18%)</span><b style="color:#0f172a;">${X(n.gst_amount)}</b></div>            <div class="bill-row" style="display:flex; justify-content:space-between; font-size:0.95rem; margin-top:8px; padding-top:8px; border-top:1px solid #e2e8f0; font-weight:800; color:#10b981;"><span>Total Payable</span><b>${X(n.bill_total)}</b></div>            <button type="button" class="btn btn-primary btn-wide" id="view-bill-btn" style="margin-top:12px; background:#10b981; border:none; box-shadow:0 4px 12px rgba(16,185,129,0.2);">?? View & Download Premium Bill</button>          </div>`:``}        <div class="form-group">          <label>Assign to Technician</label>          <select id="assign-to" ${p?`disabled`:``}>            <option value="">— None —</option>            ${l.map(e=>`<option value="${e.id}" ${n.assigned_employee_id===e.id?`selected`:``} ${e._clockedIn?``:`disabled`}>${e._clockedIn?`Online`:s.has(e.id)?`Restricted`:`Offline`} - ${e.full_name}</option>`).join(``)}          </select>          <small style="display:block;margin-top:8px;color:var(--text-dim);font-size:0.78rem;">${p?`Already assigned. Save is disabled to prevent duplicate assignment.`:`Only currently clocked-in employees with no strict clock-out restriction can receive new assignments.`}</small>        </div>      </div>      <div class="modal-footer">        <button class="btn btn-secondary" id="ci2">Close</button>        <button class="btn btn-primary" id="save-sr" ${p?`disabled`:``}>${j.check}<span>${p?`Already assigned`:`Save assignment`}</span></button>      </div>    </div>`,document.body.appendChild(v),v.querySelector(`#ci`).onclick=v.querySelector(`#ci2`).onclick=()=>v.remove(),g&&(v.querySelector(`#view-bill-btn`).onclick=()=>{let e=Math.max(0,Number(n.bill_amount||0)-Number(n.extra_cost||0));Oe({customer:{name:n.full_name,phone:n.phone,location:n.location,company:n.company_name,device_type:n.device_type,device_serial:n.device_serial_no,service_item:n.service_item,ticket_no:n.ticket_no},technician:d,services:h,servicesSubtotal:e,extra:Number(n.extra_cost)||0,extraReason:n.extra_cost_reason||``,platform:Number(n.platform_fee)||0,km:Number(n.transport_km)||0,transport:Number(n.transport_fee)||0,discount:Number(n.discount_amount)||0,taxable:e+Number(n.extra_cost||0)+Number(n.platform_fee||0)+Number(n.transport_fee||0)-Number(n.discount_amount||0),gst:Number(n.gst_amount)||0,total:Number(n.bill_total)||0,paymentLink:n.payment_link||``},{allowShare:!1,title:`?? Bill (Sent to Client)`})}),v.querySelector(`#save-sr`).onclick=async()=>{if(p){_(`This request is already assigned. It can only be reassigned if the employee declines it.`,`warning`);return}let e=v.querySelector(`#assign-to`).value;if(e&&!c.has(e)){_(`This employee is not clocked in. Please choose an active technician.`,`warning`);return}let r=v.querySelector(`#save-sr`);r.disabled=!0,r.innerHTML=`<span>Saving…</span>`;let i={assigned_employee_id:e||null};if(e&&n.assigned_employee_id!==e?(i.assignment_status=`pending`,i.decline_reason=null):e||(i.assignment_status=null),e&&!n.ticket_id){let{data:t}=await u.from(`profiles`).select(`id`).eq(`phone`,n.phone).maybeSingle(),{data:a,error:o}=await u.from(`tickets`).insert({title:`Service: ${(n.service_item||``).slice(0,30)}`,description:`Ticket ${n.ticket_no||``} from ${n.full_name} (${n.phone}). ${n.service_item||``}${n.description?`\n\nCustomer says: ${n.description}`:``}`,assigned_to:e,client_id:t?t.id:null,status:`assigned`,category:`service_request`}).select().single();if(o){_(o.message,`error`),r.disabled=!1,r.innerHTML=`${j.check}<span>Save assignment</span>`;return}i.ticket_id=a.id,i.status=`assigned`}else e&&n.ticket_id&&(await u.from(`tickets`).update({assigned_to:e,status:`assigned`}).eq(`id`,n.ticket_id),i.status=`assigned`);let{error:a}=await u.from(`inquiries`).update(i).eq(`id`,n.id);if(a){_(a.message,`error`),r.disabled=!1,r.innerHTML=`${j.check}<span>Save assignment</span>`;return}_(`Technician assigned`,`success`),v.remove(),t()}}async function At(e){A(e);let{data:t}=await u.from(`attendance`).select(`*, profiles(full_name)`).order(`date`,{ascending:!1}),n=t||[],r=new Date().toLocaleDateString(`en-CA`),i=n.filter(e=>e.date===r),a=n.filter(e=>gt(e,r)),o=n.filter(e=>_t(e,r)),s=vt(n),c=[...s.entries()].filter(([,e])=>e.length>=pt).map(([e,t])=>({userId:e,rows:t.sort((e,t)=>new Date(t.clock_in||0)-new Date(e.clock_in||0)),name:t[0]?.profiles?.full_name||`Employee`})).sort((e,t)=>t.rows.length-e.rows.length||e.name.localeCompare(t.name)),l=i.filter(e=>e.clock_in&&e.clock_out),d=l.length?l.reduce((e,t)=>e+(new Date(t.clock_out)-new Date(t.clock_in)),0)/l.length/6e4:0,f=d?`${Math.floor(d/60)}h ${Math.round(d%60)}m`:`—`,p=e=>e.length===0?`<tr><td colspan="6" style="text-align:center;padding:32px;color:var(--text-dim)">No records found</td></tr>`:e.map(e=>{let t=ut(e.clock_in,e.clock_out);return`<tr>          <td>${y(e.date)}</td>          <td><b>${e.profiles?.full_name||`—`}</b></td>          <td><span class="badge badge-open">${x(e.clock_in)}</span></td>          <td>${e.clock_out?`<span class="badge badge-resolved">${x(e.clock_out)}</span>`:_t(e,r)?`<span class="badge badge-danger">Forgot clock-out</span>`:`<span class="badge badge-open">Active</span>`}</td>          <td>${t?`<span style="font-weight:600;color:var(--primary)">${t}</span>`:`<span style="color:var(--text-dim)">—</span>`}</td>          <td><small>${e.location||`—`}</small></td>        </tr>`}).join(``);e.innerHTML=`    <div class="page-header" style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;">      <div>        <h1>Attendance Logs</h1>        <p>Track employee check-ins and locations</p>      </div>      <button class="btn btn-secondary" id="att-export">${j.clipboard}<span>Export CSV</span></button>    </div>    <div class="stats-grid" style="margin-bottom:24px">      <div class="stat-card">        <div class="stat-value" style="color:var(--primary)">${i.length}</div>        <div class="stat-label">Today's Attendance</div>      </div>      <div class="stat-card">        <div class="stat-value" style="color:var(--success)">${a.length}</div>        <div class="stat-label">Currently Active</div>      </div>      <div class="stat-card">        <div class="stat-value" style="color:${o.length?`var(--danger)`:`var(--success)`}">${o.length}</div>        <div class="stat-label">Forgot Clock-out</div>      </div>      <div class="stat-card">        <div class="stat-value" style="color:${c.length?`var(--danger)`:`var(--success)`}">${c.length}</div>        <div class="stat-label">Restricted Users</div>      </div>      <div class="stat-card">        <div class="stat-value" style="color:var(--warning);font-size:1.6rem">${f}</div>        <div class="stat-label">Avg Hours Today</div>      </div>    </div>    ${c.length?`      <div class="card" style="margin-bottom:24px;border:1px solid rgba(239,68,68,0.35);">        <div class="card-header">          <span class="card-title sr-icon-title">${j.alert}<span>Clock-in Restrictions</span></span>        </div>        <div class="card-body">          <div class="table-wrap">            <table>              <thead><tr><th>Employee</th><th>Missed Clock-outs</th><th>Latest Missed</th><th>Action</th></tr></thead>              <tbody>                ${c.map(e=>`                  <tr>                    <td><b>${Z(e.name)}</b></td>                    <td><span class="badge badge-danger">${e.rows.length}</span></td>                    <td><small>${b(e.rows[0]?.clock_in)}</small></td>                    <td><button class="btn btn-primary btn-sm resolve-attendance-restriction" data-user-id="${Z(e.userId)}">Resolve restriction</button></td>                  </tr>                `).join(``)}              </tbody>            </table>          </div>        </div>      </div>    `:``}    <div class="filter-bar" style="margin-bottom:24px; display:flex; gap:12px; flex-wrap:wrap;">      <div class="search-input-wrap" style="flex:1; min-width:200px;">        <span>??</span>        <input class="search-input" id="att-search" placeholder="Filter by employee name..."/>      </div>      <input type="date" id="att-date" style="padding:10px 16px; border-radius:12px; border:1px solid var(--border); background:var(--bg3); color:var(--text);"/>      <button class="btn btn-secondary" id="att-clear">Clear</button>    </div>    <div class="card">      <div class="table-wrap">        <table>          <thead><tr><th>Date</th><th>Employee</th><th>Clock In</th><th>Clock Out</th><th>Hours Worked</th><th>Location</th></tr></thead>          <tbody id="attendance-log-rows">${p(n)}</tbody>        </table>      </div>    </div>  `;let m=e.querySelector(`#att-search`),h=e.querySelector(`#att-date`),g=()=>{let t=m.value.toLowerCase(),r=h.value,i=n.filter(e=>{let n=(e.profiles?.full_name||``).toLowerCase().includes(t),i=!r||e.date===r;return n&&i});e.querySelector(`#attendance-log-rows`).innerHTML=p(i)};m.oninput=g,h.onchange=g,e.querySelector(`#att-clear`).onclick=()=>At(e),e.querySelectorAll(`.resolve-attendance-restriction`).forEach(t=>{t.onclick=async()=>{let n=s.get(t.dataset.userId)||[];if(!n.length){_(`No unresolved missed clock-outs found`,`info`),At(e);return}let r=Y(t,`Resolving`),i=await Promise.all(n.map(e=>u.from(`attendance`).update({clock_out:yt(e)}).eq(`id`,e.id)));r();let a=i.find(e=>e.error)?.error;if(a){_(a.message||`Could not resolve restriction`,`error`);return}_(`Restriction resolved`,`success`),At(e)}}),e.querySelector(`#att-export`).onclick=()=>{C(`attendance.csv`,n.map(e=>({date:e.date,employee:e.profiles?.full_name||``,clock_in:x(e.clock_in),clock_out:e.clock_out?x(e.clock_out):`Active`,hours_worked:ut(e.clock_in,e.clock_out)||``,location:e.location||``})))}}async function jt(e){let t=new Date().toLocaleDateString(`en-CA`),[{data:n},{data:r},{data:i}]=await Promise.all([u.from(`profiles`).select(`id, full_name, phone`).eq(`role`,`employee`),u.from(`service_pricing`).select(`category`).order(`category`),u.from(`attendance`).select(`user_id,clock_in,clock_out,date`)]),a=vt(i||[]),o=new Set([...a.entries()].filter(([,e])=>e.length>=pt).map(([e])=>e)),s=new Set((i||[]).filter(e=>gt(e,t)&&!o.has(e.user_id)).map(e=>e.user_id)),c=(n||[]).filter(e=>s.has(e.id)),l=new Map;(r||[]).forEach(e=>{let t=String(e.category||``).trim();if(!t||[`uncategorized`,`other`].includes(t.toLowerCase()))return;let n=lt(t);l.has(n.value)||l.set(n.value,n)});let d=l.size?[...l.values()]:[{value:`camera-offline`,label:`Camera offline`},{value:`software-issue`,label:`Software issue`},{value:`new-installation`,label:`New installation`}],f=document.createElement(`div`);f.className=`modal-overlay`,f.innerHTML=`    <div class="modal" style="max-width:620px">      <div class="modal-header">        <span class="modal-title">Register Service Request</span>        <button class="modal-close" id="admin-request-close">×</button>      </div>      <div class="modal-body">        <div style="padding:12px 14px;border-radius:12px;background:rgba(16,185,129,0.08);border:1px solid rgba(16,185,129,0.18);color:var(--text-soft);font-size:0.84rem;line-height:1.45;margin-bottom:16px;">          This creates the ticket directly. No OTP is sent. The customer will receive the ticket confirmation SMS, and the assigned employee will receive the job SMS if you assign one.        </div>        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;">          <div class="form-group">            <label>Customer Name</label>            <input id="ar-name" type="text" placeholder="Customer name" />          </div>          <div class="form-group">            <label>Phone</label>            <input id="ar-phone" type="tel" placeholder="10 digit mobile number" />          </div>          <div class="form-group">            <label>Company <span style="color:var(--text-dim);font-weight:500;">(optional)</span></label>            <input id="ar-company" type="text" placeholder="Company / building name" />          </div>          <div class="form-group">            <label>Preferred Time</label>            <select id="ar-time">              <option value="As soon as possible">As soon as possible</option>              <option value="Morning (10 AM - 1 PM)">Morning (10 AM - 1 PM)</option>              <option value="Afternoon (1 PM - 4 PM)">Afternoon (1 PM - 4 PM)</option>              <option value="Evening (4 PM - 6 PM)">Evening (4 PM - 6 PM)</option>              <option value="Tomorrow Morning">Tomorrow Morning</option>              <option value="Flexible">Flexible</option>            </select>          </div>          <div class="form-group">            <label>Issue</label>            <select id="ar-issue">              <option value="">Select issue</option>              ${d.map(e=>`<option value="${Z(e.value)}">${Z(e.label)}</option>`).join(``)}              <option value="other">Other</option>            </select>          </div>          <div class="form-group" id="ar-other-wrap" style="display:none;">            <label>Other Issue</label>            <input id="ar-other" type="text" placeholder="Describe issue" />          </div>          <div class="form-group">            <label>Assign Employee <span style="color:var(--text-dim);font-weight:500;">(optional)</span></label>            <select id="ar-employee">              <option value="">Create unassigned</option>              ${c.length?c.map(e=>`<option value="${Z(e.id)}">Online - ${Z(e.full_name||`Employee`)}${e.phone?` - ${Z(e.phone)}`:``}</option>`).join(``):`<option value="" disabled>No employees online</option>`}            </select>            <small style="display:block;margin-top:8px;color:var(--text-dim);font-size:0.78rem;">Only employees currently clocked in with no strict clock-out restriction can be assigned.</small>          </div>          <div class="form-group">            <label>Device Bill No <span style="color:var(--text-dim);font-weight:500;">(optional)</span></label>            <input id="ar-bill" type="text" placeholder="Invoice / bill no" />          </div>        </div>        <div class="form-group">          <label>Location</label>          <div style="display:flex;gap:8px;align-items:flex-start;">            <textarea id="ar-location" rows="3" placeholder="Customer address / landmark" style="flex:1;"></textarea>            <button type="button" class="btn btn-secondary" id="ar-detect-gps" title="Detect exact client coordinates" style="height:42px;padding:0 12px;display:flex;align-items:center;justify-content:center;">              ${j.pin}            </button>          </div>          <small id="ar-coords-display" style="display:block;margin-top:6px;color:var(--text-dim);font-size:0.78rem;"></small>        </div>        <div class="form-group">          <label>Description <span style="color:var(--text-dim);font-weight:500;">(optional)</span></label>          <textarea id="ar-description" rows="3" placeholder="Any extra details from the customer"></textarea>        </div>      </div>      <div class="modal-footer">        <button class="btn btn-secondary" id="ar-cancel">Cancel</button>        <button class="btn btn-primary" id="ar-submit">${j.plus}<span>Create Request</span></button>      </div>    </div>  `,document.body.appendChild(f);let p=()=>f.remove();f.querySelector(`#admin-request-close`).onclick=p,f.querySelector(`#ar-cancel`).onclick=p,f.onclick=e=>{e.target===f&&p()};let m=f.querySelector(`#ar-issue`),h=f.querySelector(`#ar-other-wrap`);m.onchange=()=>{h.style.display=m.value===`other`?``:`none`};let g=null,v=f.querySelector(`#ar-detect-gps`),y=f.querySelector(`#ar-location`),b=f.querySelector(`#ar-coords-display`);v.onclick=async()=>{let e=Y(v,`GPS`);try{let{latitude:e,longitude:t,accuracy:n}=(await ot()).coords;g={lat:e,lng:t,accuracy:n},b.innerHTML=`Exact pin saved: <a href="${ct(e,t)}" target="_blank" rel="noopener" style="color:var(--primary);text-decoration:none;">${e.toFixed(6)}, ${t.toFixed(6)}</a> (${Math.round(n)}m accuracy)`;try{y.value=await st(e,t)||`GPS: ${e.toFixed(6)}, ${t.toFixed(6)}`}catch{y.value=`GPS: ${e.toFixed(6)}, ${t.toFixed(6)}`}_(`Exact client coordinates captured`,`success`)}catch(e){console.error(`Admin GPS capture failed:`,e),_(`Could not detect GPS. Check browser location permission.`,`error`)}finally{e()}},f.querySelector(`#ar-submit`).onclick=async()=>{let t=Y(f.querySelector(`#ar-submit`),`Creating`);try{let t=f.querySelector(`#ar-name`).value.trim(),n=at(f.querySelector(`#ar-phone`).value),r=f.querySelector(`#ar-company`).value.trim(),i=f.querySelector(`#ar-time`).value,a=m.value,o=d.find(e=>e.value===a)?.label||``,c=f.querySelector(`#ar-other`)?.value.trim()||``,l=f.querySelector(`#ar-employee`).value,h=f.querySelector(`#ar-location`).value.trim(),v=f.querySelector(`#ar-description`).value.trim(),y=f.querySelector(`#ar-bill`).value.trim();if(!t)return _(`Customer name is required`,`error`);if(!n)return _(`Enter a valid 10 digit phone number`,`error`);if(!h)return _(`Location is required`,`error`);if(!a)return _(`Select the issue`,`error`);if(a===`other`&&!c)return _(`Describe the issue`,`error`);if(l&&!s.has(l))return _(`This employee is not online. Choose an online employee or create unassigned.`,`warning`);let b=crypto.randomUUID(),x=it(),S=a===`other`?`Other: ${c}`:o,{error:C}=await u.from(`inquiries`).insert({id:b,full_name:t,phone:n,company_name:r||null,location:h,customer_lat:g?.lat??null,customer_lng:g?.lng??null,bill_no:y||null,service_item:S,description:v||null,ticket_no:x,preferred_time:i,status:`open`,assignment_status:`none`});if(C)throw Error(C.message||`Could not create request`);if(l){let{error:e}=await u.from(`inquiries`).update({assigned_employee_id:l,assignment_status:`pending`,decline_reason:null}).eq(`id`,b);if(e)throw Error(e.message||`Request created, but assignment failed`)}_(`Request ${x} created`,`success`),p(),e&&e()}catch(e){console.error(e),_(e.message||`Could not create request`,`error`)}finally{t()}}}async function Mt(e){A(e);let t=e.dataset.srFilter===`closed`?`resolved`:e.dataset.srFilter||`active`,n=e.dataset.srCompany||``,[{data:r,error:i},{data:a}]=await Promise.all([u.from(`inquiries`).select(`*`).order(`created_at`,{ascending:!1}),u.from(`profiles`).select(`id, full_name`).eq(`role`,`employee`)]);i&&console.warn(`[Admin] inquiries load:`,i.message);let o=new Map((a||[]).map(e=>[e.id,e.full_name])),s=r||[],c={all:s.length,active:s.filter(e=>![`resolved`,`closed`].includes(e.status)).length,resolved:s.filter(e=>[`resolved`,`closed`].includes(e.status)).length,paid:s.filter(e=>e.payment_status===`paid`).length,unpaid:s.filter(e=>e.bill_amount&&e.payment_status!==`paid`).length},l=s.filter(e=>t===`all`?!0:t===`active`?![`resolved`,`closed`].includes(e.status):t===`resolved`?[`resolved`,`closed`].includes(e.status):t===`paid`?e.payment_status===`paid`:t===`unpaid`?e.bill_amount&&e.payment_status!==`paid`:!0).filter(e=>(e.company_name||``).toLowerCase().includes(n.toLowerCase()));if(e.innerHTML=`    <div class="page-header" style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;">      <div>        <h1>Service Requests</h1>        <p>Manage customer service requests, billing and payments</p>      </div>      <div style="display:flex;gap:10px;flex-wrap:wrap;">        <button class="btn btn-primary" id="sr-new">${j.plus}<span>Register Request</span></button>        <button class="btn btn-secondary" id="sr-export">${j.clipboard}<span>Export</span></button>        <button class="btn btn-secondary" id="sr-refresh">${j.refresh}<span>Refresh</span></button>      </div>    </div>    <div class="sr-filter-bar">      ${[[`active`,`Active`],[`resolved`,`Resolved`],[`unpaid`,`Awaiting Payment`],[`paid`,`Paid`],[`all`,`All`]].map(([e,n])=>`        <button class="sr-filter ${e===t?`active`:``}" data-key="${e}">          <span>${n}</span><span class="sr-filter-count">${c[e]}</span>        </button>      `).join(``)}    </div>    <div class="filter-bar" style="margin-bottom:24px; display:flex; gap:12px; flex-wrap:wrap; align-items:center;">      <div class="search-input-wrap" style="flex:1; min-width:220px;">        <span>${j.search}</span>        <input class="search-input" id="sr-company-filter" placeholder="Filter by company..." value="${n}"/>      </div>      <button class="btn btn-secondary" id="sr-company-clear">Clear Company</button>    </div>    <div class="card">      <div class="table-wrap">        <table>          <thead>            <tr>              <th>Ticket</th><th>Service Date</th><th>Company</th><th>Customer</th><th>Phone</th><th>Service</th>              <th>Assigned Employee</th><th>Status</th><th>Payment</th><th></th>            </tr>          </thead>          <tbody>            ${l.length===0?`<tr><td colspan="10" style="text-align:center;padding:32px;color:var(--text-dim)">No requests in this view</td></tr>`:l.map(e=>`<tr>                  <td><code style="font-size:0.78rem;color:var(--primary)">${e.ticket_no||e.id.slice(0,8)}</code></td>                  <td><small>${b(e.created_at)}</small></td>                  <td>${e.company_name?`<b>${e.company_name}</b>`:`<span style="color:var(--text-dim)">—</span>`}</td>                  <td><b>${e.full_name}</b></td>                  <td><small style="color:var(--text-dim)">${e.phone||`—`}</small></td>                  <td style="max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${e.service_item||`—`}</td>                  <td>${e.assigned_employee_id?`<b>${o.get(e.assigned_employee_id)||`Assigned`}</b>`:`<span style="color:var(--text-dim)">Unassigned</span>`}</td>                  <td>${St(e.status)}</td>                  <td>${e.bill_amount?e.payment_status===`paid`?`<span class="badge badge-resolved">Paid</span>`:`<span class="badge badge-medium">Unpaid</span>`:`<span style="color:var(--text-dim)">—</span>`}</td>                  <td><button class="btn btn-primary btn-sm inq-btn" data-id="${e.id}">Manage</button></td>                </tr>`).join(``)}          </tbody>        </table>      </div>    </div>  `,e.querySelector(`#sr-refresh`).onclick=()=>Mt(e),e.querySelector(`#sr-new`).onclick=()=>jt(()=>Mt(e)),e.querySelector(`#sr-company-filter`).oninput=t=>{e.dataset.srCompany=t.target.value.trim(),Mt(e)},e.querySelector(`#sr-company-clear`).onclick=()=>{e.dataset.srCompany=``,Mt(e)},e.querySelector(`#sr-export`).onclick=()=>{C(`service-requests.csv`,l.map(e=>({ticket:e.ticket_no||e.id,service_date:e.created_at,company:e.company_name||``,customer:e.full_name,phone:e.phone,service:e.service_item||``,assigned_employee:e.assigned_employee_id?o.get(e.assigned_employee_id)||`Assigned`:`Unassigned`,status:e.status,bill_amount:e.bill_amount||``,payment_status:e.payment_status||``,location:e.location||``})))},n){let t=e.querySelector(`#sr-company-filter`);t.focus(),t.setSelectionRange(t.value.length,t.value.length)}e.querySelectorAll(`.sr-filter`).forEach(t=>{t.onclick=()=>{e.dataset.srFilter=t.dataset.key,Mt(e)}}),e.querySelectorAll(`.inq-btn`).forEach(t=>{t.onclick=()=>rt(t,t.dataset.id,()=>Mt(e))})}async function Nt(e){A(e);let{data:t}=await u.from(`eod_reports`).select(`*, profiles(full_name)`).order(`date`,{ascending:!1}),n=t||[],r=t=>{e.innerHTML=`      <div class="page-header">        <h1>Daily Summaries</h1>        <p>End-of-day progress reports from staff</p>      </div>      <div class="filter-bar" style="margin-bottom:24px; display:flex; gap:12px; flex-wrap:wrap;">        <div class="search-input-wrap" style="flex:1; min-width:200px;">          <span>??</span>          <input class="search-input" id="eod-search" placeholder="Filter by staff name..."/>        </div>        <input type="date" id="eod-date" style="padding:10px 16px; border-radius:12px; border:1px solid var(--border); background:var(--bg3); color:var(--text);"/>        <button class="btn btn-secondary" id="eod-clear">Clear</button>      </div>      <div class="card">        <div class="table-wrap">          <table>            <thead><tr><th>Date</th><th>Staff</th><th>Summary</th></tr></thead>            <tbody>              ${t.length===0?`<tr><td colspan="3" style="text-align:center;padding:32px;color:var(--text-dim)">No reports found</td></tr>`:t.map(e=>`<tr>                <td>${y(e.date)}</td>                <td><b>${e.profiles?.full_name||`—`}</b></td>                <td style="max-width:400px;font-size:.9rem; line-height:1.5; padding:16px 8px;">${e.content}</td>              </tr>`).join(``)}            </tbody>          </table>        </div>      </div>    `;let r=e.querySelector(`#eod-search`),a=e.querySelector(`#eod-date`),o=()=>{let e=r.value.toLowerCase(),t=a.value;i(n.filter(n=>{let r=(n.profiles?.full_name||``).toLowerCase().includes(e),i=!t||n.date===t;return r&&i}))};r.oninput=o,a.onchange=o,e.querySelector(`#eod-clear`).onclick=()=>Nt(e)},i=t=>{let n=e.querySelector(`tbody`);n.innerHTML=t.length===0?`<tr><td colspan="3" style="text-align:center;padding:32px;color:var(--text-dim)">No reports found</td></tr>`:t.map(e=>`<tr>      <td>${y(e.date)}</td>      <td><b>${e.profiles?.full_name||`—`}</b></td>      <td style="max-width:400px;font-size:.9rem; line-height:1.5; padding:16px 8px;">${e.content}</td>    </tr>`).join(``)};r(n)}async function Pt(e){A(e);let{data:t}=await u.from(`tickets`).select(`*, inquiries(*)`).order(`created_at`,{ascending:!1}),{data:n}=await u.from(`profiles`).select(`id, full_name`),r=(n||[]).reduce((e,t)=>({...e,[t.id]:t.full_name}),{});e.innerHTML=`    <div class="page-header">      <h1>All Tickets & Tasks</h1>      <p>Master list of all service requests and internal tasks</p>    </div>    <div class="card">      <div class="table-wrap">        <table>          <thead>            <tr>              <th>Ticket ID</th>              <th>Customer</th>              <th>Contact</th>              <th>Assigned To</th>              <th>Status</th>              <th>Created</th>              <th>Action</th>            </tr>          </thead>          <tbody>            ${(t||[]).map(e=>{let t=Array.isArray(e.inquiries)?e.inquiries[0]:e.inquiries,n=t?`<small>${t.phone||`—`}<br/>${t.location?t.location.slice(0,20)+`...`:`—`}</small>`:`—`,i=t?.id?`<button class="btn btn-primary btn-sm all-ticket-manage" data-id="${t.id}">Manage</button>`:`<span style="color:var(--text-dim);font-size:0.8rem;">No request</span>`;return`<tr>      <td><code style="font-size:0.75rem;">#${e.id.slice(0,8)}</code></td>      <td><b>${t?t.full_name:`Guest`}</b></td>      <td>${n}</td>      <td>${e.assigned_to?r[e.assigned_to]||`Staff`:`<span style="color:var(--text-dim)">Unassigned</span>`}</td>      <td>${St(e.status)}</td>      <td><small>${y(e.created_at)}</small></td>      <td>${i}</td>    </tr>`}).join(``)||`<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-dim)">No tickets found</td></tr>`}                      </tbody>        </table>      </div>    </div>  `,e.querySelectorAll(`.all-ticket-manage`).forEach(t=>{t.onclick=()=>rt(t,t.dataset.id,()=>Pt(e))})}async function Ft(e){A(e);let{data:t}=await u.from(`leave_requests`).select(`*, profiles(full_name)`).order(`created_at`,{ascending:!1}),n=t||[];e.innerHTML=`    <div class="page-header">      <h1>Leave Requests</h1>      <p>Approve or reject employee time-off requests</p>    </div>    <div class="card">      <div class="table-wrap">        <table>          <thead>            <tr>              <th>Employee</th>              <th>Dates</th>              <th>Reason</th>              <th>Status</th>              <th>Actions</th>            </tr>          </thead>          <tbody>            ${n.length===0?`<tr><td colspan="5" style="text-align:center;padding:32px;color:var(--text-dim)">No leave requests found</td></tr>`:n.map(e=>`              <tr>                <td><b>${e.profiles?.full_name||`—`}</b></td>                <td><small>${y(e.start_date)} to ${y(e.end_date)}</small></td>                <td style="max-width:200px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap" title="${e.reason}">${e.reason}</td>                <td><span class="badge badge-${e.status}">${e.status}</span></td>                <td>                  ${e.status===`pending`?`                    <div style="display:flex; gap:8px;">                      <button class="btn btn-primary btn-sm leave-act" data-id="${e.id}" data-status="approved">Approve</button>                      <button class="btn btn-danger btn-sm leave-act" data-id="${e.id}" data-status="rejected">Reject</button>                    </div>                  `:`—`}                </td>              </tr>            `).join(``)}          </tbody>        </table>      </div>    </div>  `,e.querySelectorAll(`.leave-act`).forEach(t=>{t.onclick=async()=>{let n=t.dataset.status,{error:r}=await u.from(`leave_requests`).update({status:n}).eq(`id`,t.dataset.id);r?_(r.message,`error`):(_(`Request ${n}`,`success`),Ft(e))}})}async function It(e){A(e);let t=new Date().toLocaleDateString(`en-CA`).slice(0,7),n=new Date(new Date().getFullYear(),new Date().getMonth()+1,0).getDate(),[{data:r},{data:i},{data:a}]=await Promise.all([u.from(`profiles`).select(`*`).eq(`role`,`employee`).order(`full_name`,{ascending:!0}),u.from(`attendance`).select(`*`).order(`date`,{ascending:!1}),u.from(`leave_requests`).select(`*`).order(`created_at`,{ascending:!1})]),o=(r||[]).map(e=>{let r=(i||[]).filter(n=>n.user_id===e.id&&String(n.date||``).startsWith(t)),o=new Set(r.map(e=>e.date)).size,s=(a||[]).filter(n=>n.employee_id===e.id&&n.status===`approved`&&String(n.start_date||``).startsWith(t)).reduce((e,t)=>e+dt(t.start_date,t.end_date),0),c=Number(e.salary)||0,l=o+s;return{...e,presentDays:o,approvedLeaveDays:s,payableDays:l,monthlySalary:c,estimated:c/n*l}}),s=o.reduce((e,t)=>e+t.estimated,0),c=o.reduce((e,t)=>e+t.monthlySalary,0);e.innerHTML=`    <div class="page-header">      <h1>Salary Overview</h1>      <p>Attendance-based salary estimate for ${new Date().toLocaleDateString(`en-US`,{month:`long`,year:`numeric`})}</p>    </div>    <div class="stats-grid">      <div class="stat-card"><div class="stat-value">${o.length}</div><div class="stat-label">Employees</div></div>      <div class="stat-card"><div class="stat-value" style="font-size:1.8rem">${X(c)}</div><div class="stat-label">Monthly Payroll</div></div>      <div class="stat-card"><div class="stat-value" style="font-size:1.8rem;color:var(--warning)">${X(s)}</div><div class="stat-label">Estimated Earned</div></div>    </div>    <div class="card">      <div class="table-wrap">        <table>          <thead><tr><th>Employee</th><th>Monthly Salary</th><th>Present</th><th>Approved Leave</th><th>Payable Days</th><th>Estimated Earned</th></tr></thead>          <tbody>            ${o.length===0?`<tr><td colspan="6" style="text-align:center;padding:32px;color:var(--text-dim)">No employees found</td></tr>`:o.map(e=>`<tr>                <td><b>${e.full_name||`—`}</b></td>                <td>${X(e.monthlySalary)}</td>                <td><span class="badge badge-open">${e.presentDays}</span></td>                <td><span class="badge badge-resolved">${e.approvedLeaveDays}</span></td>                <td>${e.payableDays} / ${n}</td>                <td><b style="color:var(--primary)">${X(e.estimated)}</b></td>              </tr>`).join(``)}          </tbody>        </table>      </div>    </div>  `}async function Lt(e){A(e);let t=e.dataset.contactFilter||`all`,{data:n,error:r}=await u.from(`inquiries`).select(`*`).order(`created_at`,{ascending:!1});r&&console.warn(`[Admin] contacts load:`,r.message);let i=n||[],a=new Date,o=new Date(a.getFullYear(),a.getMonth(),a.getDate()).getTime(),s=o-a.getDay()*864e5,c=new Date(a.getFullYear(),a.getMonth(),1).getTime(),l=(e,t)=>new Date(e.created_at).getTime()>=t,d=e=>{let t=new Map;return e.forEach(e=>{e.phone&&!t.has(e.phone)&&t.set(e.phone,e)}),[...t.values()]},f={all:i.length,today:i.filter(e=>l(e,o)).length,week:i.filter(e=>l(e,s)).length,month:i.filter(e=>l(e,c)).length,unique:d(i).length},p;p=t===`today`?i.filter(e=>l(e,o)):t===`week`?i.filter(e=>l(e,s)):t===`month`?i.filter(e=>l(e,c)):t===`unique`?d(i):i;let m=[[`all`,`All`],[`today`,`Today`],[`week`,`This Week`],[`month`,`This Month`],[`unique`,`Unique Customers`]],h=e=>String(e||``).replace(/\D/g,``);e.innerHTML=`    <div class="page-header" style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;">      <div>        <h1>Contacts</h1>        <p>Customer contact details collected from service requests</p>      </div>      <div style="display:flex;gap:8px;flex-wrap:wrap;">        <button class="btn btn-secondary" id="contacts-export">Export CSV</button>        <button class="btn btn-secondary" id="contacts-refresh">${j.refresh}<span>Refresh</span></button>      </div>    </div>    <div class="sr-filter-bar">      ${m.map(([e,n])=>`        <button class="sr-filter ${e===t?`active`:``}" data-key="${e}">          <span>${n}</span><span class="sr-filter-count">${f[e]}</span>        </button>      `).join(``)}    </div>    <div class="card">      <div class="table-wrap">        <table>          <thead>            <tr>              <th>Name</th><th>Phone</th><th>Location</th>              <th>Service</th><th>Date</th><th>Actions</th>            </tr>          </thead>          <tbody>            ${p.length===0?`<tr><td colspan="6" style="text-align:center;padding:32px;color:var(--text-dim)">No contacts in this view</td></tr>`:p.map(e=>{let t=h(e.phone);return`<tr>                    <td><b>${e.full_name||`—`}</b></td>                    <td><span class="sr-mono">${e.phone||`—`}</span></td>                    <td style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${(e.location||``).replace(/"/g,`&quot;`)}">${e.location||`—`}</td>                    <td style="max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${e.service_item||`—`}</td>                    <td>${y(e.created_at)}</td>                    <td>                      <div class="contact-actions">                        <a class="contact-act contact-call" href="tel:${t}" title="Call">${j.phone}</a>                        <a class="contact-act contact-wa" href="https://wa.me/${t}" target="_blank" rel="noopener" title="WhatsApp">${j.whatsapp}</a>                        <button class="contact-act contact-copy" data-phone="${e.phone||``}" title="Copy number">${j.clipboard}</button>                      </div>                    </td>                  </tr>`}).join(``)}          </tbody>        </table>      </div>    </div>  `,e.querySelector(`#contacts-refresh`).onclick=()=>Lt(e),e.querySelector(`#contacts-export`).onclick=()=>C(`contacts.csv`,p.map(e=>({name:e.full_name,phone:e.phone,location:e.location,service:e.service_item,ticket_no:e.ticket_no,date:e.created_at}))),e.querySelectorAll(`.sr-filter`).forEach(t=>{t.onclick=()=>{e.dataset.contactFilter=t.dataset.key,Lt(e)}}),e.querySelectorAll(`.contact-copy`).forEach(e=>{e.onclick=async()=>{let t=e.dataset.phone;if(t)try{await navigator.clipboard.writeText(t),_(`Phone number copied`,`success`)}catch{_(`Copy failed`,`error`)}}})}async function Rt(e){A(e);let{data:t}=await u.from(`profiles`).select(`*`).order(`created_at`,{ascending:!1}),n=t||[],r=e=>e.role===`employee`?`
    <label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;white-space:nowrap;">
      <input type="checkbox" class="can-add-service-chk" data-uid="${e.id}" ${e.can_add_service?`checked`:``} style="cursor:pointer;width:16px;height:16px;margin:0;"/>
      Add Service
    </label>
  `:`<span style="color:var(--text-dim)">-</span>`,i=e=>e.role===`employee`?`
    <label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;white-space:nowrap;">
      <input type="checkbox" class="can-update-profile-chk" data-uid="${e.id}" ${e.can_update_profile?`checked`:``} style="cursor:pointer;width:16px;height:16px;margin:0;"/>
      Profile Edit
    </label>
  `:`<span style="color:var(--text-dim)">-</span>`;e.innerHTML=`
    <div class="page-header"><h1>User Management</h1><p>Control roles, SMS phone numbers, and staff access permissions.</p></div>
    <div class="card">
      <div class="table-wrap">
        <table>
          <thead><tr><th>Name</th><th>Current Role</th><th>Change Role</th><th>SMS Phone</th><th>Service Access</th><th>Profile Access</th><th>Update</th></tr></thead>
          <tbody>${n.length?n.map(e=>`<tr>
            <td><b>${Z(e.full_name||`-`)}</b></td>
            <td><span class="badge badge-open">${Z(e.role||`client`)}</span></td>
            <td>
              <select class="role-select" data-uid="${e.id}" style="width:auto;padding:4px 8px;border-radius:8px;box-shadow:var(--neu-inner);border:none;background:var(--bg);">
                <option ${e.role===`client`?`selected`:``} value="client">Client</option>
                <option ${e.role===`employee`?`selected`:``} value="employee">Staff</option>
                <option ${e.role===`admin`?`selected`:``} value="admin">Admin</option>
              </select>
            </td>
            <td>
              <input class="employee-phone-input" data-uid="${e.id}" type="tel" inputmode="numeric" maxlength="14"
                     placeholder="9876543210" value="${Z((e.phone||``).replace(/^\+91\s*/,``))}"
                     style="width:150px;padding:7px 10px;border-radius:8px;box-shadow:var(--neu-inner);border:none;background:var(--bg);"/>
              <small style="display:block;color:var(--text-dim);margin-top:4px;">Used for staff job SMS</small>
            </td>
            <td>${r(e)}</td>
            <td>${i(e)}</td>
            <td><button class="btn btn-secondary btn-sm save-user-phone" data-uid="${e.id}">Save Phone</button></td>
          </tr>`).join(``):`<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-dim)">No users found</td></tr>`}</tbody>
        </table>
      </div>
    </div>`,e.querySelectorAll(`.role-select`).forEach(t=>{t.addEventListener(`change`,async()=>{let{error:n}=await u.from(`profiles`).update({role:t.value}).eq(`id`,t.dataset.uid);if(n){_(`Role update failed: `+(n.message||``),`error`);return}_(`Role updated`,`success`),Rt(e)})});let a=(t,n,r)=>{e.querySelectorAll(t).forEach(e=>{e.addEventListener(`change`,async()=>{let{error:t}=await u.from(`profiles`).update({[n]:+!!e.checked}).eq(`id`,e.dataset.uid);if(t){_(`Failed to update ${r}: `+(t.message||``),`error`),e.checked=!e.checked;return}_(`${r} updated`,`success`)})})};a(`.can-add-service-chk`,`can_add_service`,`Service access`),a(`.can-update-profile-chk`,`can_update_profile`,`Profile edit access`),e.querySelectorAll(`.employee-phone-input`).forEach(e=>{e.addEventListener(`input`,()=>{let t=e.value.replace(/\D/g,``);t.length>10&&t.startsWith(`91`)?t=t.slice(2):t.length===11&&t.startsWith(`0`)&&(t=t.slice(1)),e.value=t.slice(0,10)})}),e.querySelectorAll(`.save-user-phone`).forEach(t=>{t.addEventListener(`click`,async()=>{let n=(e.querySelector(`.employee-phone-input[data-uid="${t.dataset.uid}"]`)?.value||``).replace(/\D/g,``);if(n&&!/^[6-9]\d{9}$/.test(n)){_(`Enter a valid 10-digit Indian mobile number`,`error`);return}t.disabled=!0,t.textContent=`Saving...`;let{error:r}=await u.from(`profiles`).update({phone:n?`+91${n}`:null}).eq(`id`,t.dataset.uid);if(t.disabled=!1,t.textContent=`Save Phone`,r){_(`Phone update failed: `+(r.message||``),`error`);return}_(`Employee SMS phone saved`,`success`)})})}async function zt(e){A(e);let{data:t}=await u.from(`inquiries`).select(`*`).order(`created_at`,{ascending:!1}),n=(t||[]).filter(e=>e.bill_amount!=null&&Number(e.bill_amount)>0),r=n.filter(e=>e.payment_status===`paid`).reduce((e,t)=>e+(Number(t.bill_amount)||0),0),i=n.filter(e=>e.payment_status!==`paid`).reduce((e,t)=>e+(Number(t.bill_amount)||0),0),a=e=>e.length===0?`<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-dim)">No payment records yet</td></tr>`:e.map(e=>`      <tr>        <td><code style="font-size:0.75rem;">${e.ticket_no||e.id.slice(0,8)}</code></td>        <td><b>${e.full_name}</b><br/><small style="color:var(--text-dim)">${e.phone}</small></td>        <td>\u20B9${Number(e.bill_amount).toLocaleString(`en-IN`)}</td>        <td><span class="badge badge-${e.payment_status===`paid`?`resolved`:`medium`}">${e.payment_status===`paid`?`Paid`:`Unpaid`}</span></td>        <td>${e.payment_link?`<a href="${e.payment_link}" target="_blank" style="color:var(--primary);font-size:0.8rem;">View Link</a>`:`<span style="color:var(--text-dim);font-size:0.8rem;">No link</span>`}</td>        <td>${e.payment_status===`paid`?`<span style="color:var(--success);font-size:0.8rem;font-weight:700;">? Done</span>`:`<button class="btn btn-secondary btn-sm mark-paid-btn" data-id="${e.id}" style="white-space:nowrap">? Mark Paid</button>`}</td>        <td><button class="btn btn-primary btn-sm inq-btn" data-id="${e.id}">Details</button></td>      </tr>`).join(``);e.innerHTML=`    <div class="page-header" style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;">      <div>        <h1>Payment Tracker</h1>        <p>Monitor revenue and billing status</p>      </div>      <button class="btn btn-secondary" id="pay-refresh">${j.refresh}<span>Refresh</span></button>    </div>    <div class="stats-grid" style="margin-bottom:24px;">      <div class="stat-card">        <div class="stat-value" style="color:var(--success)">\u20B9${r.toLocaleString(`en-IN`)}</div>        <div class="stat-label">Total Received</div>      </div>      <div class="stat-card">        <div class="stat-value" style="color:var(--warning)">\u20B9${i.toLocaleString(`en-IN`)}</div>        <div class="stat-label">Pending Payments</div>      </div>      <div class="stat-card">        <div class="stat-value" style="color:var(--primary)">${n.filter(e=>e.payment_status===`paid`).length} / ${n.length}</div>        <div class="stat-label">Paid / Total Bills</div>      </div>    </div>    <div class="filter-bar" style="margin-bottom:16px; display:flex; gap:12px; flex-wrap:wrap;">      <div class="search-input-wrap" style="flex:1; min-width:200px;">        <span>??</span>        <input class="search-input" id="pay-search" placeholder="Search by name or ticket…"/>      </div>      <div class="sr-filter-bar" id="pay-status-tabs">        <button class="sr-filter active" data-status="all">All <span class="sr-filter-count">${n.length}</span></button>        <button class="sr-filter" data-status="unpaid">Unpaid <span class="sr-filter-count">${n.filter(e=>e.payment_status!==`paid`).length}</span></button>        <button class="sr-filter" data-status="paid">Paid <span class="sr-filter-count">${n.filter(e=>e.payment_status===`paid`).length}</span></button>      </div>    </div>    <div class="card">      <div class="table-wrap">        <table>          <thead>            <tr><th>Ticket</th><th>Customer</th><th>Bill</th><th>Status</th><th>Link</th><th></th><th></th></tr>          </thead>          <tbody>${a(n)}</tbody>        </table>      </div>    </div>  `;let o=`all`,s=``,c=()=>{let t=n.filter(e=>{let t=o===`all`?!0:o===`paid`?e.payment_status===`paid`:e.payment_status!==`paid`,n=!s||e.full_name.toLowerCase().includes(s)||(e.ticket_no||``).toLowerCase().includes(s);return t&&n});e.querySelector(`tbody`).innerHTML=a(t),l()},l=()=>{e.querySelectorAll(`.inq-btn`).forEach(t=>{t.onclick=()=>rt(t,t.dataset.id,()=>zt(e))}),e.querySelectorAll(`.mark-paid-btn`).forEach(t=>{t.onclick=async()=>{t.disabled=!0,t.textContent=`…`;let r=n.find(e=>String(e.id)===String(t.dataset.id)),i=r?await Dt(r):{message:`Payment row not found`};i?(_(i.message,`error`),t.disabled=!1,t.textContent=`? Mark Paid`):(_(`Marked as paid and status updated`,`success`),zt(e))}})};e.querySelector(`#pay-refresh`).onclick=()=>zt(e),e.querySelector(`#pay-search`).oninput=e=>{s=e.target.value.toLowerCase(),c()},e.querySelectorAll(`#pay-status-tabs .sr-filter`).forEach(t=>{t.onclick=()=>{e.querySelectorAll(`#pay-status-tabs .sr-filter`).forEach(e=>e.classList.remove(`active`)),t.classList.add(`active`),o=t.dataset.status,c()}}),l()}async function Bt(e){A(e);let{data:t}=await u.from(`inquiries`).select(`*`).order(`bill_generated_at`,{ascending:!1}),n=(t||[]).filter(e=>Number(e.bill_total)>0),r=n.reduce((e,t)=>e+(Number(t.bill_total)||0),0),i=n.filter(e=>e.payment_status===`paid`).reduce((e,t)=>e+(Number(t.bill_total)||0),0),a=r-i,o=e=>{let t=e.bill_generated_at||e.created_at;if(!t)return`—`;try{let e=new Date(t.replace(` `,`T`));return Number.isNaN(e.getTime())?t:e.toLocaleString(`en-IN`,{dateStyle:`medium`,timeStyle:`short`})}catch{return t}},s=e=>e.length===0?`<tr><td colspan="8" style="text-align:center;padding:32px;color:var(--text-dim)">No bills generated yet</td></tr>`:e.map(e=>`      <tr>        <td><small style="color:var(--text-dim)">${o(e)}</small></td>        <td><code style="font-size:0.75rem;">${e.ticket_no||(e.id||``).slice(0,8)}</code></td>        <td><b>${e.full_name||`—`}</b><br/><small style="color:var(--text-dim)">${e.phone||``}</small></td>        <td>${e.device_type||`<span style="color:var(--text-dim)">—</span>`}<br/><small style="color:var(--text-dim)">${e.device_serial_no||``}</small></td>        <td><b>\u20B9${Math.round(Number(e.bill_total)).toLocaleString(`en-IN`)}</b></td>        <td><span class="badge badge-${e.payment_status===`paid`?`resolved`:`medium`}">${e.payment_status===`paid`?`Paid`:`Unpaid`}</span></td>        <td><button class="btn btn-primary btn-sm bill-view-btn" data-id="${e.id}">?? View</button></td>        <td><button class="btn btn-secondary btn-sm bill-share-btn" data-id="${e.id}" title="Get shareable PDF link">?? Share</button></td>      </tr>`).join(``);e.innerHTML=`    <div class="page-header" style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;">      <div>        <h1>Bills</h1>        <p>All invoices generated by technicians — open any bill to view or download the PDF</p>      </div>      <button class="btn btn-secondary" id="bills-refresh">${j.refresh}<span>Refresh</span></button>    </div>    <div class="stats-grid" style="margin-bottom:24px;">      <div class="stat-card">        <div class="stat-value" style="color:var(--primary)">${n.length}</div>        <div class="stat-label">Total Bills</div>      </div>      <div class="stat-card">        <div class="stat-value" style="color:var(--success)">\u20B9${Math.round(i).toLocaleString(`en-IN`)}</div>        <div class="stat-label">Received</div>      </div>      <div class="stat-card">        <div class="stat-value" style="color:var(--warning)">\u20B9${Math.round(a).toLocaleString(`en-IN`)}</div>        <div class="stat-label">Pending</div>      </div>      <div class="stat-card">        <div class="stat-value" style="font-size:1.7rem;">\u20B9${Math.round(r).toLocaleString(`en-IN`)}</div>        <div class="stat-label">Total Billed</div>      </div>    </div>    <div class="filter-bar" style="margin-bottom:16px; display:flex; gap:12px; flex-wrap:wrap;">      <div class="search-input-wrap" style="flex:1; min-width:200px;">        <span>??</span>        <input class="search-input" id="bills-search" placeholder="Search by name, ticket, device, serial…"/>      </div>      <div class="sr-filter-bar" id="bills-status-tabs">        <button class="sr-filter active" data-status="all">All <span class="sr-filter-count">${n.length}</span></button>        <button class="sr-filter" data-status="paid">Paid <span class="sr-filter-count">${n.filter(e=>e.payment_status===`paid`).length}</span></button>        <button class="sr-filter" data-status="unpaid">Unpaid <span class="sr-filter-count">${n.filter(e=>e.payment_status!==`paid`).length}</span></button>      </div>    </div>    <div class="card">      <div class="table-wrap">        <table>          <thead>            <tr><th>Date</th><th>Ticket</th><th>Customer</th><th>Device</th><th>Total</th><th>Payment</th><th></th><th></th></tr>          </thead>          <tbody>${s(n)}</tbody>        </table>      </div>    </div>  `;let c=`all`,l=``,d=()=>{let t=n.filter(e=>{let t=c===`all`?!0:c===`paid`?e.payment_status===`paid`:e.payment_status!==`paid`,n=`${e.full_name||``} ${e.ticket_no||``} ${e.device_type||``} ${e.device_serial_no||``}`.toLowerCase();return t&&(!l||n.includes(l))});e.querySelector(`tbody`).innerHTML=s(t),p()},f=async e=>{let t=e.assigned_employee_id&&(await u.from(`profiles`).select(`full_name`).eq(`id`,e.assigned_employee_id).single()).data?.full_name||``,{data:n}=await u.from(`inquiry_services`).select(`service_id, service_pricing(name, category, sub_category, sub_sub_category, cost)`).eq(`inquiry_id`,e.id),r=(n||[]).map(e=>{let t=e.service_pricing||{};return{name:[t.category,t.sub_category,t.sub_sub_category||t.name].filter(Boolean).join(` › `),cost:Number(t.cost)||0}}),i=Math.max(0,Number(e.bill_amount||0)-Number(e.extra_cost||0));return{customer:{name:e.full_name,phone:e.phone,location:e.location,company:e.company_name,device_type:e.device_type,device_serial:e.device_serial_no,service_item:e.service_item,ticket_no:e.ticket_no},technician:t,services:r,servicesSubtotal:i,extra:Number(e.extra_cost)||0,extraReason:e.extra_cost_reason||``,platform:Number(e.platform_fee)||0,km:Number(e.transport_km)||0,transport:Number(e.transport_fee)||0,discount:Number(e.discount_amount)||0,taxable:i+Number(e.extra_cost||0)+Number(e.platform_fee||0)+Number(e.transport_fee||0)-Number(e.discount_amount||0),gst:Number(e.gst_amount)||0,total:Number(e.bill_total)||0,paymentLink:e.payment_link||``}},p=()=>{e.querySelectorAll(`.bill-view-btn`).forEach(e=>{e.onclick=async()=>{let t=n.find(t=>String(t.id)===String(e.dataset.id));t&&Oe(await f(t),{allowShare:!1,title:`?? Bill (Sent to Client)`})}}),e.querySelectorAll(`.bill-share-btn`).forEach(e=>{e.onclick=async()=>{let t=n.find(t=>String(t.id)===String(e.dataset.id));if(!t)return;let r=Y(e,`Preparing…`),i;try{i=await f(t)}finally{r()}Vt(t,i)}})};e.querySelector(`#bills-refresh`).onclick=()=>Bt(e),e.querySelector(`#bills-search`).oninput=e=>{l=e.target.value.toLowerCase(),d()},e.querySelectorAll(`#bills-status-tabs .sr-filter`).forEach(t=>{t.onclick=()=>{e.querySelectorAll(`#bills-status-tabs .sr-filter`).forEach(e=>e.classList.remove(`active`)),t.classList.add(`active`),c=t.dataset.status,d()}}),p()}async function Vt(e,t){let n=document.createElement(`div`);n.className=`modal-overlay`,n.innerHTML=`    <div class="modal-card" style="max-width:480px;width:100%;">      <div class="modal-header">        <h3>?? Share Bill with Client</h3>        <button class="btn-icon" id="bsm-close">?</button>      </div>      <div class="modal-body" style="padding:24px;">        <div id="bsm-loading" style="text-align:center;padding:20px 0;">          <div class="spinner" style="margin:0 auto 12px;"></div>          <p style="color:var(--text-dim);font-size:14px;">Generating PDF…</p>        </div>        <div id="bsm-content" style="display:none;">          <p style="font-size:13px;color:var(--text-dim);margin-bottom:12px;">Copy this public link and send it to the client — they can open and download the PDF without logging in.</p>          <div style="display:flex;gap:8px;align-items:center;">            <input id="bsm-url" readonly style="flex:1;padding:10px 12px;border:1px solid var(--border);border-radius:8px;font-size:13px;background:var(--surface);color:var(--text);" value="" />            <button class="btn btn-primary" id="bsm-copy" style="white-space:nowrap;">?? Copy</button>          </div>          <div style="margin-top:16px;display:flex;gap:10px;flex-wrap:wrap;">            <a id="bsm-open" target="_blank" rel="noopener" class="btn btn-secondary" style="text-decoration:none;">?? Open PDF</a>            <button class="btn btn-secondary" id="bsm-whatsapp">?? Send via WhatsApp</button>          </div>        </div>        <div id="bsm-error" style="display:none;color:var(--danger);font-size:14px;"></div>      </div>    </div>`,document.body.appendChild(n),n.querySelector(`#bsm-close`).onclick=()=>n.remove();try{let r=await H(t,{inquiryId:e.id,existingUrl:e.bill_pdf_url||null});e.bill_pdf_url=r,n.querySelector(`#bsm-loading`).style.display=`none`,n.querySelector(`#bsm-content`).style.display=`block`;let i=n.querySelector(`#bsm-url`);i.value=r,n.querySelector(`#bsm-copy`).onclick=async()=>{try{await navigator.clipboard.writeText(r),_(`Link copied to clipboard!`,`success`)}catch{i.select(),document.execCommand(`copy`),_(`Link copied!`,`success`)}},n.querySelector(`#bsm-open`).href=r,n.querySelector(`#bsm-whatsapp`).onclick=()=>{let t=(e.phone||``).replace(/\D/g,``);if(!t){_(`No phone number on this bill`,`error`);return}let n=[`Hi ${e.full_name||``}! ??`,`Your service invoice from *Networking Experts* is ready.`,`Ticket: *${e.ticket_no||`—`}* · Total: *${(e=>`\u20B9${Math.round(Number(e)||0).toLocaleString(`en-IN`)}`)(e.bill_total)}*`,``,`?? View / download bill PDF:`,r,``,`— Networking Experts`].join(`
`);window.open(`https://wa.me/${t}?text=${encodeURIComponent(n)}`,`_blank`)}}catch(e){console.error(`[showBillShareModal]`,e),n.querySelector(`#bsm-loading`).style.display=`none`,n.querySelector(`#bsm-error`).style.display=`block`,n.querySelector(`#bsm-error`).textContent=`Failed to generate PDF: ${e.message}`}}async function Ht(e){A(e);let[{data:t},{data:n},{data:r}]=await Promise.all([u.from(`device_types`).select(`*`).order(`name`),u.from(`companies`).select(`*`).order(`name`),u.from(`inquiries`).select(`full_name, company_name, device_type, device_serial_no, ticket_no, created_at`)]),i=Array.isArray(t)?t:[],a=Array.isArray(n)?n:[],o=(r||[]).filter(e=>e.device_type&&e.device_type.trim()||e.device_serial_no&&e.device_serial_no.trim());o.sort((e,t)=>new Date(t.created_at)-new Date(e.created_at));let s=i.length===0?`<tr><td colspan="3" style="text-align:center;padding:24px;color:var(--text-dim)">No device types yet.</td></tr>`:i.map(e=>`      <tr data-id="${e.id}">        <td><b>${Z(e.name)}</b></td>        <td><small style="color:var(--text-dim)">${Z(e.description||`—`)}</small></td>        <td style="text-align:right; white-space:nowrap;">          <button class="btn btn-secondary btn-sm dt-edit-btn" data-id="${e.id}" style="padding:2px 8px; font-size:0.75rem;">Edit</button>          <button class="btn btn-danger btn-sm dt-del-btn" data-id="${e.id}" style="padding:2px 8px; font-size:0.75rem;">Delete</button>        </td>      </tr>`).join(``),c=a.length===0?`<tr><td colspan="2" style="text-align:center;padding:24px;color:var(--text-dim)">No companies yet.</td></tr>`:a.map(e=>{let t=e.name.toLowerCase()===`networking experts`;return`          <tr data-id="${e.id}">            <td><b>${Z(e.name)}</b></td>            <td style="text-align:right; white-space:nowrap;">              ${t?`<span style="color:var(--text-dim); font-size:0.75rem; margin-right:8px; font-weight:600;">Default</span>`:`                <button class="btn btn-secondary btn-sm comp-edit-btn" data-id="${e.id}" style="padding:2px 8px; font-size:0.75rem;">Edit</button>                <button class="btn btn-danger btn-sm comp-del-btn" data-id="${e.id}" style="padding:2px 8px; font-size:0.75rem;">Delete</button>              `}            </td>          </tr>        `}).join(``),l=o.length===0?`<tr><td colspan="6" style="text-align:center;padding:32px;color:var(--text-dim)">No reported customer devices found.</td></tr>`:o.map(e=>`      <tr>        <td><b>${Z(e.full_name||`—`)}</b></td>        <td>${Z(e.company_name||`—`)}</td>        <td><span class="badge badge-open">${Z(e.device_type||`—`)}</span></td>        <td><code>${Z(e.device_serial_no||`—`)}</code></td>        <td><code>${Z(e.ticket_no||`—`)}</code></td>        <td>${e.created_at?new Date(e.created_at).toLocaleDateString(`en-IN`):`—`}</td>      </tr>    `).join(``);e.innerHTML=`    <div class="page-header" style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;margin-bottom:20px;">      <div>        <h1>Devices & Companies Management</h1>        <p>Manage device types, registered companies, and view reported customer devices.</p>      </div>      <button class="btn btn-secondary" id="dt-refresh">${j.refresh}<span>Refresh</span></button>    </div>    <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap:20px; margin-bottom:20px;">      <!-- Device Types CRUD -->      <div class="card" style="margin:0; display:flex; flex-direction:column; justify-content:space-between;">        <div class="card-body">          <h2 style="font-size:1.2rem; margin-top:0; margin-bottom:12px;">Device Types CRUD</h2>          <p style="font-size:0.85rem; color:var(--text-dim); margin-bottom:16px;">Pickable device types for technicians.</p>          <div style="display:flex; gap:10px; margin-bottom:16px; align-items:flex-end;">            <div class="form-group" style="margin:0; flex:1;">              <label style="font-size:0.75rem;">Device Name</label>              <input id="dt-name" placeholder="e.g. Video Door Phone" style="width:100%; padding:6px 10px; font-size:0.85rem;"/>            </div>            <div class="form-group" style="margin:0; flex:1.5;">              <label style="font-size:0.75rem;">Description (optional)</label>              <input id="dt-desc" placeholder="Short note" style="width:100%; padding:6px 10px; font-size:0.85rem;"/>            </div>            <button class="btn btn-primary" id="dt-add" style="padding:6px 12px; height:34px; font-size:0.85rem; display:flex; align-items:center; gap:4px;">              ${j.plus}<span>Add</span>            </button>          </div>          <div class="table-wrap" style="max-height: 280px; overflow-y: auto;">            <table>              <thead><tr><th>Name</th><th>Description</th><th style="text-align:right;"></th></tr></thead>              <tbody>${s}</tbody>            </table>          </div>        </div>      </div>      <!-- Companies CRUD -->      <div class="card" style="margin:0; display:flex; flex-direction:column; justify-content:space-between;">        <div class="card-body">          <h2 style="font-size:1.2rem; margin-top:0; margin-bottom:12px;">Companies Registry</h2>          <p style="font-size:0.85rem; color:var(--text-dim); margin-bottom:16px;">Registered client companies.</p>          <div style="display:flex; gap:10px; margin-bottom:16px; align-items:flex-end;">            <div class="form-group" style="margin:0; flex:1;">              <label style="font-size:0.75rem;">Company Name</label>              <input id="comp-name" placeholder="e.g. ACME Corp" style="width:100%; padding:6px 10px; font-size:0.85rem;"/>            </div>            <button class="btn btn-primary" id="comp-add" style="padding:6px 12px; height:34px; font-size:0.85rem; display:flex; align-items:center; gap:4px;">              ${j.plus}<span>Add</span>            </button>          </div>          <div class="table-wrap" style="max-height: 280px; overflow-y: auto;">            <table>              <thead><tr><th>Name</th><th style="text-align:right;"></th></tr></thead>              <tbody>${c}</tbody>            </table>          </div>        </div>      </div>    </div>    <!-- Reported Customer Devices Table Card -->    <div class="card">      <div class="card-body">        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; flex-wrap:wrap; gap:12px;">          <div>            <h2 style="font-size:1.25rem; margin:0;">Reported Customer Devices</h2>            <p style="font-size:0.85rem; color:var(--text-dim); margin:4px 0 0 0;">              List of all customer devices registered or reported in service inquiries.            </p>          </div>          <button class="btn btn-secondary" id="export-devices-csv" style="display:flex; align-items:center; gap:6px; font-size:0.85rem; padding:8px 14px;">            Export CSV          </button>        </div>        <div class="table-wrap">          <table>            <thead>              <tr>                <th>Customer Name</th>                <th>Company</th>                <th>Device Type</th>                <th>Serial Number</th>                <th>Ticket Number</th>                <th>Service Date</th>              </tr>            </thead>            <tbody>${l}</tbody>          </table>        </div>      </div>    </div>  `,e.querySelector(`#dt-refresh`).onclick=()=>Ht(e),e.querySelector(`#dt-add`).onclick=async()=>{let t=e.querySelector(`#dt-name`).value.trim(),n=e.querySelector(`#dt-desc`).value.trim();if(!t){_(`Enter a device name`,`warning`);return}if(i.some(e=>e.name.toLowerCase()===t.toLowerCase())){_(`That device type already exists`,`warning`);return}let r=window.crypto?.randomUUID&&window.crypto.randomUUID()||`dt-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,{error:a}=await u.from(`device_types`).insert({id:r,name:t,description:n||null});if(a){_(a.message,`error`);return}_(`Device type added`,`success`),Ht(e)},e.querySelectorAll(`.dt-edit-btn`).forEach(t=>{t.onclick=async()=>{let n=i.find(e=>String(e.id)===t.dataset.id);if(!n)return;let r=prompt(`Device name:`,n.name);if(r==null)return;let a=prompt(`Description (optional):`,n.description||``);if(a==null)return;let{error:o}=await u.from(`device_types`).update({name:r.trim()||n.name,description:a.trim()||null}).eq(`id`,n.id);if(o){_(o.message,`error`);return}_(`Updated`,`success`),Ht(e)}}),e.querySelectorAll(`.dt-del-btn`).forEach(t=>{t.onclick=async()=>{let n=i.find(e=>String(e.id)===t.dataset.id);if(!n||!confirm(`Delete device type "${n.name}"?`))return;let{error:r}=await u.from(`device_types`).delete().eq(`id`,n.id);if(r){_(r.message,`error`);return}_(`Deleted`,`success`),Ht(e)}}),e.querySelector(`#comp-add`).onclick=async()=>{let t=e.querySelector(`#comp-name`).value.trim();if(!t){_(`Enter a company name`,`warning`);return}if(a.some(e=>e.name.toLowerCase()===t.toLowerCase())){_(`That company already exists`,`warning`);return}let n=window.crypto?.randomUUID&&window.crypto.randomUUID()||`comp-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,{error:r}=await u.from(`companies`).insert({id:n,name:t});if(r){_(r.message,`error`);return}_(`Company added`,`success`),Ht(e)},e.querySelectorAll(`.comp-edit-btn`).forEach(t=>{t.onclick=async()=>{let n=a.find(e=>String(e.id)===t.dataset.id);if(!n)return;if(n.name.toLowerCase()===`networking experts`){_(`Cannot edit default company`,`error`);return}let r=prompt(`Company name:`,n.name);if(!r||!r.trim())return;if(a.some(e=>e.name.toLowerCase()===r.trim().toLowerCase()&&e.id!==n.id)){_(`That company name already exists`,`warning`);return}let{error:i}=await u.from(`companies`).update({name:r.trim()}).eq(`id`,n.id);if(i){_(i.message,`error`);return}_(`Company updated`,`success`),Ht(e)}}),e.querySelectorAll(`.comp-del-btn`).forEach(t=>{t.onclick=async()=>{let n=a.find(e=>String(e.id)===t.dataset.id);if(!n)return;if(n.name.toLowerCase()===`networking experts`){_(`Cannot delete default company`,`error`);return}if(!confirm(`Delete company "${n.name}"?`))return;let{error:r}=await u.from(`companies`).delete().eq(`id`,n.id);if(r){_(r.message,`error`);return}_(`Company deleted`,`success`),Ht(e)}}),e.querySelector(`#export-devices-csv`).onclick=()=>{let e=[`Customer Name`,`Company`,`Device Type`,`Serial Number`,`Ticket Number`,`Service Date`],t=o.map(e=>[e.full_name||``,e.company_name||``,e.device_type||``,e.device_serial_no||``,e.ticket_no||``,e.created_at?new Date(e.created_at).toLocaleDateString(`en-IN`):``]),n=[e.join(`,`),...t.map(e=>e.map(e=>`"${String(e).replace(/"/g,`""`)}"`).join(`,`))].join(`
`),r=new Blob([n],{type:`text/csv;charset=utf-8;`}),i=URL.createObjectURL(r),a=document.createElement(`a`);a.setAttribute(`href`,i),a.setAttribute(`download`,`reported-devices.csv`),document.body.appendChild(a),a.click(),document.body.removeChild(a),URL.revokeObjectURL(i)}}async function Ut(e){A(e);let{data:t}=await u.from(`inquiries`).select(`*`).eq(`payment_method`,`cash`).eq(`payment_status`,`paid`).order(`cash_collected_at`,{ascending:!1}),{data:n}=await u.from(`profiles`).select(`id, full_name, phone`).eq(`role`,`employee`),r=n||[],i=new Map;(t||[]).forEach(e=>{!e.assigned_employee_id||!e.cash_collected_at||(i.has(e.assigned_employee_id)||i.set(e.assigned_employee_id,[]),i.get(e.assigned_employee_id).push(e))});let a=(t||[]).filter(e=>e.cash_collected_at&&!e.cash_submitted_at),o=(t||[]).filter(e=>e.cash_submitted_at),s=a.reduce((e,t)=>e+(Number(t.bill_total)||0),0),c=o.reduce((e,t)=>e+(Number(t.bill_total)||0),0),l=e=>{if(!e)return`—`;try{let t=new Date(String(e).replace(` `,`T`));return Number.isNaN(t.getTime())?e:t.toLocaleString(`en-IN`,{dateStyle:`medium`,timeStyle:`short`})}catch{return e}},d=e=>{let t=i.get(e.id)||[],n=t.filter(e=>!e.cash_submitted_at),r=t.filter(e=>e.cash_submitted_at),a=n.reduce((e,t)=>e+(Number(t.bill_total)||0),0),o=r.reduce((e,t)=>e+(Number(t.bill_total)||0),0);return`      <div class="emp-cash-card" data-emp-id="${e.id}">        <div class="emp-cash-head">          <div>            <div class="emp-cash-name">${e.full_name}</div>            <div class="emp-cash-sub">${e.phone||``}</div>          </div>          <div class="emp-cash-totals">            <div><span>Pending</span><b style="color:var(--warning)">\u20B9${Math.round(a).toLocaleString(`en-IN`)}</b></div>            <div><span>Submitted</span><b style="color:var(--success)">\u20B9${Math.round(o).toLocaleString(`en-IN`)}</b></div>          </div>        </div>        ${n.length===0?`<div class="emp-cash-empty">No pending cash from this employee.</div>`:`          <div class="table-wrap">            <table>              <thead><tr>                <th style="width:30px;"><input type="checkbox" class="cash-all-cb" checked title="Select all pending"/></th>                <th>Date</th><th>Ticket</th><th>Customer</th><th>Service</th><th>Amount</th>              </tr></thead>              <tbody>                ${n.map(e=>`                  <tr>                    <td><input type="checkbox" class="cash-cb" data-id="${e.id}" checked/></td>                    <td><small style="color:var(--text-dim)">${l(e.cash_collected_at)}</small></td>                    <td><code style="font-size:0.75rem;">${e.ticket_no||(e.id||``).slice(0,8)}</code></td>                    <td><b>${e.full_name||`—`}</b><br/><small style="color:var(--text-dim)">${e.phone||``}</small></td>                    <td><small>${e.service_item||`—`}</small></td>                    <td><b>\u20B9${Math.round(Number(e.bill_total)||0).toLocaleString(`en-IN`)}</b></td>                  </tr>`).join(``)}              </tbody>            </table>          </div>          <div class="emp-cash-actions">            <span class="emp-cash-selected">Selected: <b id="sel-total-${e.id}">\u20B9${Math.round(a).toLocaleString(`en-IN`)}</b></span>            <button class="btn btn-primary record-submit-btn" data-emp-id="${e.id}">${j.check}<span>Record Submission</span></button>          </div>`}        ${r.length>0?`          <details class="emp-cash-history">            <summary>Past submissions (${r.length}) · \u20B9${Math.round(o).toLocaleString(`en-IN`)}</summary>            <div class="table-wrap">              <table>                <thead><tr><th>Submitted</th><th>Ticket</th><th>Customer</th><th>Amount</th></tr></thead>                <tbody>                  ${r.map(e=>`                    <tr>                      <td><small style="color:var(--text-dim)">${l(e.cash_submitted_at)}</small></td>                      <td><code style="font-size:0.75rem;">${e.ticket_no||(e.id||``).slice(0,8)}</code></td>                      <td><b>${e.full_name||`—`}</b></td>                      <td><b>\u20B9${Math.round(Number(e.bill_total)||0).toLocaleString(`en-IN`)}</b></td>                    </tr>`).join(``)}                </tbody>              </table>            </div>          </details>`:``}      </div>`},f=r.filter(e=>(i.get(e.id)||[]).length>0);e.innerHTML=`    <div class="page-header" style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;">      <div>        <h1>Cash Collections</h1>        <p>Cash collected by technicians, grouped per employee. Tick the records you're receiving cash for, then press <b>Record Submission</b>.</p>      </div>      <button class="btn btn-secondary" id="cash-refresh">${j.refresh}<span>Refresh</span></button>    </div>    <div class="stats-grid" style="margin-bottom:24px;">      <div class="stat-card">        <div class="stat-value" style="color:var(--warning); font-size:1.9rem;">\u20B9${Math.round(s).toLocaleString(`en-IN`)}</div>        <div class="stat-label">Total Pending</div>      </div>      <div class="stat-card">        <div class="stat-value" style="color:var(--success); font-size:1.9rem;">\u20B9${Math.round(c).toLocaleString(`en-IN`)}</div>        <div class="stat-label">Total Submitted (All Time)</div>      </div>      <div class="stat-card">        <div class="stat-value">${f.length}</div>        <div class="stat-label">Employees With Records</div>      </div>      <div class="stat-card">        <div class="stat-value">${a.length}</div>        <div class="stat-label">Pending Records</div>      </div>    </div>    ${f.length===0?`<div class="card"><div class="card-body" style="text-align:center; padding:48px; color:var(--text-dim);">No cash collections recorded yet.</div></div>`:f.map(d).join(``)}  `,e.querySelector(`#cash-refresh`).onclick=()=>Ut(e);let p=t=>{let n=e.querySelector(`.emp-cash-card[data-emp-id="${t}"]`);if(!n)return;let r=Array.from(n.querySelectorAll(`.cash-cb:checked`)).map(e=>e.dataset.id),a=(i.get(t)||[]).filter(e=>r.includes(String(e.id))).reduce((e,t)=>e+(Number(t.bill_total)||0),0),o=n.querySelector(`#sel-total-${t}`);o&&(o.textContent=`\u20B9${Math.round(a).toLocaleString(`en-IN`)}`)};e.querySelectorAll(`.emp-cash-card`).forEach(e=>{let t=e.dataset.empId,n=e.querySelector(`.cash-all-cb`),r=e.querySelectorAll(`.cash-cb`);n&&(n.onclick=()=>{r.forEach(e=>{e.checked=n.checked}),p(t)}),r.forEach(e=>{e.onchange=()=>p(t)})}),e.querySelectorAll(`.record-submit-btn`).forEach(t=>{t.onclick=async()=>{let n=t.dataset.empId,r=e.querySelector(`.emp-cash-card[data-emp-id="${n}"]`),a=Array.from(r.querySelectorAll(`.cash-cb:checked`)).map(e=>e.dataset.id);if(a.length===0){_(`Select at least one record`,`warning`);return}t.disabled=!0,t.innerHTML=`<span>Saving…</span>`;try{let{data:{user:t}}=await u.auth.getUser(),r=new Date().toISOString().slice(0,19).replace(`T`,` `);for(let e of a)await u.from(`inquiries`).update({cash_submitted_at:r,cash_submitted_by:t?.id||null}).eq(`id`,e);let o=(i.get(n)||[]).filter(e=>a.includes(String(e.id))).reduce((e,t)=>e+(Number(t.bill_total)||0),0);_(`? Recorded \u20B9${Math.round(o).toLocaleString(`en-IN`)} from technician`,`success`),Ut(e)}catch(e){_(e.message||`Could not record submission`,`error`),t.disabled=!1,t.innerHTML=`${j.check}<span>Record Submission</span>`}}})}var Wt=null;function Gt(){return window.XLSX?Promise.resolve(window.XLSX):Wt||(Wt=new Promise((e,t)=>{let n=document.createElement(`script`);n.src=`https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js`,n.onload=()=>window.XLSX?e(window.XLSX):t(Error(`xlsx failed to load`)),n.onerror=()=>t(Error(`Could not fetch xlsx parser. Check your internet connection.`)),document.head.appendChild(n)}),Wt)}function Kt(e){let t=[],n=``,r=[],i=!1;for(let a=0;a<e.length;a++){let o=e[a];i?o===`"`&&e[a+1]===`"`?(n+=`"`,a++):o===`"`?i=!1:n+=o:o===`"`?i=!0:o===`,`?(r.push(n),n=``):o===`
`?(r.push(n),t.push(r),n=``,r=[]):o===`\r`||(n+=o)}return(n.length||r.length)&&(r.push(n),t.push(r)),t.filter(e=>e.some(e=>String(e??``).trim()!==``))}async function qt(e){if(/\.csv$/i.test(e.name)||e.type===`text/csv`)return Kt(await e.text());let t=await Gt(),n=await e.arrayBuffer(),r=t.read(n,{type:`array`}),i=r.Sheets[r.SheetNames[0]];return t.utils.sheet_to_json(i,{header:1,blankrows:!1,defval:``})}function Jt(e){if(e==null)return NaN;let t=String(e).replace(/[?$,\s]/g,``);return Number(t)}function Yt(e){let t=e.map(e=>String(e??``).trim().toLowerCase()),n={mainIdx:-1,subIdx:-1,subSubIdx:-1,priceIdx:-1},r=0;return t.forEach((e,t)=>{e&&(/(price|rate|cost|amount|charge)/.test(e)?(n.priceIdx=t,r++):/sub[\s\-_]*sub/.test(e)||/level\s*3/.test(e)||/issue|defect|problem/.test(e)?(n.subSubIdx=t,r++):/sub/.test(e)||/level\s*2/.test(e)||/group/.test(e)?(n.subIdx=t,r++):/(main|category|type|service)/.test(e)&&(n.mainIdx=t,r++))}),r>=2?n:null}function Xt(e){let t=-1;for(let n=e.length-1;n>=0;n--)if(Number.isFinite(Jt(e[n]))){t=n;break}return t<=0?{mainIdx:-1,subIdx:-1,subSubIdx:0,priceIdx:t>=0?t:1}:t===1?{mainIdx:-1,subIdx:-1,subSubIdx:0,priceIdx:t}:t===2?{mainIdx:0,subIdx:-1,subSubIdx:1,priceIdx:t}:{mainIdx:0,subIdx:1,subSubIdx:2,priceIdx:t}}async function Zt(e){let t=0,n=0,r=[];if(!e.length)return{inserted:t,skipped:n,errors:r};let i=Yt(e[0]),a=+!!i;i||=Xt(e[0]);let{mainIdx:o,subIdx:s,subSubIdx:c,priceIdx:l}=i;c===-1&&s!==-1&&o!==-1&&(c=s,s=-1);let d=[],f=[];for(let t=a;t<e.length;t++){let i=e[t],a=e=>e>=0?String(i[e]??``).trim():``,u=a(o),p=a(s),m=a(c),h=Jt(l>=0?i[l]:null);if(!u&&!p&&!m&&!Number.isFinite(h)){n++;continue}if(!m){r.push(`Row ${t+1}: missing leaf service name`),n++;continue}if(!Number.isFinite(h)||h<0){r.push(`Row ${t+1}: invalid price`),n++;continue}d.push({id:crypto.randomUUID(),category:u||`Uncategorized`,sub_category:p||null,sub_sub_category:m,name:m,cost:h}),f.push({rowIndex:t})}for(let e=0;e<d.length;e+=10){let i=d.slice(e,e+10),a=f.slice(e,e+10),o=0;for(;o<3;){let{error:e}=await u.from(`service_pricing`).insert(i);if(e?.status===429){o++,await new Promise(e=>setTimeout(e,1e3*2**o));continue}e?(a.forEach(t=>r.push(`Row ${t.rowIndex+1}: ${e.message}`)),n+=i.length):t+=i.length;break}o===3&&(a.forEach(e=>r.push(`Row ${e.rowIndex+1}: rate limited (too many requests)`)),n+=i.length)}return{inserted:t,skipped:n,errors:r}}function Qt(){let e=new Blob([`Main Category,Sub Category,Sub-Sub Category,Price`],{type:`text/csv;charset=utf-8`}),t=URL.createObjectURL(e),n=document.createElement(`a`);n.href=t,n.download=`service-pricing-template.csv`,document.body.appendChild(n),n.click(),n.remove(),URL.revokeObjectURL(t)}async function $t(e){A(e);try{let{data:t,error:n}=await u.from(`service_pricing`).select(`*`).order(`category`);if(n)throw n;let r=t||[],i=[...new Set(r.map(e=>e.category||`Service`))].sort(),a=[...new Set(r.map(e=>e.sub_category||``).filter(Boolean))].sort(),o=e=>e.length===0?`<tr><td colspan="6" style="text-align:center;padding:32px;color:var(--text-dim)">No services match this filter</td></tr>`:e.map(e=>`
          <tr data-main="${nt(e.category||`Service`)}" data-sub="${nt(e.sub_category||``)}" data-search="${nt(`${e.category||``} ${e.sub_category||``} ${e.sub_sub_category||``} ${e.name||``}`.toLowerCase())}">
            <td><input type="checkbox" class="service-checkbox" data-id="${e.id}"></td>
            <td><span class="badge badge-open">${Z(e.category||`Service`)}</span></td>
            <td>${e.sub_category?Z(e.sub_category):`<span style="color:var(--text-dim)">-</span>`}</td>
            <td><b>${Z(e.sub_sub_category||e.name||``)}</b></td>
            <td>${X(e.cost)}</td>
            <td style="display:flex;gap:6px;"><button class="btn btn-secondary btn-sm edit-price" data-id="${e.id}" title="Edit">${j.edit||`Edit`}</button><button class="btn btn-danger btn-sm del-price" data-id="${e.id}" title="Delete">${j.close}</button></td>
          </tr>
        `).join(``);e.innerHTML=`
      <div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:16px;">
        <div style="flex:1;min-width:250px;">
          <h1 style="display:flex;align-items:center;gap:12px;margin:0 0 8px;">
            <span style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;color:var(--primary);font-size:1.4rem;flex-shrink:0;">${j.receipt||``}</span>
            <span>Service Pricing</span>
          </h1>
          <p style="margin:0;font-size:0.95rem;">Manage and filter service rates</p>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end;">
          <button class="btn btn-secondary" id="dl-template" style="white-space:nowrap;">${j.download||``}<span>Template</span></button>
          <button class="btn btn-secondary" id="upload-price" style="white-space:nowrap;">${j.upload||``}<span>Upload</span></button>
          <button class="btn btn-primary" id="add-price" style="white-space:nowrap;">${j.plus}<span>Add</span></button>
          <input type="file" id="upload-price-file" accept=".xlsx,.xls,.csv" style="display:none">
          <button class="btn btn-primary" id="admin-pricing-export" style="white-space:nowrap;">${j.download||``}<span>Export</span></button>
        </div>
      </div>

      <div class="card" style="margin-bottom:12px;padding:12px 16px;font-size:13px;color:var(--text-dim);">
        Excel/CSV columns: <b>Main Category</b>, <b>Sub Category</b>, <b>Sub-Sub Category</b>, <b>Price</b>. Sub Category is optional — a 3-column file is also accepted.
      </div>

      <div class="card" style="margin-bottom:14px;">
        <div class="card-body" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;align-items:end;">
          <div class="form-group" style="margin:0;">
            <label>Main Category</label>
            <select id="admin-price-main">
              <option value="all">All categories</option>
              ${i.map(e=>`<option value="${nt(e)}">${Z(e)}</option>`).join(``)}
            </select>
          </div>
          <div class="form-group" style="margin:0;">
            <label>Sub Category</label>
            <select id="admin-price-sub">
              <option value="all">All sub categories</option>
              ${a.map(e=>`<option value="${nt(e)}">${Z(e)}</option>`).join(``)}
            </select>
          </div>
          <div class="form-group" style="margin:0;">
            <label>Search</label>
            <input id="admin-price-search" type="search" placeholder="Search service or issue"/>
          </div>
          <button class="btn btn-secondary" id="admin-price-reset">${j.refresh||``}<span>Reset</span></button>
        </div>
      </div>

      <div class="card">
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;" id="bulk-actions">
          <button class="btn btn-danger btn-sm" id="del-selected" style="display:none;">Delete Selected</button>
          <button class="btn btn-warning btn-sm" id="remove-dupes">Remove Duplicates</button>
        </div>
        <div class="card-header">
          <span class="card-title">Services</span>
          <span id="admin-price-count" style="font-size:0.82rem;color:var(--text-dim);font-weight:700;">${r.length} item${r.length===1?``:`s`}</span>
        </div>
        <div class="table-wrap">
          <table>
            <thead>
              <tr><th style="width:30px;"><input type="checkbox" id="select-all" title="Select all"></th><th>Main Category</th><th>Sub Category</th><th>Service / Issue</th><th>Price</th><th>Actions</th></tr>
            </thead>
            <tbody id="admin-price-body">${o(r)}</tbody>
          </table>
        </div>
      </div>
    `;let s=e.querySelector(`#admin-price-main`),c=e.querySelector(`#admin-price-sub`),l=e.querySelector(`#admin-price-search`),d=e.querySelector(`#admin-price-body`),f=e.querySelector(`#admin-price-count`),p=e.querySelector(`#select-all`),m=e.querySelector(`#del-selected`),h=[...r],g=()=>{let e=s.value;c.innerHTML=`<option value="all">All sub categories</option>`+(e===`all`?a:[...new Set(r.filter(t=>t.category===e).map(e=>e.sub_category||``).filter(Boolean))].sort()).map(e=>`<option value="${e}">${e}</option>`).join(``),c.value=`all`,v()},v=()=>{let e=s.value,t=c.value,n=l.value.trim().toLowerCase();h=r.filter(r=>{let i=r.category||`Service`,a=r.sub_category||``,o=`${r.category||``} ${r.sub_category||``} ${r.sub_sub_category||``} ${r.name||``}`.toLowerCase();return(e===`all`||i===e)&&(t===`all`||a===t)&&(!n||o.includes(n))}),d.innerHTML=o(h),f.textContent=`${h.length} item${h.length===1?``:`s`}`,b(),y()},y=()=>{let t=e.querySelectorAll(`.service-checkbox:checked`).length;m.style.display=t>0?``:`none`},b=()=>{e.querySelectorAll(`.service-checkbox`).forEach(e=>{e.onchange=y}),e.querySelectorAll(`.edit-price`).forEach(t=>{t.onclick=async()=>{let n=r.find(e=>e.id===t.dataset.id);if(!n)return;let i=prompt(`Main Category:`,n.category||`Service`);if(i===null)return;let a=prompt(`Sub Category:`,n.sub_category||``);if(a===null)return;let o=prompt(`Sub-Sub Category:`,n.sub_sub_category||n.name||``);if(!o)return;let s=prompt(`Price (₹):`,String(n.cost||0)),c=parseFloat(s);if(!Number.isFinite(c)||c<0){_(`Invalid price`,`error`);return}let{error:l}=await u.from(`service_pricing`).update({category:i||`Uncategorized`,sub_category:a.trim()||null,sub_sub_category:o,name:o,cost:c}).eq(`id`,n.id);l?_(l.message,`error`):(_(`Service updated`,`success`),$t(e))}}),e.querySelectorAll(`.del-price`).forEach(t=>{t.onclick=async()=>{if(!confirm(`Delete this service?`))return;let{error:n}=await u.from(`service_pricing`).delete().eq(`id`,t.dataset.id);n?_(n.message,`error`):(_(`Service deleted`,`success`),$t(e))}})};s.onchange=g,c.onchange=v,l.oninput=v,p.onchange=()=>{e.querySelectorAll(`.service-checkbox`).forEach(e=>e.checked=p.checked),y()},e.querySelector(`#admin-price-reset`).onclick=()=>{s.value=`all`,c.value=`all`,l.value=``,v()},m.onclick=async()=>{let t=Array.from(e.querySelectorAll(`.service-checkbox:checked`)).map(e=>e.dataset.id);if(!t.length||!confirm(`Delete ${t.length} service${t.length===1?``:`s`}?`))return;let n=0;for(let e of t){let{error:t}=await u.from(`service_pricing`).delete().eq(`id`,e);t||n++}_(`Deleted ${n} service${n===1?``:`s`}`,`success`),$t(e)},e.querySelector(`#remove-dupes`).onclick=async()=>{let t=new Map,n=[];if(r.forEach(e=>{let r=`${e.category}||${e.sub_category}||${e.sub_sub_category}`;t.has(r)?n.push(e.id):t.set(r,e.id)}),!n.length){_(`No duplicates found`,`info`);return}if(!confirm(`Found ${n.length} duplicate service${n.length===1?``:`s`}. Delete them?`))return;let i=0;for(let e of n){let{error:t}=await u.from(`service_pricing`).delete().eq(`id`,e);t||i++}_(`Removed ${i} duplicate${i===1?``:`s`}`,`success`),$t(e)};let x=!1;e.querySelector(`#add-price`).onclick=()=>{if(x)return;let t=prompt(`Enter Main Category:`);if(t===null)return;let n=prompt(`Enter Sub Category (optional):`);if(n===null)return;let r=prompt(`Enter Sub-Sub Category (specific issue):`);if(!r)return;let i=prompt(`Enter Price (₹):`),a=parseFloat(i);if(!Number.isFinite(a)||a<0){_(`Invalid price`,`error`);return}x=!0,(async()=>{try{let{error:i}=await u.from(`service_pricing`).insert({id:crypto.randomUUID?.()||`svc-${Date.now()}`,category:t||`Uncategorized`,sub_category:n.trim()||null,sub_sub_category:r,name:r,cost:a});i?.status===429?_(`Server is busy — please try again in a few seconds`,`error`):i?_(i.message||`Failed to add service`,`error`):(_(`Service added`,`success`),$t(e))}finally{x=!1}})()};let S=e.querySelector(`#upload-price-file`),w=!1;e.querySelector(`#upload-price`).onclick=()=>{if(w){_(`Upload in progress...`,`info`);return}S.click()},S.onchange=async()=>{let t=S.files?.[0];if(t){if(w){_(`Upload already in progress`,`warning`);return}w=!0,S.value=``,_(`Reading ${t.name}...`,`info`);try{let n=await qt(t);if(!n.length){_(`File is empty`,`warning`);return}let{inserted:r,skipped:i}=await Zt(n);r?_(`Imported ${r} service${r===1?``:`s`}${i?` (${i} skipped)`:``}`,`success`):_(`No rows imported${i?` — ${i} skipped`:``}`,`warning`),$t(e)}catch(e){console.error(`[pricing import] failed`,e),_(e.message||`Failed to read file`,`error`)}finally{w=!1}}},e.querySelector(`#dl-template`).onclick=Qt,e.querySelector(`#admin-pricing-export`).onclick=()=>{if(!h.length){_(`No services to export`,`warning`);return}C(`service-pricing-${s.value===`all`?`all-main-categories`:s.value.toLowerCase().replace(/[^a-z0-9]+/g,`-`).replace(/^-+|-+$/g,``)}.csv`,h.map(e=>({main_category:e.category||`Service`,sub_category:e.sub_category||``,service:e.sub_sub_category||e.name||``,price:Number(e.cost)||0})))},b(),y()}catch(t){console.error(`[employee pricing] initialization failed:`,t),e.innerHTML=`
      <div class="card" style="padding:32px;text-align:center;">
        <p style="color:var(--danger);margin:0;font-weight:600;">Could not load service pricing</p>
        <small style="color:var(--text-dim);">${Z(t?.message||`An unexpected error occurred`)}</small>
      </div>
    `}}async function en(e){let[{data:t},{data:n}]=await Promise.all([u.from(`inquiries`).select(`*`).order(`feedback_at`,{ascending:!1}),u.from(`profiles`).select(`id,full_name,role`)]),r=(t||[]).filter(e=>e.feedback_rating!=null),i=new Map((n||[]).map(e=>[e.id,e])),a=new Date().toLocaleDateString(`en-CA`).slice(0,7),o=r.filter(e=>String(e.feedback_at||e.updated_at||``).startsWith(a)),s=new Map;r.forEach(e=>{let t=e.feedback_employee_id||e.assigned_employee_id;if(!t)return;let n=e.employee_rating||e.feedback_rating;if(!n)return;s.has(t)||s.set(t,{total:0,count:0,fiveStars:0});let r=s.get(t);r.total+=Number(n),r.count+=1,n>=5&&(r.fiveStars+=1)});let c=[...s.entries()].map(([e,t])=>({id:e,name:i.get(e)?.full_name||`—`,avg:t.total/t.count,count:t.count,fiveStars:t.fiveStars})).sort((e,t)=>t.avg-e.avg||t.count-e.count),l=new Map;o.forEach(e=>{let t=e.feedback_employee_id||e.assigned_employee_id;if(!t)return;let n=e.employee_rating||e.feedback_rating;if(!n)return;l.has(t)||l.set(t,{total:0,count:0,fiveStars:0});let r=l.get(t);r.total+=Number(n),r.count+=1,n>=5&&(r.fiveStars+=1)});let d=[...l.entries()].map(([e,t])=>({id:e,name:i.get(e)?.full_name||`Employee`,avg:t.total/t.count,count:t.count,fiveStars:t.fiveStars})).sort((e,t)=>t.avg-e.avg||t.count-e.count||t.fiveStars-e.fiveStars)[0]||null,f=r.length?r.reduce((e,t)=>e+Number(t.feedback_rating||0),0)/r.length:0,p=r.filter(e=>e.feedback_rating>=5).length,m=e=>{let t=Math.round(Number(e)||0);return Array.from({length:5},(e,n)=>`<span style="color:${n<t?`var(--warning)`:`var(--border)`};display:inline-flex;width:14px;height:14px">${n<t?j.star:j.starOutline}</span>`).join(``)};e.innerHTML=`    <div class="page-header">      <h1>Client Feedback</h1>      <p>Ratings & comments submitted by clients after service completion</p>    </div>    <div class="stats-grid">      <div class="stat-card"><div class="stat-value">${r.length}</div><div class="stat-label">Total Reviews</div></div>      <div class="stat-card"><div class="stat-value" style="color:var(--warning)">${f.toFixed(2)} <span style="font-size:1rem">/ 5</span></div><div class="stat-label">Overall Average</div></div>      <div class="stat-card"><div class="stat-value" style="color:var(--success)">${p}</div><div class="stat-label">5-Star Reviews</div></div>      <div class="stat-card"><div class="stat-value" style="color:var(--primary)">${c.length}</div><div class="stat-label">Employees Rated</div></div>      <div class="stat-card"><div class="stat-value" style="color:var(--warning);font-size:1.55rem">${d?Z(d.name):`-`}</div><div class="stat-label">Employee of Month</div></div>    </div>    <div class="card">      <div class="card-header"><span class="card-title">Employee Leaderboard</span></div>      <div class="table-wrap">        <table>          <thead><tr><th>Employee</th><th>Average</th><th>Reviews</th><th>5?</th></tr></thead>          <tbody>            ${c.length===0?`<tr><td colspan="4" style="text-align:center;padding:24px;color:var(--text-dim)">No employee-specific ratings yet</td></tr>`:c.map(e=>`<tr>                <td><b>${e.name}</b></td>                <td>${m(e.avg)} <span style="margin-left:6px;font-weight:700">${e.avg.toFixed(2)}</span></td>                <td>${e.count}</td>                <td><span class="badge badge-resolved">${e.fiveStars}</span></td>              </tr>`).join(``)}          </tbody>        </table>      </div>    </div>    <div class="card" style="margin-top:24px">      <div class="card-header" style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;">        <span class="card-title">All Reviews</span>        <div class="search-input-wrap" style="min-width:200px;max-width:320px;">          <span>??</span>          <input class="search-input" id="fb-search" placeholder="Filter by name or ticket…" style="padding:6px 10px;font-size:0.85rem;"/>        </div>      </div>      <div class="table-wrap">        <table id="fb-table">          <thead><tr><th>Date</th><th>Ticket</th><th>Client</th><th>Employee</th><th>Overall</th><th>Employee</th><th>Comment</th></tr></thead>          <tbody>            ${r.length===0?`<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-dim)">No feedback received yet</td></tr>`:r.map(e=>{let t=i.get(e.feedback_employee_id||e.assigned_employee_id)?.full_name||`—`,n=e.employee_rating?`${m(e.employee_rating)} <b style="margin-left:4px">${e.employee_rating}</b>`:`<span style="color:var(--text-dim)">—</span>`;return`<tr data-search="${(e.full_name+` `+(e.ticket_no||``)+` `+t).toLowerCase()}">                  <td><small>${e.feedback_at?y(e.feedback_at):`—`}</small></td>                  <td><code style="font-size:0.75rem;color:var(--primary)">${e.ticket_no||`—`}</code></td>                  <td><b>${e.full_name}</b></td>                  <td>${t}</td>                  <td>${m(e.feedback_rating)} <b style="margin-left:4px">${e.feedback_rating}</b></td>                  <td>${n}</td>                  <td style="max-width:340px;white-space:normal;font-size:.85rem;line-height:1.45;color:var(--text-soft)">${e.feedback_comment||`<span style="color:var(--text-dim)">—</span>`}</td>                </tr>`}).join(``)}          </tbody>        </table>      </div>    </div>  `;let h=e.querySelector(`#fb-search`);h&&(h.oninput=()=>{let t=h.value.toLowerCase();e.querySelectorAll(`#fb-table tbody tr[data-search]`).forEach(e=>{e.style.display=e.dataset.search.includes(t)?``:`none`})});let g=u.channel(`admin-feedback`).on(`postgres_changes`,{event:`UPDATE`,schema:`public`,table:`inquiries`},t=>{t.new?.feedback_rating!=null&&en(e)}).subscribe(),_=setInterval(()=>{document.body.contains(e)||(u.removeChannel(g),clearInterval(_))},5e3)}function Z(e){return String(e??``).replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e])}async function tn(e){e.innerHTML=`<div class="page-header"><h1>Complaints</h1><p>Loading…</p></div>`;let{data:t,error:n}=await u.from(`complaints`).select(`*`).order(`created_at`,{ascending:!1});if(n){e.innerHTML=`<div class="page-header"><h1>Complaints</h1><p style="color:var(--danger)">Could not load complaints: ${Z(n.message||``)}</p></div>`;return}let r=t||[],i=r.filter(e=>e.status===`open`).length,a=r.filter(e=>e.status===`resolved`).length,o=e=>e===`resolved`?`<span class="badge badge-resolved">Resolved</span>`:e===`in_progress`?`<span class="badge badge-in_progress">In Progress</span>`:`<span class="badge badge-danger">Open</span>`;e.innerHTML=`    <div class="page-header">      <h1>Complaints</h1>      <p>Customer complaints filed against existing tickets via the public portal</p>    </div>    <div class="stats-grid">      <div class="stat-card"><div class="stat-value">${r.length}</div><div class="stat-label">Total Complaints</div></div>      <div class="stat-card"><div class="stat-value" style="color:var(--danger)">${i}</div><div class="stat-label">Open</div></div>      <div class="stat-card"><div class="stat-value" style="color:var(--success)">${a}</div><div class="stat-label">Resolved</div></div>    </div>    <div class="card" style="margin-top:24px">      <div class="card-header" style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;">        <span class="card-title">All Complaints</span>        <div class="search-input-wrap" style="min-width:200px;max-width:320px;">          <span>??</span>          <input class="search-input" id="cmp-search" placeholder="Filter by ticket or phone…" style="padding:6px 10px;font-size:0.85rem;"/>        </div>      </div>      <div class="table-wrap">        <table id="cmp-table">          <thead><tr><th>Filed</th><th>Ticket</th><th>Phone</th><th>Complaint</th><th>Status</th><th>Response</th><th>Actions</th></tr></thead>          <tbody>            ${r.length===0?`<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-dim)">No complaints filed yet</td></tr>`:r.map(e=>`                <tr data-search="${Z(((e.ticket_no||``)+` `+(e.phone||``)).toLowerCase())}">                  <td><small>${e.created_at?b(e.created_at):`—`}</small></td>                  <td><code style="font-size:0.75rem;color:var(--primary)">${Z(e.ticket_no||`—`)}</code></td>                  <td><small>${Z(e.phone||`—`)}</small></td>                  <td style="max-width:360px;white-space:normal;font-size:.85rem;line-height:1.45;color:var(--text-soft)">${Z(e.complaint_text||``)}</td>                  <td>${o(e.status)}</td>                  <td style="max-width:260px;white-space:normal;font-size:.82rem;color:var(--text-soft)">${e.admin_response?Z(e.admin_response):`<span style="color:var(--text-dim)">—</span>`}</td>                  <td>                    <button class="btn btn-secondary btn-sm cmp-respond-btn" data-id="${e.id}">${e.status===`resolved`?`View`:`Respond`}</button>                  </td>                </tr>`).join(``)}          </tbody>        </table>      </div>    </div>  `;let s=e.querySelector(`#cmp-search`);s&&(s.oninput=()=>{let t=s.value.toLowerCase();e.querySelectorAll(`#cmp-table tbody tr[data-search]`).forEach(e=>{e.style.display=e.dataset.search.includes(t)?``:`none`})}),e.querySelectorAll(`.cmp-respond-btn`).forEach(t=>{t.onclick=()=>nn(r.find(e=>e.id===t.dataset.id),()=>tn(e))});let c=u.channel(`admin-complaints`).on(`postgres_changes`,{event:`INSERT`,schema:`public`,table:`complaints`},()=>tn(e)).on(`postgres_changes`,{event:`UPDATE`,schema:`public`,table:`complaints`},()=>tn(e)).subscribe(),l=setInterval(()=>{document.body.contains(e)||(u.removeChannel(c),clearInterval(l))},5e3)}function nn(e,t){if(!e)return;let n=document.createElement(`div`);n.className=`modal-overlay`,n.innerHTML=`    <div class="modal" style="max-width:560px">      <div class="modal-header">        <span class="modal-title">Complaint on ${Z(e.ticket_no)}</span>        <button class="modal-close">×</button>      </div>      <div style="padding:0 24px 12px;color:var(--text-soft);font-size:0.85rem;">From ${Z(e.phone)} · ${b(e.created_at)}</div>      <div class="modal-body">        <div style="background:var(--bg-soft);padding:14px;border-radius:12px;font-size:0.9rem;line-height:1.5;color:var(--text);margin-bottom:18px;">          ${Z(e.complaint_text)}        </div>        <label class="srf-label" style="display:block;font-weight:700;font-size:0.85rem;margin-bottom:6px;">Customer response (sent via SMS)</label>        <textarea id="cmp-response" rows="4" placeholder="What did we do or say in reply?" style="width:100%;padding:10px;border-radius:10px;border:1px solid var(--border);background:var(--bg);font-family:inherit;font-size:0.9rem;resize:vertical;">${Z(e.admin_response||``)}</textarea>        <div style="margin-top:6px;font-size:0.78rem;color:var(--text-dim);line-height:1.4;">          ${e.admin_response?`SMS already delivered to <b>${Z(e.phone||``)}</b>. Editing the text and saving will re-send.`:`No SMS has been sent yet. The customer will receive an SMS the moment you save a non-empty response.`}        </div>        <label style="display:block;font-weight:700;font-size:0.85rem;margin:14px 0 6px;">Status</label>        <select id="cmp-status" style="width:100%;padding:10px;border-radius:10px;border:1px solid var(--border);background:var(--bg);font-family:inherit;font-size:0.9rem;">          <option value="open" ${e.status===`open`?`selected`:``}>Open</option>          <option value="in_progress" ${e.status===`in_progress`?`selected`:``}>In Progress</option>          <option value="resolved" ${e.status===`resolved`?`selected`:``}>Resolved</option>        </select>      </div>      <div class="modal-footer">        <button class="btn btn-secondary" id="cmp-cancel">Cancel</button>        <button class="btn btn-primary" id="cmp-save">Save</button>      </div>    </div>  `,document.body.appendChild(n);let r=()=>n.remove();n.querySelector(`.modal-close`).onclick=r,n.querySelector(`#cmp-cancel`).onclick=r,n.addEventListener(`click`,e=>{e.target===n&&r()}),n.querySelector(`#cmp-save`).onclick=async()=>{let i=n.querySelector(`#cmp-response`).value.trim(),a=n.querySelector(`#cmp-status`).value,o=(e.admin_response||``).trim(),s={status:a};i!==o&&(s.admin_response=i||null),a===`resolved`&&!e.resolved_at&&(s.resolved_at=new Date().toISOString().slice(0,19).replace(`T`,` `));let c=Y(n.querySelector(`#cmp-save`),`Saving`),{data:l,error:d}=await u.from(`complaints`).update(s).eq(`id`,e.id);if(c(),d){_(`Could not save: `+(d.message||``),`error`);return}s.admin_response&&l?.sms?.ok===!1?_(`Response saved, but SMS failed: ${l.sms.error||`provider rejected it`}`,`error`):_(s.admin_response?`Response saved and SMS sent`:`Complaint updated`,`success`),r(),t&&t()}}async function rn(e){e.innerHTML=`<div class="page-header"><h1>Landing Page Ads</h1><p>Loading…</p></div>`;let{data:t,error:n}=await u.from(`ads`).select(`*`).order(`position`,{ascending:!0});if(n){e.innerHTML=`<div class="page-header"><h1>Landing Page Ads</h1><p style="color:var(--danger)">Could not load ads: ${Z(n.message||``)}</p></div>`;return}let r=t||[],i=r.filter(e=>e.active).length;e.innerHTML=`    <div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-end;gap:12px;flex-wrap:wrap;">      <div>        <h1>Landing Page Ads</h1>        <p>Slides shown in the rotating carousel on the public service portal</p>      </div>      <button class="btn btn-primary" id="ad-add-btn">+ Add slide</button>    </div>    <div class="stats-grid">      <div class="stat-card"><div class="stat-value">${r.length}</div><div class="stat-label">Total Slides</div></div>      <div class="stat-card"><div class="stat-value" style="color:var(--success)">${i}</div><div class="stat-label">Active</div></div>      <div class="stat-card"><div class="stat-value" style="color:var(--text-dim)">${r.length-i}</div><div class="stat-label">Hidden</div></div>    </div>    <div class="card" style="margin-top:24px">      <div class="card-header"><span class="card-title">Slides (drag order via Position field)</span></div>      <div class="table-wrap">        <table>          <thead><tr><th style="width:60px">Pos</th><th>Preview</th><th>Kind</th><th>Caption</th><th>Duration</th><th>Status</th><th style="width:200px">Actions</th></tr></thead>          <tbody>            ${r.length===0?`<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-dim)">No ads yet — click "Add slide" to create your first one</td></tr>`:r.map(e=>`                <tr>                  <td><b>${e.position??0}</b></td>                  <td>                    ${e.kind===`video`?`<video src="${Z(e.url)}" muted style="width:120px;height:68px;object-fit:cover;border-radius:8px;background:var(--bg-soft);" onmouseover="this.play()" onmouseout="this.pause()"></video>`:`<img src="${Z(e.url)}" alt="" style="width:120px;height:68px;object-fit:cover;border-radius:8px;background:var(--bg-soft);" loading="lazy"/>`}                  </td>                  <td><span class="badge ${e.kind===`video`?`badge-in_progress`:`badge-resolved`}">${e.kind}</span></td>                  <td style="max-width:240px;white-space:normal;font-size:0.85rem;color:var(--text-soft)">${Z(e.caption||``)}</td>                  <td><small>${((Number(e.duration_ms)||6e3)/1e3).toFixed(1)}s</small></td>                  <td>                    <div style="font-size:0.75rem; color:var(--text-soft)">                      <div><b>Start:</b> ${e.starts_at?new Date(e.starts_at).toLocaleString():`Now`}</div>                      <div><b>End:</b> ${e.expires_at?new Date(e.expires_at).toLocaleString():`Never`}</div>                    </div>                  </td>                  <td>${e.active?`<span class="badge badge-resolved">Active</span>`:`<span class="badge badge-danger">Hidden</span>`}</td>                  <td>                    <button class="btn btn-secondary btn-sm ad-edit-btn" data-id="${e.id}">Edit</button>                    <button class="btn btn-secondary btn-sm ad-toggle-btn" data-id="${e.id}">${e.active?`Hide`:`Show`}</button>                    <button class="btn btn-secondary btn-sm ad-delete-btn" data-id="${e.id}" style="color:var(--danger)">Delete</button>                  </td>                </tr>`).join(``)}          </tbody>        </table>      </div>    </div>  `;let a=()=>rn(e);e.querySelector(`#ad-add-btn`).onclick=()=>an(null,a),e.querySelectorAll(`.ad-edit-btn`).forEach(e=>{e.onclick=()=>an(r.find(t=>t.id===e.dataset.id),a)}),e.querySelectorAll(`.ad-toggle-btn`).forEach(e=>{e.onclick=async()=>{let t=r.find(t=>t.id===e.dataset.id),{error:n}=await u.from(`ads`).update({active:+!t.active}).eq(`id`,t.id);if(n)return _(`Could not update: `+(n.message||``),`error`);_(t.active?`Slide hidden`:`Slide shown`,`success`),a()}}),e.querySelectorAll(`.ad-delete-btn`).forEach(e=>{e.onclick=async()=>{if(!confirm(`Delete this slide? This cannot be undone.`))return;let{error:t}=await u.from(`ads`).delete().eq(`id`,e.dataset.id);if(t)return _(`Could not delete: `+(t.message||``),`error`);_(`Slide deleted`,`success`),a()}})}function an(e,t){let n=!!e,r=document.createElement(`div`);r.className=`modal-overlay`,r.innerHTML=`    <div class="modal" style="max-width:560px">      <div class="modal-header">        <span class="modal-title">${n?`Edit slide`:`Add slide`}</span>        <button class="modal-close">×</button>      </div>      <div class="modal-body">        <label style="display:block;font-weight:700;font-size:0.85rem;margin-bottom:6px;">Slide type</label>        <div style="display:flex;gap:8px;margin-bottom:14px;">          <label style="flex:1;padding:10px;border:2px solid var(--border);border-radius:10px;cursor:pointer;text-align:center;font-weight:700;">            <input type="radio" name="ad-kind" value="image" ${!e||e.kind===`image`?`checked`:``} style="margin-right:6px"/> Image          </label>          <label style="flex:1;padding:10px;border:2px solid var(--border);border-radius:10px;cursor:pointer;text-align:center;font-weight:700;">            <input type="radio" name="ad-kind" value="video" ${e?.kind===`video`?`checked`:``} style="margin-right:6px"/> Video          </label>        </div>        <div style="margin-bottom:14px;">          <label style="display:block;font-weight:700;font-size:0.85rem;margin-bottom:6px;">Media Source</label>          <div style="display:flex;gap:8px;margin-bottom:8px;">            <label style="font-size:0.85rem;cursor:pointer;"><input type="radio" name="media-source" value="upload" checked> Upload File</label>            <label style="font-size:0.85rem;cursor:pointer;"><input type="radio" name="media-source" value="url"> Enter URL</label>          </div>                    <div id="media-upload-div">            <input type="file" id="ad-file" accept="image/*,video/*" style="width:100%;padding:8px;border-radius:10px;border:1px dashed var(--border);background:var(--bg);font-size:0.9rem;" />          </div>          <div id="media-url-div" style="display:none;">            <input id="ad-url" type="url" placeholder="https://…/image.jpg or https://…/video.mp4"                   value="${Z(e?.url||``)}"                   style="width:100%;padding:10px;border-radius:10px;border:1px solid var(--border);background:var(--bg);font-family:inherit;font-size:0.9rem;"/>          </div>          ${e?.url?`<div style="font-size:0.8rem;color:var(--text-dim);margin-top:6px;overflow:hidden;text-overflow:ellipsis;">Current URL: <a href="${Z(e.url)}" target="_blank" style="color:var(--primary)">${Z(e.url)}</a></div>`:``}        </div>        <label style="display:block;font-weight:700;font-size:0.85rem;margin-bottom:6px;">Caption <span style="color:var(--text-dim);font-weight:500">(optional, max 255 chars)</span></label>        <input id="ad-caption" type="text" maxlength="255" placeholder="Short overlay text"               value="${Z(e?.caption||``)}"               style="width:100%;padding:10px;border-radius:10px;border:1px solid var(--border);background:var(--bg);font-family:inherit;font-size:0.9rem;margin-bottom:14px;"/>        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px;">          <div>            <label style="display:block;font-weight:700;font-size:0.85rem;margin-bottom:6px;">Duration (seconds)</label>            <input id="ad-duration" type="number" min="2" max="60" step="0.5"                   value="${e?(Number(e.duration_ms)||6e3)/1e3:6}"                   style="width:100%;padding:10px;border-radius:10px;border:1px solid var(--border);background:var(--bg);font-family:inherit;font-size:0.9rem;"/>          </div>          <div>            <label style="display:block;font-weight:700;font-size:0.85rem;margin-bottom:6px;">Position</label>            <input id="ad-position" type="number" min="0" step="1"                   value="${e?.position??0}"                   style="width:100%;padding:10px;border-radius:10px;border:1px solid var(--border);background:var(--bg);font-family:inherit;font-size:0.9rem;"/>          </div>        </div>        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px;">          <div>            <label style="display:block;font-weight:700;font-size:0.85rem;margin-bottom:6px;">Starts At (optional)</label>            <input id="ad-starts" type="datetime-local"                   value="${e?.starts_at?new Date(new Date(e.starts_at).getTime()-new Date().getTimezoneOffset()*6e4).toISOString().slice(0,16):``}"                   style="width:100%;padding:10px;border-radius:10px;border:1px solid var(--border);background:var(--bg);font-family:inherit;font-size:0.9rem;"/>          </div>          <div>            <label style="display:block;font-weight:700;font-size:0.85rem;margin-bottom:6px;">Expires At (optional)</label>            <input id="ad-expires" type="datetime-local"                   value="${e?.expires_at?new Date(new Date(e.expires_at).getTime()-new Date().getTimezoneOffset()*6e4).toISOString().slice(0,16):``}"                   style="width:100%;padding:10px;border-radius:10px;border:1px solid var(--border);background:var(--bg);font-family:inherit;font-size:0.9rem;"/>          </div>        </div>        <label style="display:flex;align-items:center;gap:8px;font-weight:700;font-size:0.9rem;">          <input id="ad-active" type="checkbox" ${!e||e.active?`checked`:``}/>          Active (show on landing page)        </label>      </div>      <div class="modal-footer">        <button class="btn btn-secondary" id="ad-cancel">Cancel</button>        <button class="btn btn-primary" id="ad-save">${n?`Save`:`Add slide`}</button>      </div>    </div>  `,document.body.appendChild(r);let i=()=>r.remove();r.querySelector(`.modal-close`).onclick=i,r.querySelector(`#ad-cancel`).onclick=i,r.addEventListener(`click`,e=>{e.target===r&&i()}),r.querySelectorAll(`input[name="media-source"]`).forEach(e=>{e.onchange=()=>{r.querySelector(`#media-upload-div`).style.display=e.value===`upload`?`block`:`none`,r.querySelector(`#media-url-div`).style.display=e.value===`url`?`block`:`none`}}),r.querySelector(`#ad-save`).onclick=async()=>{let a=r.querySelector(`input[name="ad-kind"]:checked`).value,o=r.querySelector(`#ad-caption`).value.trim(),s=parseFloat(r.querySelector(`#ad-duration`).value),c=parseInt(r.querySelector(`#ad-position`).value,10)||0,l=r.querySelector(`#ad-starts`).value,d=r.querySelector(`#ad-expires`).value,f=+!!r.querySelector(`#ad-active`).checked,p=r.querySelector(`#ad-url`).value.trim(),m=r.querySelector(`input[name="media-source"][value="upload"]`).checked,h=r.querySelector(`#ad-file`);if(m&&h.files.length>0){let e=r.querySelector(`#ad-save`);e.disabled=!0,e.textContent=`Uploading...`;let t=new FormData;t.append(`file`,h.files[0]);try{let e=window.location.hostname!==`localhost`&&window.location.hostname!==`127.0.0.1`?`/api/upload`:`http://localhost:5000/api/upload`,n=await fetch(e,{method:`POST`,headers:{Authorization:`Bearer ${localStorage.getItem(`auth_token`)}`},body:t}),r=await n.json();if(!n.ok)throw Error(r.error||`Upload failed`);p=r.url}catch(t){return e.disabled=!1,e.textContent=n?`Save`:`Add slide`,_(t.message,`error`)}}if(!p)if(e?.url)p=e.url;else return _(`Media File or URL is required`,`error`);if(!/^https?:\/\//i.test(p)&&!p.startsWith(`/uploads/`))return _(`URL must start with http(s):// or /uploads/`,`error`);if(!Number.isFinite(s)||s<2)return _(`Duration must be at least 2 seconds`,`error`);let g={kind:a,url:p,caption:o||null,duration_ms:Math.round(s*1e3),position:c,starts_at:l?new Date(l).toISOString().slice(0,19).replace(`T`,` `):null,expires_at:d?new Date(d).toISOString().slice(0,19).replace(`T`,` `):null,active:f},v;if(v=n?await u.from(`ads`).update(g).eq(`id`,e.id):await u.from(`ads`).insert(g),v.error)return _(`Could not save: `+(v.error.message||``),`error`);_(n?`Slide updated`:`Slide added`,`success`),i(),t&&t()}}async function on(e){let t=window.location.hostname!==`localhost`&&window.location.hostname!==`127.0.0.1`?`/api`:`http://localhost:5000/api`,n=()=>({"Content-Type":`application/json`,Authorization:`Bearer ${localStorage.getItem(`auth_token`)||``}`}),r=`18:00`;try{let e=await fetch(`${t}/settings/attendance`,{headers:n()});e.ok&&(r=(await e.json()).autoClockOutTime||r)}catch(e){console.warn(`[settings] could not load attendance settings`,e)}let{data:i}=await u.from(`attendance`).select(`user_id,clock_in,clock_out,date`),a=vt(i||[]),o=Array.from(a.entries()).filter(([,e])=>e.length>=pt).map(([e])=>e),{data:s}=await u.from(`profiles`).select(`id,full_name,role`).eq(`role`,`employee`),c=(s||[]).filter(e=>o.includes(e.id));e.innerHTML=`
    <div class="page-header settings-header">
      <div class="settings-title-wrap">
        <span class="settings-title-icon">${j.settings}</span>
        <div>
          <h1>Settings</h1>
          <p>Configure system preferences and manage attendance restrictions.</p>
        </div>
      </div>
    </div>

    <div class="settings-grid">
      <div class="settings-card">
        <div class="settings-card-head">
          <span class="settings-card-icon">${j.clock}</span>
          <div>
            <h3>Auto Clock-Out Time</h3>
            <p>Set the daily fallback clock-out time for active employees.</p>
          </div>
        </div>

        <div class="settings-alert settings-alert-danger">
          <span>${j.alert}</span>
          <small>Changing this affects all employees globally. Changes apply to the server job immediately.</small>
        </div>

        <div class="settings-form-row">
          <label class="sr-only" for="auto-clockout-time">Auto clock-out time</label>
          <input type="time" id="auto-clockout-time" value="${r}" class="settings-time-input">
          <button class="btn btn-primary settings-save-btn" id="save-clockout-time">
            ${j.check}
            <span>Save Time</span>
          </button>
        </div>

        <p class="settings-helper">
          Employees clocked in after this time will be auto-clocked out. Current: <b id="current-clockout-time">${r}</b>
        </p>
      </div>

      <div class="settings-card">
        <div class="settings-card-head">
          <span class="settings-card-icon settings-card-icon-danger">${j.block}</span>
          <div>
            <h3>Restrictions (${c.length})</h3>
            <p>Employees with repeated missed clock-outs are blocked from clocking in.</p>
          </div>
        </div>

        <div class="settings-alert settings-alert-info">
          <span>${j.alert}</span>
          <small>Employees with 4+ missed clock-outs cannot clock in.</small>
        </div>

        ${c.length===0?`<div class="settings-empty">
              <span>${j.check}</span>
              <p>No restricted employees</p>
            </div>`:`<div class="settings-restriction-list">
              ${c.map(e=>`
                <div class="settings-restriction-row">
                  <div class="settings-employee">
                    <span class="settings-employee-avatar">${(e.full_name||`E`).trim().charAt(0).toUpperCase()}</span>
                    <div>
                      <b>${e.full_name}</b>
                      <small>${e.id.slice(0,8)}...</small>
                    </div>
                  </div>
                  <button class="btn btn-secondary btn-sm remove-restriction" data-id="${e.id}" data-name="${e.full_name}">
                    ${j.refresh}
                    <span>Unlock</span>
                  </button>
                </div>
              `).join(``)}
            </div>`}
      </div>
    </div>

    <div class="settings-notes">
      <span class="settings-notes-icon">${j.alert}</span>
      <div>
        <b>Important Notes</b>
        <ul>
          <li>Auto clock-out time changes apply immediately on the server</li>
          <li>Unlocking employees automatically fixes their oldest missed clock-outs</li>
          <li>Changes are immediate but server must be running for them to apply</li>
        </ul>
      </div>
    </div>
  `,e.querySelector(`#save-clockout-time`).onclick=async()=>{let i=e.querySelector(`#auto-clockout-time`),a=i.value;if(!a){_(`Please select a time`,`warning`);return}let o=Y(e.querySelector(`#save-clockout-time`),`Saving`);try{let o=await fetch(`${t}/settings/attendance`,{method:`PUT`,headers:n(),body:JSON.stringify({autoClockOutTime:a})}),s=await o.json().catch(()=>({}));if(!o.ok)throw Error(s.error||`Could not save clock-out time`);r=s.autoClockOutTime||a,i.value=r;let c=e.querySelector(`#current-clockout-time`);c&&(c.textContent=r),_(`Auto clock-out time saved: ${r}`,`success`)}catch(e){_(e.message||`Could not save clock-out time`,`error`)}finally{o()}},e.querySelectorAll(`.remove-restriction`).forEach(t=>{t.onclick=async()=>{let n=t.dataset.id,r=t.dataset.name;if(!confirm(`Remove clock-out restriction for ${r}?`))return;let a=(i||[]).filter(e=>e.user_id===n).filter(e=>_t(e));if(a.length>=pt){let e=a.slice(0,a.length-pt+1),t=0;for(let n of e){let{error:e}=await u.from(`attendance`).update({clock_out:yt(n)}).eq(`id`,n.id);e||t++}_(`Fixed ${t} clock-out record${t===1?``:`s`} for ${r}`,`success`)}else _(`Employee is not restricted`,`info`);on(e)}})}function sn(e){return String(e??``).replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e])}function cn(e){return sn(e)}function ln(e,t=`Saving`){if(!e)return()=>{};let n=e.innerHTML;return e.disabled=!0,e.classList.add(`is-loading`),e.innerHTML=`<span class="btn-spinner"></span><span>${t}</span>`,()=>{e.disabled=!1,e.classList.remove(`is-loading`),e.innerHTML=n}}function un(e){if(!e)return``;let t=new Date(e);return Number.isNaN(t.getTime())?``:new Date(t.getTime()-t.getTimezoneOffset()*6e4).toISOString().slice(0,16)}async function dn(e){A(e);let{data:t,error:n}=await u.from(`notices`).select(`*`).order(`created_at`,{ascending:!1});if(n){e.innerHTML=`<div class="card"><div class="card-body" style="text-align:center;padding:40px;color:var(--danger);">Could not load notices: ${sn(n.message||``)}</div></div>`;return}let r=t||[],i=r.filter(e=>Number(e.active)===1).length;e.innerHTML=`
    <div class="page-header admin-notice-header">
      <div>
        <h1><span>${j.clipboard}</span> Notice Board</h1>
        <p>Publish staff notices directly to the employee dashboard</p>
      </div>
      <button class="btn btn-primary" id="notice-add-btn">${j.plus}<span>New Notice</span></button>
    </div>
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-value">${r.length}</div><div class="stat-label">Total Notices</div></div>
      <div class="stat-card"><div class="stat-value" style="color:var(--success)">${i}</div><div class="stat-label">Active</div></div>
      <div class="stat-card"><div class="stat-value" style="color:var(--text-dim)">${r.length-i}</div><div class="stat-label">Hidden</div></div>
    </div>
    <div class="admin-notice-grid">
      ${r.length===0?`
        <div class="card"><div class="card-body admin-notice-empty">${j.clipboard}<p>No notices yet</p></div></div>
      `:r.map(e=>`
        <article class="admin-notice-card notice-${cn(e.priority||`normal`)}">
          <div class="admin-notice-top">
            <span class="admin-notice-icon">${e.priority===`urgent`?j.alert:e.priority===`high`?j.star:j.clipboard}</span>
            <div>
              <span class="badge ${Number(e.active)===1?`badge-resolved`:`badge-danger`}">${Number(e.active)===1?`Active`:`Hidden`}</span>
              <span class="badge badge-${e.priority===`urgent`?`danger`:e.priority===`high`?`medium`:`open`}">${sn(e.priority||`normal`)}</span>
            </div>
          </div>
          <h3>${sn(e.title)}</h3>
          <p>${sn(e.body)}</p>
          <small>Posted ${b(e.created_at)}${e.expires_at?` · Expires ${b(e.expires_at)}`:``}</small>
          <div class="admin-notice-actions">
            <button class="btn btn-secondary btn-sm notice-edit-btn" data-id="${cn(e.id)}">${j.edit}<span>Edit</span></button>
            <button class="btn btn-secondary btn-sm notice-toggle-btn" data-id="${cn(e.id)}">${Number(e.active)===1?`Hide`:`Show`}</button>
            <button class="btn btn-secondary btn-sm notice-delete-btn" data-id="${cn(e.id)}" style="color:var(--danger)">${j.close}<span>Delete</span></button>
          </div>
        </article>
      `).join(``)}
    </div>
  `;let a=()=>dn(e);e.querySelector(`#notice-add-btn`).onclick=()=>fn(null,a),e.querySelectorAll(`.notice-edit-btn`).forEach(e=>{e.onclick=()=>fn(r.find(t=>t.id===e.dataset.id),a)}),e.querySelectorAll(`.notice-toggle-btn`).forEach(e=>{e.onclick=async()=>{let t=r.find(t=>t.id===e.dataset.id),{error:n}=await u.from(`notices`).update({active:Number(t.active)===1?0:1}).eq(`id`,t.id);if(n)return _(`Could not update notice: `+(n.message||``),`error`);_(Number(t.active)===1?`Notice hidden`:`Notice published`,`success`),a()}}),e.querySelectorAll(`.notice-delete-btn`).forEach(e=>{e.onclick=async()=>{if(!confirm(`Delete this notice?`))return;let{error:t}=await u.from(`notices`).delete().eq(`id`,e.dataset.id);if(t)return _(`Could not delete notice: `+(t.message||``),`error`);_(`Notice deleted`,`success`),a()}})}function fn(e,t){let n=!!e,r=document.createElement(`div`);r.className=`modal-overlay`,r.innerHTML=`
    <div class="modal" style="max-width:560px">
      <div class="modal-header">
        <span class="modal-title">${n?`Edit Notice`:`New Notice`}</span>
        <button class="modal-close">×</button>
      </div>
      <div class="modal-body">
        <label class="notice-editor-label">Title</label>
        <input id="notice-title" maxlength="160" value="${cn(e?.title||``)}" placeholder="Morning briefing at 10 AM" class="notice-editor-input">
        <label class="notice-editor-label">Notice Message</label>
        <textarea id="notice-body" rows="5" placeholder="Write the update employees should see..." class="notice-editor-input notice-editor-textarea">${sn(e?.body||``)}</textarea>
        <div class="notice-editor-grid">
          <div>
            <label class="notice-editor-label">Priority</label>
            <select id="notice-priority" class="notice-editor-input">
              <option value="normal" ${(e?.priority||`normal`)===`normal`?`selected`:``}>Normal</option>
              <option value="high" ${e?.priority===`high`?`selected`:``}>High</option>
              <option value="urgent" ${e?.priority===`urgent`?`selected`:``}>Urgent</option>
            </select>
          </div>
          <div>
            <label class="notice-editor-label">Expires At</label>
            <input id="notice-expires" type="datetime-local" value="${un(e?.expires_at)}" class="notice-editor-input">
          </div>
        </div>
        <label class="notice-editor-check">
          <input id="notice-active" type="checkbox" ${!e||Number(e.active)===1?`checked`:``}>
          Publish to employee dashboard
        </label>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" id="notice-cancel">Cancel</button>
        <button class="btn btn-primary" id="notice-save">${n?`Save Notice`:`Publish Notice`}</button>
      </div>
    </div>
  `,document.body.appendChild(r);let i=()=>r.remove();r.querySelector(`.modal-close`).onclick=i,r.querySelector(`#notice-cancel`).onclick=i,r.addEventListener(`click`,e=>{e.target===r&&i()}),r.querySelector(`#notice-save`).onclick=async()=>{let a=r.querySelector(`#notice-title`).value.trim(),o=r.querySelector(`#notice-body`).value.trim(),s=r.querySelector(`#notice-priority`).value,c=r.querySelector(`#notice-expires`).value,l=+!!r.querySelector(`#notice-active`).checked;if(!a)return _(`Notice title is required`,`warning`);if(!o)return _(`Notice message is required`,`warning`);let d={title:a,body:o,priority:s,active:l,expires_at:c?new Date(c).toISOString().slice(0,19).replace(`T`,` `):null};if(!n){let{data:{user:e}}=await u.auth.getUser();d.created_by=e?.id||null}let f=ln(r.querySelector(`#notice-save`),`Saving`),p=n?await u.from(`notices`).update(d).eq(`id`,e.id):await u.from(`notices`).insert(d);if(f(),p.error)return _(`Could not save notice: `+(p.error.message||``),`error`);_(n?`Notice updated`:`Notice published`,`success`),i(),t&&t()}}var pn=e=>`₹${Math.round(Number(e)||0).toLocaleString(`en-IN`)}`;function mn(e){return String(e??``).replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e])}function hn(e){if(!e)return``;let t=String(e).trim(),n=/^(\d{4}-\d{2}-\d{2})/.exec(t);if(n)return n[1];let r=new Date(t.replace(` `,`T`));return Number.isNaN(r.getTime())?``:r.toLocaleDateString(`en-CA`)}function gn(e){let t=new Date,n=t.toLocaleDateString(`en-CA`),r=new Date(t);if(e===`daily`)return{from:n,to:n};if(e===`weekly`)r.setDate(t.getDate()-6);else if(e===`monthly`)r.setMonth(t.getMonth(),1);else if(e===`yearly`)r.setMonth(0,1);else return{from:``,to:``};return{from:r.toLocaleDateString(`en-CA`),to:n}}function _n(e){return hn(e.payment_received_at||e.cash_collected_at||e.bill_generated_at||e.updated_at||e.created_at)}function vn(e,t){return e.filter(e=>{let n=_n(e);return!(t.from&&n&&n<t.from||t.to&&n&&n>t.to||t.employee&&t.employee!==`all`&&e.assigned_employee_id!==t.employee)})}function yn(e){let t=e.filter(e=>e.payment_method===`cash`),n=e.filter(e=>e.payment_method!==`cash`);return{cashAmount:t.reduce((e,t)=>e+(Number(t.bill_total)||0),0),onlineAmount:n.reduce((e,t)=>e+(Number(t.bill_total)||0),0),cashCount:t.length,onlineCount:n.length}}function bn(e,t){return`
    <div class="table-wrap">
      <table>
        <thead><tr><th>Date</th><th>Ticket</th><th>Customer</th><th>Employee</th><th>Mode</th><th>Amount</th></tr></thead>
        <tbody>
          ${e.length===0?`<tr><td colspan="6" style="text-align:center;padding:32px;color:var(--text-dim)">No collections found</td></tr>`:e.map(e=>`
            <tr>
              <td><small style="color:var(--text-dim)">${_n(e)?y(_n(e)):`-`}</small></td>
              <td><code style="font-size:0.75rem;color:var(--primary)">${mn(e.ticket_no||`-`)}</code></td>
              <td><b>${mn(e.full_name||`Client`)}</b><br/><small style="color:var(--text-dim)">${mn(e.service_item||``)}</small></td>
              <td>${mn(t.get(e.assigned_employee_id)?.full_name||`Employee`)}</td>
              <td><span class="badge ${e.payment_method===`cash`?`badge-medium`:`badge-resolved`}">${e.payment_method===`cash`?`Cash`:`Online`}</span></td>
              <td><b>${pn(e.bill_total)}</b></td>
            </tr>
          `).join(``)}
        </tbody>
      </table>
    </div>
  `}async function xn(e){A(e);let{data:{user:t}}=await u.auth.getUser();if(!t){e.innerHTML=`<p>Please sign in.</p>`;return}let{data:n}=await u.from(`inquiries`).select(`*`).eq(`assigned_employee_id`,t.id).eq(`payment_status`,`paid`).order(`payment_received_at`,{ascending:!1}),r=Array.isArray(n)?n.filter(e=>Number(e.bill_total)>0):[],i={...gn(e.dataset.period||`monthly`)};i.from=e.dataset.from||i.from,i.to=e.dataset.to||i.to;let a=vn(r,i),o=yn(a);e.innerHTML=`
    <div class="page-header collection-header">
      <div>
        <h1>My Collections</h1>
        <p>Your own cash and online payment totals</p>
      </div>
      <button class="btn btn-secondary" id="collections-refresh">${j.refresh}<span>Refresh</span></button>
    </div>
    <div class="collection-filters">
      ${[`daily`,`weekly`,`monthly`,`yearly`,`all`].map(t=>`<button class="sr-filter ${t===(e.dataset.period||`monthly`)?`active`:``}" data-period="${t}">${t}</button>`).join(``)}
      <input type="date" id="coll-from" value="${i.from}">
      <input type="date" id="coll-to" value="${i.to}">
      <button class="btn btn-secondary btn-sm" id="coll-apply">Apply</button>
    </div>
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-value" style="color:var(--warning)">${pn(o.cashAmount)}</div><div class="stat-label">Cash (${o.cashCount})</div></div>
      <div class="stat-card"><div class="stat-value" style="color:var(--success)">${pn(o.onlineAmount)}</div><div class="stat-label">Online (${o.onlineCount})</div></div>
      <div class="stat-card"><div class="stat-value" style="color:var(--primary)">${pn(o.cashAmount+o.onlineAmount)}</div><div class="stat-label">Total Collection</div></div>
    </div>
    <div class="card">${bn(a,new Map)}</div>
  `,e.querySelector(`#collections-refresh`).onclick=()=>xn(e),e.querySelectorAll(`.collection-filters .sr-filter`).forEach(t=>{t.onclick=()=>{e.dataset.period=t.dataset.period,e.dataset.from=``,e.dataset.to=``,xn(e)}}),e.querySelector(`#coll-apply`).onclick=()=>{e.dataset.period=`custom`,e.dataset.from=e.querySelector(`#coll-from`).value,e.dataset.to=e.querySelector(`#coll-to`).value,xn(e)}}async function Sn(e){A(e);let[{data:t},{data:n}]=await Promise.all([u.from(`inquiries`).select(`*`).eq(`payment_status`,`paid`).order(`payment_received_at`,{ascending:!1}),u.from(`profiles`).select(`id,full_name,phone`).eq(`role`,`employee`)]),r=(t||[]).filter(e=>Number(e.bill_total)>0),i=n||[],a=new Map(i.map(e=>[e.id,e])),o=gn(e.dataset.period||`monthly`),s={from:e.dataset.from||o.from,to:e.dataset.to||o.to,employee:e.dataset.employee||`all`},c=vn(r,s),l=yn(c),d=new Map;c.forEach(e=>{let t=e.assigned_employee_id||`unassigned`;d.has(t)||d.set(t,[]),d.get(t).push(e)});let f=[...d.entries()].map(([e,t])=>{let n=yn(t);return{id:e,name:a.get(e)?.full_name||`Unassigned`,...n}}).sort((e,t)=>t.cashAmount+t.onlineAmount-(e.cashAmount+e.onlineAmount));e.innerHTML=`
    <div class="page-header collection-header">
      <div>
        <h1>Collection Reports</h1>
        <p>Cash and online totals by employee and grand total</p>
      </div>
      <button class="btn btn-primary" id="coll-export">${j.download}<span>Export</span></button>
    </div>
    <div class="collection-filters">
      ${[`daily`,`weekly`,`monthly`,`yearly`,`all`].map(t=>`<button class="sr-filter ${t===(e.dataset.period||`monthly`)?`active`:``}" data-period="${t}">${t}</button>`).join(``)}
      <select id="coll-employee">
        <option value="all">All employees</option>
        ${i.map(e=>`<option value="${e.id}" ${s.employee===e.id?`selected`:``}>${mn(e.full_name||e.phone||e.id)}</option>`).join(``)}
      </select>
      <input type="date" id="coll-from" value="${s.from}">
      <input type="date" id="coll-to" value="${s.to}">
      <button class="btn btn-secondary btn-sm" id="coll-apply">Apply</button>
    </div>
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-value" style="color:var(--warning)">${pn(l.cashAmount)}</div><div class="stat-label">Grand Cash (${l.cashCount})</div></div>
      <div class="stat-card"><div class="stat-value" style="color:var(--success)">${pn(l.onlineAmount)}</div><div class="stat-label">Grand Online (${l.onlineCount})</div></div>
      <div class="stat-card"><div class="stat-value" style="color:var(--primary)">${pn(l.cashAmount+l.onlineAmount)}</div><div class="stat-label">Grand Total</div></div>
    </div>
    <div class="card" style="margin-bottom:20px;">
      <div class="card-header"><span class="card-title">By Employee</span></div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Employee</th><th>Cash</th><th>Online</th><th>Total</th></tr></thead>
          <tbody>${f.length===0?`<tr><td colspan="4" style="text-align:center;padding:28px;color:var(--text-dim)">No collections found</td></tr>`:f.map(e=>`
            <tr><td><b>${mn(e.name)}</b></td><td>${pn(e.cashAmount)} <small>(${e.cashCount})</small></td><td>${pn(e.onlineAmount)} <small>(${e.onlineCount})</small></td><td><b>${pn(e.cashAmount+e.onlineAmount)}</b></td></tr>
          `).join(``)}</tbody>
        </table>
      </div>
    </div>
    <div class="card">${bn(c,a)}</div>
  `,e.querySelectorAll(`.collection-filters .sr-filter`).forEach(t=>{t.onclick=()=>{e.dataset.period=t.dataset.period,e.dataset.from=``,e.dataset.to=``,Sn(e)}}),e.querySelector(`#coll-apply`).onclick=()=>{e.dataset.period=`custom`,e.dataset.employee=e.querySelector(`#coll-employee`).value,e.dataset.from=e.querySelector(`#coll-from`).value,e.dataset.to=e.querySelector(`#coll-to`).value,Sn(e)},e.querySelector(`#coll-export`).onclick=()=>C(`collection-report.csv`,c.map(e=>({date:_n(e),ticket:e.ticket_no||``,customer:e.full_name||``,employee:a.get(e.assigned_employee_id)?.full_name||``,payment_method:e.payment_method===`cash`?`cash`:`online`,amount:Number(e.bill_total)||0})))}var Cn=e=>`₹${Math.round(Number(e)||0).toLocaleString(`en-IN`)}`,Q=e=>String(e??``).replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e]);async function wn(e){A(e);let{data:t,error:n}=await u.from(`discount_presets`).select(`*`).order(`created_at`,{ascending:!1});if(n){e.innerHTML=`<div class="card"><div class="card-body" style="color:var(--danger)">Could not load discounts: ${Q(n.message)}</div></div>`;return}let r=t||[];e.innerHTML=`
    <div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-end;gap:14px;flex-wrap:wrap;">
      <div><h1>Discounts</h1><p>Create predefined discounts employees can select while billing</p></div>
      <button class="btn btn-primary" id="discount-add">${j.plus}<span>Add Discount</span></button>
    </div>
    <div class="card">
      <div class="table-wrap">
        <table>
          <thead><tr><th>Name</th><th>Amount</th><th>Description</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            ${r.length===0?`<tr><td colspan="5" style="text-align:center;padding:32px;color:var(--text-dim)">No discount presets yet</td></tr>`:r.map(e=>`
              <tr>
                <td><b>${Q(e.name)}</b></td>
                <td><b style="color:var(--success)">${Cn(e.amount)}</b></td>
                <td style="max-width:360px;white-space:normal;color:var(--text-soft)">${Q(e.description||`-`)}</td>
                <td><span class="badge ${Number(e.active)===1?`badge-resolved`:`badge-danger`}">${Number(e.active)===1?`Active`:`Hidden`}</span></td>
                <td>
                  <button class="btn btn-secondary btn-sm discount-edit" data-id="${Q(e.id)}">${j.edit}<span>Edit</span></button>
                  <button class="btn btn-secondary btn-sm discount-toggle" data-id="${Q(e.id)}">${Number(e.active)===1?`Hide`:`Show`}</button>
                  <button class="btn btn-secondary btn-sm discount-delete" data-id="${Q(e.id)}" style="color:var(--danger)">${j.close}<span>Delete</span></button>
                </td>
              </tr>
            `).join(``)}
          </tbody>
        </table>
      </div>
    </div>
  `;let i=()=>wn(e);e.querySelector(`#discount-add`).onclick=()=>Tn(null,i),e.querySelectorAll(`.discount-edit`).forEach(e=>e.onclick=()=>Tn(r.find(t=>t.id===e.dataset.id),i)),e.querySelectorAll(`.discount-toggle`).forEach(e=>e.onclick=async()=>{let t=r.find(t=>t.id===e.dataset.id),{error:n}=await u.from(`discount_presets`).update({active:Number(t.active)===1?0:1}).eq(`id`,t.id);if(n)return _(n.message,`error`);_(Number(t.active)===1?`Discount hidden`:`Discount active`,`success`),i()}),e.querySelectorAll(`.discount-delete`).forEach(e=>e.onclick=async()=>{if(!confirm(`Delete this discount?`))return;let{error:t}=await u.from(`discount_presets`).delete().eq(`id`,e.dataset.id);if(t)return _(t.message,`error`);_(`Discount deleted`,`success`),i()})}function Tn(e,t){let n=document.createElement(`div`);n.className=`modal-overlay`,n.innerHTML=`
    <div class="modal" style="max-width:520px">
      <div class="modal-header"><span class="modal-title">${e?`Edit Discount`:`Add Discount`}</span><button class="modal-close">×</button></div>
      <div class="modal-body">
        <label class="notice-editor-label">Discount Name</label>
        <input id="disc-name" class="notice-editor-input" value="${Q(e?.name||``)}" placeholder="Festival offer">
        <label class="notice-editor-label">Amount</label>
        <input id="disc-amount" class="notice-editor-input" type="number" min="0" step="1" value="${e?.amount||``}" placeholder="100">
        <label class="notice-editor-label">Description</label>
        <textarea id="disc-desc" class="notice-editor-input notice-editor-textarea" rows="3" placeholder="Shown to employees while billing">${Q(e?.description||``)}</textarea>
        <label class="notice-editor-check"><input id="disc-active" type="checkbox" ${!e||Number(e.active)===1?`checked`:``}> Active</label>
      </div>
      <div class="modal-footer"><button class="btn btn-secondary" id="disc-cancel">Cancel</button><button class="btn btn-primary" id="disc-save">Save</button></div>
    </div>
  `,document.body.appendChild(n);let r=()=>n.remove();n.querySelector(`.modal-close`).onclick=r,n.querySelector(`#disc-cancel`).onclick=r,n.onclick=e=>{e.target===n&&r()},n.querySelector(`#disc-save`).onclick=async()=>{let i={name:n.querySelector(`#disc-name`).value.trim(),amount:Number(n.querySelector(`#disc-amount`).value)||0,description:n.querySelector(`#disc-desc`).value.trim()||null,active:+!!n.querySelector(`#disc-active`).checked};if(!i.name)return _(`Enter discount name`,`warning`);if(i.amount<=0)return _(`Enter discount amount`,`warning`);let a=e?await u.from(`discount_presets`).update(i).eq(`id`,e.id):await u.from(`discount_presets`).insert(i);if(a.error)return _(a.error.message,`error`);_(e?`Discount updated`:`Discount added`,`success`),r(),t()}}async function En(e){A(e);let[{data:t},{data:n}]=await Promise.all([u.from(`inquiries`).select(`*`).order(`bill_generated_at`,{ascending:!1}),u.from(`profiles`).select(`id,full_name,phone`)]),r=new Map((n||[]).map(e=>[e.id,e])),i=(t||[]).filter(e=>Number(e.discount_amount)>0);e.innerHTML=`
    <div class="page-header">
      <h1>Discount Details</h1>
      <p>All bills where employees applied admin or manual discounts</p>
    </div>
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-value">${i.length}</div><div class="stat-label">Discounted Bills</div></div>
      <div class="stat-card"><div class="stat-value" style="color:var(--success)">${Cn(i.reduce((e,t)=>e+Number(t.discount_amount||0),0))}</div><div class="stat-label">Total Discount</div></div>
      <div class="stat-card"><div class="stat-value">${i.filter(e=>e.discount_reason).length}</div><div class="stat-label">Manual Reasons</div></div>
    </div>
    <div class="card">
      <div class="table-wrap">
        <table>
          <thead><tr><th>Date</th><th>Ticket</th><th>Customer</th><th>Employee</th><th>Discount</th><th>Reason / Source</th></tr></thead>
          <tbody>
            ${i.length===0?`<tr><td colspan="6" style="text-align:center;padding:32px;color:var(--text-dim)">No discounts applied yet</td></tr>`:i.map(e=>`
              <tr>
                <td><small style="color:var(--text-dim)">${e.bill_generated_at?b(e.bill_generated_at):`-`}</small></td>
                <td><code style="font-size:0.75rem;color:var(--primary)">${Q(e.ticket_no||`-`)}</code></td>
                <td><b>${Q(e.full_name||`Client`)}</b><br/><small>${Q(e.service_item||``)}</small></td>
                <td>${Q(r.get(e.assigned_employee_id)?.full_name||`Employee`)}</td>
                <td><b style="color:var(--success)">${Cn(e.discount_amount)}</b><br/><small>${Q(e.discount_label||`Discount`)}</small></td>
                <td style="max-width:420px;white-space:normal;color:var(--text-soft)">${Q(e.discount_reason||(e.discount_preset_id?`Admin preset selected, no reason required`:`Automatic discount`))}</td>
              </tr>
            `).join(``)}
          </tbody>
        </table>
      </div>
    </div>
  `}function Dn(e){return String(e||``).replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e])}async function On(e){let{data:{user:t}}=await u.auth.getUser(),{data:n}=await u.from(`profiles`).select(`*`).eq(`id`,t.id).single(),r=n||{},i=r.role===`admin`||r.can_update_profile===1||r.can_update_profile===!0,a=i?``:`disabled aria-disabled="true"`;e.innerHTML=`
    <div class="page-header"><h1>My Profile</h1><p>Manage your account details</p></div>
    <div class="card" style="max-width:560px">
      <div class="card-header"><span class="card-title">Account Information</span></div>
      <div class="card-body">
        ${i?``:`
          <div class="access-lock-note">
            <span>${j.block}</span>
            <div>
              <b>Profile editing is locked</b>
              <small>Admin must enable Profile Edit access before you can update these details.</small>
            </div>
          </div>
        `}
        <div class="form-group"><label>Full Name</label><input type="text" id="p-name" value="${Dn(r.full_name)}" ${a}/></div>
        <div class="form-group"><label>Email</label><input type="email" value="${t.email}" disabled style="opacity:.6"/></div>
        <div class="form-group"><label>Phone</label><input type="tel" id="p-phone" value="${Dn(r.phone)}" ${a}/></div>
        <div class="form-group"><label>Company</label><input type="text" id="p-company" value="${Dn(r.company)}" ${a}/></div>
        <button class="btn btn-primary" style="width:auto" id="save-profile" ${i?``:`disabled`}>${j.check}<span>Save Changes</span></button>
      </div>
    </div>
    <div class="card" style="max-width:560px;margin-top:16px">
      <div class="card-header"><span class="card-title">Change Password</span></div>
      <div class="card-body">
        <div class="form-group">
          <label>New Password</label>
          <div class="password-field">
            <input type="password" id="new-pass" placeholder="Min 8 characters" autocomplete="new-password"/>
            <button type="button" class="password-toggle" data-target="new-pass" title="Show password" aria-label="Show password">${j.eye}</button>
          </div>
        </div>
        <button class="btn btn-secondary" style="width:auto" id="save-pass">Update Password</button>
      </div>
    </div>`;let o=(t,n)=>{let r=e.querySelector(t);r&&(r.onclick=n)};o(`#save-profile`,async()=>{if(!i){_(`Profile updates require admin access`,`error`);return}let{error:n}=await u.from(`profiles`).update({full_name:e.querySelector(`#p-name`).value.trim(),phone:e.querySelector(`#p-phone`).value.trim(),company:e.querySelector(`#p-company`).value.trim()}).eq(`id`,t.id);n?_(n.message,`error`):_(`Profile saved!`,`success`)}),e.querySelectorAll(`.password-toggle`).forEach(t=>{t.onclick=()=>{let n=e.querySelector(`#${t.dataset.target}`),r=n.type===`text`;n.type=r?`password`:`text`,t.innerHTML=r?j.eye:j.eyeOff,t.title=r?`Show password`:`Hide password`,t.setAttribute(`aria-label`,t.title)}}),o(`#save-pass`,async()=>{let t=e.querySelector(`#new-pass`).value;if(t.length<8){_(`Min 8 characters`,`error`);return}let{error:n}=await u.auth.updateUser({password:t});n?_(n.message,`error`):_(`Password updated!`,`success`)})}var kn=new URL(`/assets/logo-Cuxe_Kd5.png`,``+import.meta.url).href,An=window.location.hostname!==`localhost`&&window.location.hostname!==`127.0.0.1`?`/api`:`http://localhost:5000/api`,jn=`8899133144`,Mn=`+91 88991 33144`,Nn=`tel:+91${jn}`,Pn=`https://wa.me/91${jn}?text=Hello%20Networking%20Experts%2C%20I%20need%20help%20with%20a%20service%20request.`;async function Fn(e,t){try{let n=await fetch(`${An}${e}`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(t)}),r=await n.json().catch(()=>({}));return n.ok?{ok:!0,...r}:{ok:!1,error:r.error||`Request failed`}}catch(e){return{ok:!1,error:e.message||`Network request failed`}}}var In=e=>Fn(`/otp/send`,{phone:e}),Ln=(e,t)=>Fn(`/otp/verify`,{phone:e,otp:t}),Rn=e=>Fn(`/otp/resend`,{phone:e}),zn=`nest_landing_ads_v1`,Bn=600*1e3;function Vn(){let e=new Date;return`NE-${String(e.getFullYear()).slice(-2)}${String(e.getMonth()+1).padStart(2,`0`)}${String(e.getDate()).padStart(2,`0`)}-${String(Math.floor(1e3+Math.random()*9e3))}`}var Hn=[`open`,`assigned`,`in_progress`,`resolved`],Un={pending:`Received`,open:`Received`,assigned:`Assigned`,in_progress:`In Progress`,resolved:`Resolved`,closed:`Resolved`};function Wn(e){return e===`closed`?`resolved`:e||`open`}var Gn=[{value:`internet-down`,label:`Internet down`},{value:`slow-connection`,label:`Slow connection`},{value:`wifi-issue`,label:`Wi-Fi issue`},{value:`cctv-not-working`,label:`CCTV not working`},{value:`camera-offline`,label:`Camera offline`},{value:`hardware-repair`,label:`Hardware repair`},{value:`software-issue`,label:`Software issue`},{value:`new-installation`,label:`New installation`},{value:`other`,label:`Other (specify below)`}],Kn={value:`other`,label:`Other (specify below)`};function qn(e){return String(e||``).toLowerCase().trim().replace(/[^a-z0-9]+/g,`-`).replace(/^-+|-+$/g,``)||`option`}async function Jn(){try{let{data:e,error:t}=await u.from(`service_pricing`).select(`category`);if(t||!Array.isArray(e)||e.length===0)return null;let n=new Map;for(let t of e){let e=(t?.category||``).trim();if(!e||e.toLowerCase()===`uncategorized`)continue;let r=qn(e);n.has(r)||n.set(r,{value:r,label:e})}return n.size===0?null:[...n.values(),Kn]}catch{return null}}function Yn(){try{let e=JSON.parse(localStorage.getItem(zn)||`null`);return!e||!Array.isArray(e.ads)||!e.ads.length||Date.now()-Number(e.savedAt||0)>Bn?[]:e.ads}catch{return[]}}function Xn(e){try{localStorage.setItem(zn,JSON.stringify({savedAt:Date.now(),ads:e}))}catch{}}function Zn(e){if(!e?.url)return Promise.resolve();let t=(e.kind||`image`).toLowerCase()===`video`;return new Promise(n=>{let r=()=>{clearTimeout(i),n()},i=setTimeout(n,8e3);if(t){let t=document.createElement(`video`);t.muted=!0,t.preload=`metadata`,t.playsInline=!0,t.onloadeddata=r,t.onloadedmetadata=r,t.onerror=r,t.src=e.url,t.load();return}let a=new Image;a.onload=r,a.onerror=r,a.src=e.url,a.decode&&a.decode().then(r).catch(()=>{})})}async function Qn(e){await Promise.all((e||[]).map(Zn))}function $n({desiredAccuracy:e=25,maxWaitMs:t=12e3}={}){return new Promise((n,r)=>{if(!navigator.geolocation)return r(Error(`Geolocation not supported`));let i=null,a=!1,o=navigator.geolocation.watchPosition(t=>{(!i||t.coords.accuracy<i.coords.accuracy)&&(i=t),t.coords.accuracy<=e&&!a&&(a=!0,navigator.geolocation.clearWatch(o),clearTimeout(s),n(i))},e=>{a||(i?(a=!0,navigator.geolocation.clearWatch(o),clearTimeout(s),n(i)):(a=!0,r(e)))},{enableHighAccuracy:!0,timeout:t,maximumAge:0}),s=setTimeout(()=>{a||(a=!0,navigator.geolocation.clearWatch(o),i?n(i):r(Error(`Geolocation timed out`)))},t)})}async function er(e,t){return(await(await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${e}&lon=${t}&zoom=18&addressdetails=1`)).json()).display_name||``}function tr(e,t){return`https://www.google.com/maps?q=${encodeURIComponent(`${e},${t}`)}`}function nr(e,t){let n=new URLSearchParams(window.location.search),r=n.get(`tab`),i=n.get(`ticket`)||``,a=(n.get(`phone`)||``).replace(/^\+91/,``).replace(/\D/g,``),o=Yn(),s={mode:r===`track`?`track`:`new`,step:1,phone:``,otp:``,captcha:rr(),locationMode:`gps`,locationValue:``,coords:null,description:``,ticketNo:``,trackTicketNo:i,trackPhone:a,trackResult:null,trackList:null,trackLoading:!1,complaintTicketNo:``,complaintPhone:``,complaintText:``,complaintLoading:!1,complaintSubmitted:!1,ads:o,adsLoading:o.length===0,adIndex:0,_adTimer:null,issueOptions:Gn,issueValue:``};function c(){let t=(localStorage.getItem(`theme`)||`light`)===`dark`?j.sun:j.moon;e.innerHTML=`
      <style>
        @media (max-width: 640px) { .srf-nav-title { display: none !important; } }
        @keyframes srfAdZoom {
          0% { transform: scale(1); }
          100% { transform: scale(1.08); }
        }
        @keyframes srfFadeUp {
          0% { opacity: 0; transform: translateY(15px); }
          100% { opacity: 1; transform: translateY(0); }
        }
      </style>
      <div class="srf-page">
        ${s.adsLoading?`
          <div class="srf-loading-screen" role="status" aria-live="polite">
            <div class="srf-loading-card">
              <img src="${kn}" alt="Networking Experts" class="srf-loading-logo"
                   onerror="this.style.display='none'"/>
              <span class="srf-loading-spinner"></span>
              <div class="srf-loading-title">Loading service portal</div>
            </div>
          </div>
        `:``}
        <div class="srf-bg-orb srf-orb-1"></div>
        <div class="srf-bg-orb srf-orb-2"></div>
        <div class="srf-bg-orb srf-orb-3"></div>

        <nav class="srf-nav">
          <img src="${kn}" alt="Networking Experts" class="srf-logo"
               onerror="this.outerHTML='<span class=\\'srf-brand\\'>Networking Experts</span>'"/>
          <div class="srf-nav-actions">
            <button class="srf-icon-btn theme-toggle-btn" title="Toggle theme">${t}</button>
            <button class="srf-icon-btn srf-staff-btn" title="Staff Login">${j.staff}</button>
          </div>
        </nav>

        <section class="srf-top-banner" style="max-width:1000px; margin:0 auto; padding: 24px 20px 0; text-align:center;">
          <div class="srf-badge" style="margin: 0 auto 16px;">${j.shield}<span>Verified Service Request</span></div>
          <h1 class="srf-title" style="text-align:center; margin-bottom:18px;">Need help?<br/><span class="srf-grad">We'll be there in minutes.</span></h1>
          <p class="srf-sub" style="margin: 0 auto 32px; text-align:center; max-width:600px;">Raise a service request in three quick steps. We'll send a one-time code by SMS, take your details, and dispatch the right technician.</p>
          <div class="srf-contact-card" aria-label="Contact Networking Experts">
            <div class="srf-contact-copy">
              <span class="srf-contact-kicker">Need urgent support?</span>
              <a class="srf-contact-number" href="${Nn}">${Mn}</a>
            </div>
            <div class="srf-contact-actions">
              <a class="srf-contact-action srf-contact-call" href="${Nn}" aria-label="Call Networking Experts at ${Mn}">
                <span class="srf-contact-icon">${j.phone}</span>
                <span>Call</span>
              </a>
              <a class="srf-contact-action srf-contact-whatsapp" href="${Pn}" target="_blank" rel="noopener" aria-label="Message Networking Experts on WhatsApp">
                <span class="srf-contact-icon">${j.whatsapp}</span>
                <span>WhatsApp</span>
              </a>
            </div>
          </div>
          
        
        </section>

        <main class="srf-main">
          <section class="srf-intro">
            ${s.ads.length>0?`
              <div class="srf-ads" id="srf-ads">
                <div class="srf-ad-slot" id="srf-ad-slot"></div>
                ${s.ads.length>1?`
                  <div class="srf-ad-dots" id="srf-ad-dots">
                    ${s.ads.map((e,t)=>`<button type="button" class="srf-ad-dot" data-idx="${t}" aria-label="Slide ${t+1}"></button>`).join(``)}
                  </div>
                `:``}
              </div>
            `:`
               <div class="srf-ad-empty">
                  <h2 style="font-size:1.5rem; font-weight:800; color:var(--text); margin-bottom:12px;">Welcome to Networking Experts</h2>
                  <p style="color:var(--text-soft); font-size:1rem;">Your trusted partner for all networking needs.</p>
               </div>
            `}
          </section>

          <section class="srf-card-wrap">
            <div class="srf-mode-tabs" role="tablist">
              <button class="srf-mode-tab ${s.mode===`new`?`active`:``}" data-mode="new" role="tab">
                ${j.wrench}<span>New Request</span>
              </button>
              <button class="srf-mode-tab ${s.mode===`track`?`active`:``}" data-mode="track" role="tab">
                ${j.search}<span>Track Request</span>
              </button>
              <button class="srf-mode-tab ${s.mode===`complaint`?`active`:``}" data-mode="complaint" role="tab">
                ${j.shield}<span>Complaint</span>
              </button>
            </div>

            <div id="srf-stepper-wrap">${f()}</div>

            <div class="srf-card" id="srf-card">
              ${m()}
            </div>
          </section>
        </main>
      </div>
    `,T(),D(),l()}function l(){if(s._adTimer&&=(clearTimeout(s._adTimer),null),!s.ads.length)return;let t=e.querySelector(`#srf-ad-slot`);if(!t)return;let n=[...e.querySelectorAll(`.srf-ad-dot`)];s.adIndex=Math.min(Math.max(Number(s.adIndex)||0,0),s.ads.length-1);let r=()=>{let e=s.ads[s.adIndex],r=(e.kind||`image`).toLowerCase()===`video`;if(t.innerHTML=`${r?`<video class="srf-ad-media" src="${ar(e.url)}" autoplay muted playsinline preload="auto"></video>`:`<img class="srf-ad-media" src="${ar(e.url)}" alt="${ar(e.caption||`Advertisement`)}" loading="eager"/>`}${e.caption?`<div class="srf-ad-caption">
             <span>${$(e.caption)}</span>
           </div>`:``}`,r){let e=t.querySelector(`video`);if(e){let t=()=>{try{e.currentTime=0;let t=e.play();t?.catch&&t.catch(()=>{})}catch{}};e.addEventListener(`ended`,t),e.addEventListener(`error`,t,{once:!0}),e.play().catch?.(()=>{})}}n.forEach((e,t)=>e.classList.toggle(`active`,t===s.adIndex))},i=()=>{if(s._adTimer&&clearTimeout(s._adTimer),s.ads.length<=1||(s.ads[s.adIndex]?.kind||`image`).toLowerCase()===`video`)return;let e=Math.max(1500,Number(s.ads[s.adIndex].duration_ms)||6e3);s._adTimer=setTimeout(()=>{s.adIndex=(s.adIndex+1)%s.ads.length,r(),i()},e)};n.forEach((e,t)=>{e.onclick=()=>{s.adIndex=t,r(),i()}}),r(),i()}async function d(){try{let{data:e}=await u.from(`ads`).select(`*`).eq(`active`,1).order(`position`,{ascending:!0}),t=new Date().getTime(),n=(e||[]).filter(e=>!(!e.url||e.kind!==`image`&&e.kind!==`video`||e.starts_at&&new Date(e.starts_at).getTime()>t||e.expires_at&&new Date(e.expires_at).getTime()<=t));n.length&&(await Qn(n),Xn(n),s.ads=n)}catch(e){console.warn(`Could not load ads:`,e)}finally{s.adsLoading=!1,c()}}function f(){return s.mode===`new`?`
      <div class="srf-stepper">
        ${[1,2,3].map(e=>`
          <div class="srf-step ${s.step===e?`active`:``} ${s.step>e?`done`:``}">
            <div class="srf-step-dot">${s.step>e?j.check:e}</div>
            <span>${[`Verify`,`OTP`,`Details`][e-1]}</span>
          </div>
          ${e<3?`<div class="srf-step-line ${s.step>e?`done`:``}"></div>`:``}
        `).join(``)}
      </div>
    `:``}function p(){e.querySelectorAll(`.srf-mode-tab`).forEach(e=>{e.classList.toggle(`active`,e.dataset.mode===s.mode)});let t=e.querySelector(`#srf-stepper-wrap`);t&&(t.innerHTML=f());let n=e.querySelector(`#srf-card`);n&&(n.innerHTML=m()),D()}function m(){return s.mode===`track`?x():s.mode===`complaint`?b():s.step===1?h():s.step===2?g():s.step===3?v():y()}function h(){return`
      <h2 class="srf-card-title">Enter your mobile number</h2>
      <p class="srf-card-sub">We'll send a one-time code to verify it's you.</p>

      <label class="srf-label" for="srf-phone">Phone number</label>
      <div class="srf-input-wrap">
        <span class="srf-input-icon">${j.phone}</span>
        <span class="srf-cc">+91</span>
        <input id="srf-phone" type="tel" inputmode="numeric" maxlength="10"
               placeholder="98765 43210" class="srf-input srf-input-cc" value="${s.phone}" />
      </div>

      <label class="srf-label" for="srf-captcha">Quick check: type these letters</label>
      <div style="display:inline-flex;gap:6px;align-items:center;margin:2px 0 8px;padding:8px 12px;border-radius:10px;background:var(--bg-soft);border:1px solid var(--border);font-size:1.05rem;font-weight:900;letter-spacing:0.22em;color:var(--primary);user-select:none;">
        ${s.captcha.code.split(``).map(e=>`<span>${e}</span>`).join(``)}
      </div>
      <div class="srf-input-wrap">
        <span class="srf-input-icon">${j.shield}</span>
        <input id="srf-captcha" type="text" inputmode="text" autocomplete="off" autocapitalize="none" spellcheck="false"
               placeholder="Enter the letters" class="srf-input" />
        <button type="button" class="srf-input-action" id="srf-refresh-captcha" title="New question">${j.refresh}</button>
      </div>

      <button class="srf-btn srf-btn-primary" id="srf-send-otp">
        <span>Send OTP by SMS</span> ${j.arrowRight}
      </button>

      <p class="srf-fineprint">${j.shield}<span>Your number is only used to verify and contact you about this request.</span></p>
    `}function g(){return`
      <button class="srf-back" id="srf-back">${j.arrowLeft}<span>Back</span></button>
      <h2 class="srf-card-title">Enter the 6-digit code</h2>
      <p class="srf-card-sub">Sent by SMS to <strong>+91 ${ir(s.phone)}</strong></p>

      <div class="srf-otp-row">
        ${Array.from({length:6}).map((e,t)=>`
          <input class="srf-otp-box" maxlength="1" inputmode="numeric" data-idx="${t}" />
        `).join(``)}
      </div>

      <button class="srf-btn srf-btn-primary" id="srf-verify-otp">
        <span>Verify & continue</span> ${j.arrowRight}
      </button>

      <button class="srf-btn-link" id="srf-resend">Resend code</button>
    `}function v(){return`
      <h2 class="srf-card-title">Tell us what's wrong</h2>
      <p class="srf-card-sub">A few quick details so we can help fast.</p>

      <label class="srf-label" for="srf-name">Your name</label>
      <div class="srf-input-wrap">
        <span class="srf-input-icon">${j.user}</span>
        <input id="srf-name" type="text" placeholder="Full name" class="srf-input" />
      </div>

      <label class="srf-label">Location</label>
      <div class="srf-segmented">
        <button type="button" data-mode="gps" class="srf-seg ${s.locationMode===`gps`?`active`:``}">
          ${j.crosshair}<span>Current</span>
        </button>
        <button type="button" data-mode="manual" class="srf-seg ${s.locationMode===`manual`?`active`:``}">
          ${j.edit}<span>Manual</span>
        </button>
      </div>

      <div class="srf-input-wrap">
        <span class="srf-input-icon">${j.pin}</span>
        <input id="srf-location" type="text"
               placeholder="${s.locationMode===`gps`?`Tap "Detect" to auto-fill…`:`Type your address…`}"
               class="srf-input" value="${s.locationValue}" ${s.locationMode===`gps`?`readonly`:``}/>
        ${s.locationMode===`gps`?`<button type="button" class="srf-input-action" id="srf-detect">${j.crosshair}</button>`:``}
      </div>

      ${s.coords?`
        <a href="${ar(tr(s.coords.lat,s.coords.lng))}" target="_blank" rel="noopener"
           style="display:inline-flex;align-items:center;gap:6px;margin:6px 0 12px;color:var(--primary);font-size:0.78rem;font-weight:700;text-decoration:none;">
          ${j.pin}<span>Open exact pin (${Math.round(Number(s.coords.accuracy)||0)}m accuracy)</span>
        </a>
      `:``}

      <label class="srf-label" for="srf-time">Preferred Visit Time</label>
      <div class="srf-input-wrap">
        <span class="srf-input-icon">${j.clock}</span>
        <select id="srf-time" class="srf-input srf-select">
          <option value="Morning (10 AM - 1 PM)">Morning (10 AM - 1 PM)</option>
          <option value="Afternoon (1 PM - 4 PM)">Afternoon (1 PM - 4 PM)</option>
          <option value="Evening (4 PM - 6 PM)">Evening (4 PM - 6 PM)</option>
          <option value="Tomorrow Morning">Tomorrow Morning</option>
          <option value="Flexible">I'm Flexible</option>
        </select>
      </div>

      <label class="srf-label" for="srf-bill">Device bill number <span class="srf-optional">(optional)</span></label>
      <div class="srf-input-wrap">
        <span class="srf-input-icon">${j.receipt}</span>
        <input id="srf-bill" type="text" placeholder="e.g. INV-2024-001" class="srf-input" />
      </div>

      <label class="srf-label" for="srf-issue">What's the issue?</label>
      <div class="srf-input-wrap">
        <span class="srf-input-icon">${j.wrench}</span>
        <select id="srf-issue" class="srf-input srf-select">
          <option value="">Select an issue…</option>
          ${s.issueOptions.map(e=>`
            <option value="${ar(e.value)}" ${s.issueValue===e.value?`selected`:``}>
              ${$(e.label)}
            </option>
          `).join(``)}
        </select>
      </div>

      <div class="srf-input-wrap srf-other-wrap" id="srf-other-wrap" style="display:none;">
        <span class="srf-input-icon">${j.edit}</span>
        <input id="srf-other" type="text" placeholder="Describe your issue briefly" class="srf-input" />
      </div>

      <label class="srf-label" for="srf-desc">Describe the problem <span class="srf-optional">(optional)</span></label>
      <div class="srf-input-wrap" style="align-items:flex-start;">
        <span class="srf-input-icon" style="margin-top:12px;">${j.edit}</span>
        <textarea id="srf-desc" rows="3" maxlength="1000"
                  placeholder="Anything our technician should know — model, when it started, what you tried, etc."
                  class="srf-input"
                  style="padding-top:12px;padding-bottom:12px;resize:vertical;min-height:84px;">${s.description?String(s.description).replace(/[<>]/g,``):``}</textarea>
      </div>

      <button class="srf-btn srf-btn-primary" id="srf-submit">
        <span>Submit request</span> ${j.arrowRight}
      </button>
    `}function y(){return`
      <div class="srf-success">
        <div class="srf-success-ring">${j.check}</div>
        <h2 class="srf-card-title">Request received!</h2>
        <p class="srf-card-sub">Save your ticket number — you can track progress anytime from the <strong>Track Request</strong> tab.</p>

        <div class="srf-ticket-pill">
          ${j.ticket}
          <span class="srf-ticket-no" id="srf-ticket-no">${s.ticketNo}</span>
          <button type="button" class="srf-input-action" id="srf-copy-ticket" title="Copy">${j.clipboard}</button>
        </div>

        <p class="srf-fineprint" style="justify-content:center;text-align:center;">
          ${j.phone}<span>Your request has been saved with this mobile number.</span>
        </p>

        <button class="srf-btn srf-btn-primary" id="srf-track-now">
          <span>Track this request</span> ${j.arrowRight}
        </button>
        <button class="srf-btn-link" id="srf-new">Submit another request</button>
      </div>
    `}function b(){return s.complaintSubmitted?`
        <div class="srf-success">
          <div class="srf-success-ring">${j.check}</div>
          <h2 class="srf-card-title">Complaint received</h2>
          <p class="srf-card-sub">Our team has been notified and will follow up on ticket <strong>${s.complaintTicketNo}</strong> soon.</p>
          <button class="srf-btn srf-btn-primary" id="srf-complaint-another">
            <span>File another complaint</span> ${j.arrowRight}
          </button>
          <button class="srf-btn-link" id="srf-complaint-to-track">Track this ticket instead</button>
        </div>
      `:`
      <h2 class="srf-card-title">File a complaint</h2>
      <p class="srf-card-sub">Tell us what went wrong with a previous service. We verify the ticket against your mobile number before forwarding it to the team.</p>

      <label class="srf-label" for="srf-cmp-tno">Ticket number</label>
      <div class="srf-input-wrap">
        <span class="srf-input-icon">${j.ticket}</span>
        <input id="srf-cmp-tno" type="text" placeholder="NE-260506-1234" class="srf-input"
               value="${s.complaintTicketNo}" autocomplete="off"/>
      </div>

      <label class="srf-label" for="srf-cmp-phone">Phone number</label>
      <div class="srf-input-wrap">
        <span class="srf-input-icon">${j.phone}</span>
        <span class="srf-cc">+91</span>
        <input id="srf-cmp-phone" type="tel" inputmode="numeric" maxlength="10"
               placeholder="98765 43210" class="srf-input srf-input-cc" value="${s.complaintPhone}"/>
      </div>

      <label class="srf-label" for="srf-cmp-text">What's the issue?</label>
      <div class="srf-input-wrap">
        <span class="srf-input-icon">${j.edit}</span>
        <textarea id="srf-cmp-text" placeholder="Describe what went wrong — the issue came back, the technician didn't show, billing was wrong, etc." class="srf-input" rows="4" maxlength="2000" style="padding-top:12px;padding-bottom:12px;resize:vertical;min-height:100px;">${$(s.complaintText)}</textarea>
      </div>

      <button class="srf-btn srf-btn-primary" id="srf-cmp-submit" ${s.complaintLoading?`disabled`:``}>
        ${s.complaintLoading?`<span class="srf-spin"></span>`:``}<span>Submit complaint</span> ${j.arrowRight}
      </button>
    `}function x(){return s.trackResult?C(s.trackResult):s.trackList?S(s.trackList):`
      <h2 class="srf-card-title">Track your requests</h2>
      <p class="srf-card-sub">Enter your mobile number to see all the tickets you've filed. Add a ticket number to jump to one directly.</p>

      <label class="srf-label" for="srf-track-phone">Phone number</label>
      <div class="srf-input-wrap">
        <span class="srf-input-icon">${j.phone}</span>
        <span class="srf-cc">+91</span>
        <input id="srf-track-phone" type="tel" inputmode="numeric" maxlength="10"
               placeholder="98765 43210" class="srf-input srf-input-cc" value="${s.trackPhone}"/>
      </div>

      <label class="srf-label" for="srf-track-tno">Ticket number <span class="srf-optional">(optional)</span></label>
      <div class="srf-input-wrap">
        <span class="srf-input-icon">${j.ticket}</span>
        <input id="srf-track-tno" type="text" placeholder="NE-260506-1234" class="srf-input"
               value="${s.trackTicketNo}" autocomplete="off"/>
      </div>

      <button class="srf-btn srf-btn-primary" id="srf-track-go" ${s.trackLoading?`disabled`:``}>
        ${s.trackLoading?`<span class="srf-spin"></span>`:``}<span>${s.trackTicketNo?`Get this ticket`:`Show my tickets`}</span> ${j.arrowRight}
      </button>
    `}function S(e){return`
      <button class="srf-back" id="srf-track-back">${j.arrowLeft}<span>New search</span></button>
      <h2 class="srf-card-title">Your tickets</h2>
      <p class="srf-card-sub">${e.length} ticket${e.length===1?``:`s`} found for +91 ${ir(s.trackPhone)}</p>

      <div style="display:flex;flex-direction:column;gap:10px;margin-top:14px;">
        ${e.length===0?`
          <div style="padding:24px;text-align:center;color:var(--text-soft);background:var(--bg-soft);border-radius:14px;">
            No tickets found for this phone number.
          </div>
        `:e.map(e=>{let t=Wn(e.status),n=Un[t===`pending`?`open`:t]||t,r=t===`resolved`?`var(--success)`:t===`in_progress`?`var(--warning)`:t===`assigned`?`var(--primary)`:`var(--text-dim)`;return`
            <button type="button" class="srf-ticket-row" data-ticket-id="${e.id}"
              style="display:flex;align-items:center;gap:14px;padding:14px;border-radius:14px;background:var(--bg-soft);border:1px solid var(--border);cursor:pointer;text-align:left;font-family:inherit;width:100%;">
              <div style="flex-shrink:0;width:44px;height:44px;border-radius:12px;background:var(--bg);color:${r};display:flex;align-items:center;justify-content:center;">${j.ticket}</div>
              <div style="flex:1;min-width:0;">
                <div style="font-weight:800;font-size:0.95rem;color:var(--text);">${$(e.ticket_no||e.id.slice(0,8))}</div>
                <div style="font-size:0.82rem;color:var(--text-soft);margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${$(e.service_item||`—`)}</div>
                <div style="font-size:0.74rem;color:var(--text-dim);margin-top:2px;">${e.created_at?new Date(e.created_at).toLocaleDateString(`en-US`,{month:`short`,day:`numeric`,year:`numeric`}):``}</div>
              </div>
              <span style="font-size:0.75rem;font-weight:700;padding:6px 12px;border-radius:999px;background:${r}1a;color:${r};white-space:nowrap;">${n}</span>
            </button>
          `}).join(``)}
      </div>
    `}function C(e){let t=Wn(e.status),n=t===`pending`?`open`:t,r=Math.max(0,Hn.indexOf(n)),i=t===`resolved`,a=e.bill_amount!=null&&Number(e.bill_amount)>0,o=e.payment_status===`paid`,s=e.feedback_rating!=null,c=e.profiles||null;return`
      <button class="srf-back" id="srf-track-back">${j.arrowLeft}<span>Look up another</span></button>
      <h2 class="srf-card-title">Ticket ${e.ticket_no||e.id.slice(0,8)}</h2>
      <p class="srf-card-sub">${e.full_name} · ${e.service_item}</p>

      ${i?``:`
        <div style="background:var(--bg-soft); padding:18px 20px; border-radius:16px; margin:20px 0; border:1px solid var(--border); display:flex; align-items:center; gap:16px;">
          <div style="width:48px;height:48px;border-radius:14px;background:var(--gradient);color:#fff;display:flex;align-items:center;justify-content:center;flex-shrink:0;box-shadow:0 6px 16px rgba(16,185,129,0.25);">${j.clock}</div>
          <div style="flex:1;min-width:0;">
            <div style="font-size:0.72rem; color:var(--text-dim); text-transform:uppercase; font-weight:800; letter-spacing:0.5px;">Service commitment</div>
            <div style="font-size:0.85rem; color:var(--text-soft); margin-top:2px;">Resolved by</div>
            <div style="font-size:1.2rem; color:var(--text); font-weight:800; margin-top:4px; letter-spacing:-0.01em;">${or(E(e.created_at))}</div>
          </div>
        </div>
      `}

      <div class="srf-timeline">
        ${Hn.map((e,t)=>`
          <div class="srf-tl-step ${t<=r?`done`:``} ${t===r?`current`:``}">
            <div class="srf-tl-dot">${t<=r?j.check:t+1}</div>
            <div class="srf-tl-label">${Un[e]}</div>
          </div>
          ${t<Hn.length-1?`<div class="srf-tl-line ${t<r?`done`:``}"></div>`:``}
        `).join(``)}
      </div>

      ${sr(n,e,c)}

      ${a?`
        <div class="srf-bill-card">
          <div class="srf-bill-row">
            <div class="srf-bill-icon">${j.rupee}</div>
            <div class="srf-bill-info">
              <div class="srf-bill-label">${o?`Amount paid`:`Amount due`}</div>
              <div class="srf-bill-amount">₹${Number(e.bill_amount).toLocaleString(`en-IN`)}</div>
            </div>
            ${o?`<span class="srf-bill-paid">${j.check}<span>Paid</span></span>`:e.payment_link?`<a class="srf-btn srf-btn-primary srf-pay-btn" href="${ar(e.payment_link)}" target="_blank" rel="noopener">${j.card}<span>Pay now</span></a>`:`<span class="srf-bill-pending">${j.hourglass}<span>Link pending</span></span>`}
          </div>
        </div>
      `:``}

      ${i&&!s?`
        <div class="srf-feedback">
          <h3 class="srf-fb-title">How did we do?</h3>
          <p class="srf-fb-sub">Your honest feedback helps us serve you better.</p>

          <div style="margin-bottom:18px;">
            <div style="font-size:0.75rem;font-weight:700;color:var(--text-dim);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:8px;">Overall Experience</div>
            <div class="srf-stars" id="srf-stars" data-rating="0">
              ${[1,2,3,4,5].map(e=>`<button type="button" class="srf-star" data-val="${e}">${j.starOutline}</button>`).join(``)}
            </div>
            <div id="srf-rating-label" style="font-size:0.82rem;color:var(--primary);font-weight:700;margin-top:6px;min-height:18px;"></div>
          </div>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:18px;">
            <div>
              <div style="font-size:0.75rem;font-weight:700;color:var(--text-dim);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:6px;">Service Quality</div>
              <div class="srf-stars" id="srf-stars-quality" data-rating="0" style="gap:2px;">
                ${[1,2,3,4,5].map(e=>`<button type="button" class="srf-star" data-val="${e}" style="padding:2px;">${j.starOutline}</button>`).join(``)}
              </div>
            </div>
            <div>
              <div style="font-size:0.75rem;font-weight:700;color:var(--text-dim);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:6px;">Technician</div>
              <div class="srf-stars" id="srf-stars-tech" data-rating="0" style="gap:2px;">
                ${[1,2,3,4,5].map(e=>`<button type="button" class="srf-star" data-val="${e}" style="padding:2px;">${j.starOutline}</button>`).join(``)}
              </div>
            </div>
          </div>

          <div style="display:flex;gap:8px;margin-bottom:18px;" id="srf-rec-wrap">
            <button class="srf-rec-btn" id="srf-rec-yes" data-val="yes" style="flex:1;padding:10px 8px;border-radius:12px;border:2px solid var(--border);background:var(--bg-soft);font-weight:700;font-size:0.82rem;cursor:pointer;color:var(--text-soft);font-family:inherit;transition:all 0.2s;">👍 Recommend</button>
            <button class="srf-rec-btn" id="srf-rec-no" data-val="no" style="flex:1;padding:10px 8px;border-radius:12px;border:2px solid var(--border);background:var(--bg-soft);font-weight:700;font-size:0.82rem;cursor:pointer;color:var(--text-soft);font-family:inherit;transition:all 0.2s;">👎 Would Not</button>
          </div>

          <div class="srf-input-wrap" style="margin-bottom:14px;">
            <span class="srf-input-icon">${j.edit}</span>
            <textarea id="srf-fb-comment" placeholder="Tell us about your experience — what went well, what could improve…" class="srf-input" rows="3" style="padding-top:12px;padding-bottom:12px;resize:vertical;min-height:72px;"></textarea>
          </div>

          <button class="srf-btn srf-btn-primary" id="srf-fb-submit" disabled style="opacity:0.5;cursor:not-allowed;">
            <span>Submit Feedback</span> ${j.arrowRight}
          </button>
          <p style="text-align:center;font-size:0.75rem;color:var(--text-dim);margin-top:8px;">Overall star rating is required</p>
        </div>
      `:``}

      ${i&&s?`
        <div class="srf-fb-done">
          <div class="srf-fb-done-ring">${j.star}</div>
          <h3 style="font-weight:800;font-size:1.1rem;color:var(--text);margin:0 0 6px;">Thank you for your feedback!</h3>
          <p style="font-size:0.9rem;color:var(--text-soft);margin:0 0 8px;">You rated us <strong style="color:var(--warning)">${e.feedback_rating}/5 ★</strong></p>
          ${e.feedback_comment?`<p style="font-size:0.85rem;color:var(--text-soft);font-style:italic;margin:0;">"${e.feedback_comment}"</p>`:``}
        </div>
      `:``}
    `}let w=(t,n,r=`onclick`)=>{let i=e.querySelector(t);i&&(i[r]=n)};function T(){w(`.theme-toggle-btn`,()=>{ee(),c()}),w(`.srf-staff-btn`,t),e.querySelectorAll(`.srf-mode-tab`).forEach(e=>{e.onclick=()=>{s.mode!==e.dataset.mode&&(s.mode=e.dataset.mode,s.mode===`track`&&(s.trackResult=null,s.trackList=null),s.mode===`complaint`&&(s.complaintSubmitted=!1),p())}})}function D(){if(s.mode===`track`)return ae();if(s.mode===`complaint`)return k();s.step===1?O():s.step===2?te():s.step===3?ne():ie()}function O(){let t=e.querySelector(`#srf-phone`),n=e.querySelector(`#srf-captcha`),r=e.querySelector(`#srf-send-otp`);t.addEventListener(`input`,e=>{let t=e.target.value.replace(/\D/g,``);t.length>10&&t.startsWith(`91`)?t=t.slice(2):t.length===11&&t.startsWith(`0`)&&(t=t.slice(1)),e.target.value=t.slice(0,10),s.phone=e.target.value}),w(`#srf-refresh-captcha`,()=>{s.captcha=rr(),c()}),r&&(r.onclick=async()=>{if(!/^\d{10}$/.test(s.phone))return _(`Enter a valid 10-digit number`,`error`);if(String(n.value||``).trim().toLowerCase()!==s.captcha.code.toLowerCase())return _(`Captcha is incorrect`,`error`),s.captcha=rr(),c();r.disabled=!0,r.innerHTML=`<span class="srf-spin"></span><span>Sending…</span>`;let e=await In(`+91`+s.phone);if(!e.ok){_(e.error||`Could not send OTP`,`error`),c();return}_(`OTP sent by SMS`,`success`),s.step=2,c()})}function te(){let t=[...e.querySelectorAll(`.srf-otp-box`)];t[0]?.focus(),t.forEach((e,n)=>{e.addEventListener(`input`,()=>{e.value=e.value.replace(/\D/g,``),e.value&&n<t.length-1&&t[n+1].focus()}),e.addEventListener(`keydown`,r=>{r.key===`Backspace`&&!e.value&&n>0&&t[n-1].focus()}),e.addEventListener(`paste`,e=>{let n=(e.clipboardData.getData(`text`)||``).replace(/\D/g,``).slice(0,6);n&&(e.preventDefault(),t.forEach((e,t)=>e.value=n[t]||``),t[Math.min(n.length,5)].focus())})}),w(`#srf-back`,()=>{s.step=1,c()}),w(`#srf-verify-otp`,async()=>{let n=t.map(e=>e.value).join(``);if(n.length!==6)return _(`Enter the full 6-digit code`,`error`);let r=e.querySelector(`#srf-verify-otp`);r.disabled=!0,r.innerHTML=`<span class="srf-spin"></span><span>Verifying...</span>`;let i=await Ln(`+91`+s.phone,n);if(!i.ok){_(i.error||`Incorrect code`,`error`),c();return}s.step=3,c()}),w(`#srf-resend`,async()=>{let e=await Rn(`+91`+s.phone);if(!e.ok)return _(e.error||`Could not resend OTP`,`error`);_(`New code sent`,`success`),c()})}function ne(){let t=e.querySelector(`#srf-issue`),n=e.querySelector(`#srf-other-wrap`);n.style.display=t.value===`other`?``:`none`,t.onchange=()=>{s.issueValue=t.value,n.style.display=t.value===`other`?``:`none`},e.querySelectorAll(`.srf-seg`).forEach(e=>{e.onclick=()=>{s.locationMode=e.dataset.mode,s.locationValue=``,s.coords=null,c()}});let r=e.querySelector(`#srf-detect`);r&&(r.onclick=async()=>{r.innerHTML=`<span class="srf-spin"></span>`;try{let{latitude:t,longitude:n,accuracy:r}=(await $n()).coords;s.coords={lat:t,lng:n,accuracy:r};try{s.locationValue=await er(t,n)||`GPS: ${t.toFixed(6)}, ${n.toFixed(6)}`}catch(e){console.error(`Reverse geocoding failed:`,e),s.locationValue=`GPS: ${t.toFixed(6)}, ${n.toFixed(6)}`}e.querySelector(`#srf-location`).value=s.locationValue,_(`Location detected (${Math.round(Number(r)||0)}m accuracy)`,`success`),p()}catch{_(`Could not detect location - switch to Manual`,`error`),r.innerHTML=j.crosshair}}),e.querySelector(`#srf-location`).addEventListener(`input`,e=>{s.locationValue=e.target.value});let i=e.querySelector(`#srf-desc`);i&&i.addEventListener(`input`,e=>{s.description=e.target.value}),w(`#srf-submit`,async()=>{let n=e.querySelector(`#srf-name`).value.trim(),r=e.querySelector(`#srf-bill`).value.trim(),i=e.querySelector(`#srf-time`).value,a=t.value;s.issueValue=a;let o=s.issueOptions.find(e=>e.value===a)?.label||``,l=e.querySelector(`#srf-other`)?.value.trim()||``;if(!n)return _(`Please enter your name`,`error`);if(!s.locationValue)return _(`Please add your location`,`error`);if(!a)return _(`Please pick an issue`,`error`);if(a===`other`&&!l)return _(`Please describe the issue`,`error`);let d=a===`other`?`Other: ${l}`:o,f=(s.description||``).trim().slice(0,1e3)||null,p=e.querySelector(`#srf-submit`);p.disabled=!0,p.innerHTML=`<span class="srf-spin"></span><span>Submitting…</span>`;let m=Vn(),{error:h}=await u.from(`inquiries`).insert({full_name:n,phone:`+91`+s.phone,location:s.locationValue,customer_lat:s.coords?.lat??null,customer_lng:s.coords?.lng??null,bill_no:r||null,service_item:d,description:f,status:`open`,assignment_status:`none`,ticket_no:m,preferred_time:i});if(h){_(h.code===`42501`?`Submission blocked by database policy. Ask admin to run migrations.sql.`:`Could not submit — please try again`,`error`),console.error(h),c();return}s.ticketNo=m,_(`Request submitted`,`success`),s.step=4,c()})}async function re(){s.issueOptions=await Jn()||Gn,s.issueValue&&!s.issueOptions.some(e=>e.value===s.issueValue)&&(s.issueValue=``),c()}function ie(){w(`#srf-copy-ticket`,async()=>{try{await navigator.clipboard.writeText(s.ticketNo),_(`Ticket number copied`,`success`)}catch{_(`Copy failed — select and copy manually`,`error`)}}),w(`#srf-track-now`,()=>{s.mode=`track`,s.trackTicketNo=s.ticketNo,s.trackPhone=s.phone,s.trackResult=null,c()}),w(`#srf-new`,()=>{s.step=1,s.phone=``,s.otp=``,s.ticketNo=``,s.captcha=rr(),s.locationMode=`gps`,s.locationValue=``,s.coords=null,c()})}function ae(){if(s.trackResult){e.querySelector(`#srf-track-back`).onclick=()=>{s.trackResult=null,c()};let t=e.querySelector(`#srf-stars`);if(t){let n=(e,t)=>{if(!e)return;let n=[...e.querySelectorAll(`.srf-star`)],r=0,i=e=>n.forEach((t,n)=>{t.innerHTML=n<e?j.star:j.starOutline,t.classList.toggle(`on`,n<e)});return n.forEach((n,a)=>{n.onmouseenter=()=>i(a+1),n.onmouseleave=()=>i(r),n.onclick=()=>{r=a+1,e.dataset.rating=r,i(r),t&&t(r)}}),()=>r},r=[``,`😞 Poor`,`😐 Fair`,`😊 Good`,`😁 Great`,`🤩 Excellent!`],i=0,a=``,o=e.querySelector(`#srf-fb-submit`),l=()=>{o&&(o.disabled=!i,o.style.opacity=i?`1`:`0.5`,o.style.cursor=i?`pointer`:`not-allowed`)};n(t,t=>{i=t;let n=e.querySelector(`#srf-rating-label`);n&&(n.textContent=r[t]||``),l()}),n(e.querySelector(`#srf-stars-quality`)),n(e.querySelector(`#srf-stars-tech`)),e.querySelectorAll(`.srf-rec-btn`).forEach(t=>{t.onclick=()=>{a=t.dataset.val,e.querySelectorAll(`.srf-rec-btn`).forEach(e=>{e.style.borderColor=e.dataset.val===a?`var(--primary)`:`var(--border)`,e.style.color=e.dataset.val===a?`var(--primary)`:`var(--text-soft)`,e.style.background=e.dataset.val===a?`rgba(16,185,129,0.08)`:`var(--bg-soft)`})}}),w(`#srf-fb-submit`,async()=>{if(!i)return _(`Please pick an overall star rating`,`warning`);let t=Number(e.querySelector(`#srf-stars-quality`)?.dataset.rating||0),n=Number(e.querySelector(`#srf-stars-tech`)?.dataset.rating||0),r=[e.querySelector(`#srf-fb-comment`).value.trim(),t?`Service quality: ${t}/5`:``,n?`Technician: ${n}/5`:``,a?a===`yes`?`Would recommend ✓`:`Would not recommend`:``].filter(Boolean).join(` | `),o=e.querySelector(`#srf-fb-submit`);o.disabled=!0,o.innerHTML=`<span class="srf-spin"></span><span>Submitting…</span>`;let l={feedback_rating:i,feedback_comment:r||null,feedback_at:new Date().toISOString()};n&&(l.employee_rating=n,s.trackResult.assigned_employee_id&&(l.feedback_employee_id=s.trackResult.assigned_employee_id));let{error:d}=await u.from(`inquiries`).update(l).eq(`id`,s.trackResult.id).eq(`ticket_no`,s.trackResult.ticket_no).eq(`phone`,s.trackResult.phone);if(d){_(`Could not submit feedback`,`error`),o.disabled=!1,o.innerHTML=`<span>Submit Feedback</span> ${j.arrowRight}`;return}s.trackResult={...s.trackResult,...l},_(`Thanks for your feedback! 🙏`,`success`),c()})}return}if(s.trackList){w(`#srf-track-back`,()=>{s.trackList=null,c()}),e.querySelectorAll(`.srf-ticket-row`).forEach(e=>{e.onclick=async()=>{let t=e.dataset.ticketId,n=s.trackList.find(e=>e.id===t);if(!n)return;s.trackLoading=!0,c();let{data:r}=await u.from(`inquiries`).select(`*,profiles(id,full_name,phone,role)`).eq(`ticket_no`,n.ticket_no).eq(`phone`,n.phone).maybeSingle();s.trackLoading=!1,s.trackResult=r||n,c()}});return}let t=e.querySelector(`#srf-track-tno`),n=e.querySelector(`#srf-track-phone`);t.addEventListener(`input`,e=>{s.trackTicketNo=e.target.value.trim().toUpperCase(),e.target.value=s.trackTicketNo}),n.addEventListener(`input`,e=>{e.target.value=e.target.value.replace(/\D/g,``).slice(0,10),s.trackPhone=e.target.value}),w(`#srf-track-go`,async()=>{let e=s.trackTicketNo,t=s.trackPhone;if(!/^\d{10}$/.test(t))return _(`Enter a valid 10-digit phone number`,`error`);if(s.trackLoading=!0,c(),e){let{data:n,error:r}=await u.from(`inquiries`).select(`*,profiles(id,full_name,phone,role)`).eq(`ticket_no`,e).eq(`phone`,`+91`+t).maybeSingle();if(s.trackLoading=!1,r){console.error(r),_(`Lookup failed`,`error`),c();return}if(!n){_(`No matching ticket. Check the number and phone.`,`error`),c();return}s.trackResult=n,c();return}let{data:n,error:r}=await u.from(`inquiries`).select(`*`).eq(`phone`,`+91`+t).order(`created_at`,{ascending:!1});if(s.trackLoading=!1,r){console.error(r),_(`Lookup failed`,`error`),c();return}let i=Array.isArray(n)?n:n?[n]:[];if(!i.length){_(`No tickets found for that phone number.`,`error`),c();return}if(i.length===1){let{data:e}=await u.from(`inquiries`).select(`*,profiles(id,full_name,phone,role)`).eq(`ticket_no`,i[0].ticket_no).eq(`phone`,i[0].phone).maybeSingle();s.trackResult=e||i[0]}else s.trackList=i;c()})}function k(){if(s.complaintSubmitted){w(`#srf-complaint-another`,()=>{s.complaintSubmitted=!1,s.complaintTicketNo=``,s.complaintText=``,c()}),w(`#srf-complaint-to-track`,()=>{s.mode=`track`,s.trackTicketNo=s.complaintTicketNo,s.trackPhone=s.complaintPhone,s.trackResult=null,s.trackList=null,c()});return}let t=e.querySelector(`#srf-cmp-tno`),n=e.querySelector(`#srf-cmp-phone`),r=e.querySelector(`#srf-cmp-text`);t.addEventListener(`input`,e=>{s.complaintTicketNo=e.target.value.trim().toUpperCase(),e.target.value=s.complaintTicketNo}),n.addEventListener(`input`,e=>{e.target.value=e.target.value.replace(/\D/g,``).slice(0,10),s.complaintPhone=e.target.value}),r.addEventListener(`input`,e=>{s.complaintText=e.target.value}),w(`#srf-cmp-submit`,async()=>{let e=s.complaintTicketNo,t=s.complaintPhone,n=s.complaintText.trim();if(!e)return _(`Enter your ticket number`,`error`);if(!/^\d{10}$/.test(t))return _(`Enter a valid 10-digit number`,`error`);if(n.length<10)return _(`Please describe the issue (at least 10 characters)`,`error`);s.complaintLoading=!0,c();let{error:r}=await u.from(`complaints`).insert({ticket_no:e,phone:`+91`+t,complaint_text:n});if(s.complaintLoading=!1,r){_(/No ticket found/i.test(r.message||``)?`No ticket matches that number and phone. Double-check and try again.`:`Could not submit complaint — please try again.`,`error`),c();return}s.complaintSubmitted=!0,_(`Complaint received`,`success`),c()})}c(),re(),d(),r===`track`&&i&&a&&a.length===10&&(async()=>{s.trackLoading=!0,c();let{data:e}=await u.from(`inquiries`).select(`*,profiles(id,full_name,phone,role)`).eq(`ticket_no`,i).eq(`phone`,`+91`+a).maybeSingle();s.trackLoading=!1,e&&(s.trackResult=e),c()})()}function rr(){return{code:Array.from({length:5},()=>`ABCDEFGHJKLMNPQRSTUVWXYZ`[Math.floor(Math.random()*24)]).join(``)}}function ir(e){return e.length===10?`${e.slice(0,5)} ${e.slice(5)}`:e}function ar(e){return String(e).replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e])}function $(e){return String(e??``).replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e])}function or(e){let t=e instanceof Date?e:new Date(e),n=t.toLocaleDateString(`en-US`,{weekday:`short`}),r=t.toLocaleDateString(`en-US`,{month:`short`}),i=t.getDate(),a=t.getFullYear();return`${t.toLocaleTimeString(`en-US`,{hour:`numeric`,minute:`2-digit`,hour12:!0})}, ${n} ${i} ${r} ${a}`}function sr(e,t,n){let r=`<div style="margin:18px 0;padding:18px;border-radius:18px;background:var(--bg-soft);box-shadow:var(--neu-in);border:1px solid var(--border);">`,i=`</div>`,a=(e,t)=>`
    <div style="font-size:0.72rem;color:var(--text-dim);text-transform:uppercase;font-weight:800;letter-spacing:0.5px;">${e}</div>
    ${t?`<div style="font-size:0.85rem;color:var(--text-soft);margin-top:2px;">${t}</div>`:``}
  `,o=(e,t,n)=>`
    <div style="display:flex;align-items:flex-start;gap:12px;padding:10px 0;border-top:1px solid var(--border);">
      <div style="width:32px;height:32px;border-radius:10px;background:var(--bg);color:var(--primary);display:flex;align-items:center;justify-content:center;flex-shrink:0;">${e}</div>
      <div style="flex:1;min-width:0;">
        <div style="font-size:0.7rem;color:var(--text-dim);text-transform:uppercase;font-weight:700;letter-spacing:0.4px;">${t}</div>
        <div style="font-size:0.92rem;color:var(--text);font-weight:600;word-break:break-word;">${n}</div>
      </div>
    </div>
  `;if(e===`open`)return`
      ${r}
        ${a(`Request received`,`We're reviewing your request and will dispatch the right technician shortly. You'll see their details here as soon as they're assigned.`)}
        <div style="margin-top:10px;">
          ${o(j.user,`Customer`,$(t.full_name))}
          ${o(j.phone,`Contact`,$(t.phone))}
          ${o(j.pin,`Location`,$(t.location||`—`))}
          ${o(j.wrench,`Service`,$(t.service_item||`—`))}
          ${t.description?o(j.edit,`Description`,$(t.description)):``}
          ${t.preferred_time?o(j.clock,`Preferred time`,$(t.preferred_time)):``}
        </div>
      ${i}
    `;if(e===`assigned`||e===`in_progress`){let t=e===`assigned`?`Technician assigned`:`Technician on the job`;return n?`
      ${r}
        ${a(t,e===`assigned`?`Your technician has been dispatched and will reach out shortly.`:`Your technician is actively working on your service.`)}
        <div style="margin-top:10px;">
          ${o(j.user,`Name`,$(n.full_name||`Technician`))}
          ${n.phone?o(j.phone,`Phone`,`<a href="tel:${ar(n.phone)}" style="color:var(--primary);text-decoration:none;">${$(n.phone)}</a>`):``}
          ${n.role?o(j.shield,`Role`,$(n.role.charAt(0).toUpperCase()+n.role.slice(1))):``}
        </div>
      ${i}
    `:`
        ${r}
          ${a(t,`Technician details will appear here once assignment is confirmed.`)}
        ${i}
      `}return``}var cr=`true`,lr=`false`,ur=cr===`true`,dr=lr===`true`;function fr(e={}){let{immediate:t=!1,onNeedReload:n,onNeedRefresh:r,onOfflineReady:i,onRegistered:a,onRegisteredSW:o,onRegisterError:s}=e,c,l,u,d=async(e=!0)=>{await l,ur||u?.()};async function f(){if(`serviceWorker`in navigator){if(c=await F(async()=>{let{Workbox:e}=await import(`./workbox-window.prod.es5-Cch4wiA5.js`);return{Workbox:e}},[]).then(({Workbox:e})=>new e(`/sw.js`,{scope:`/`,type:`classic`})).catch(e=>{s?.(e)}),!c)return;if(u=()=>{c?.messageSkipWaiting()},!dr)if(ur)c.addEventListener(`activated`,e=>{(e.isUpdate||e.isExternal)&&(n?n():window.location.reload())}),c.addEventListener(`installed`,e=>{e.isUpdate||i?.()});else{let e=!1,t=()=>{e=!0,c?.addEventListener(`controlling`,e=>{e.isUpdate&&(n?n():window.location.reload())}),r?.()};c.addEventListener(`installed`,n=>{n.isUpdate===void 0?n.isExternal===void 0?!e&&i?.():n.isExternal?t():!e&&i?.():n.isUpdate||i?.()}),c.addEventListener(`waiting`,t)}c.register({immediate:t}).then(e=>{o?o(`/sw.js`,e):a?.(e)}).catch(e=>{s?.(e)})}}return l=f(),d}fr({immediate:!0});var pr,mr=null;window.addEventListener(`beforeinstallprompt`,e=>{e.preventDefault(),pr=e});function hr(){!pr||mr||(mr=document.createElement(`button`),mr.className=`pwa-install-btn`,mr.innerHTML=`${j.download||`📥`} Install App`,document.body.appendChild(mr),mr.addEventListener(`click`,async()=>{if(!pr)return;pr.prompt();let{outcome:e}=await pr.userChoice;e===`accepted`&&(pr=null),gr()}))}function gr(){mr&&=(mr.remove(),null)}w();var _r=document.getElementById(`app`),vr=null,yr=null,br=!1,xr=`dashboard`;function Sr(e){let t=[{type:`section`,label:`Main`},{id:`dashboard`,icon:j.dashboard,label:`Dashboard`}];if(e===`employee`){let e=[...t,{id:`all-tickets`,icon:j.ticket,label:`My Tasks`},{type:`section`,label:`Work`},{id:`my-attendance`,icon:j.clock,label:`Attendance Records`},{id:`my-leaves`,icon:j.hourglass,label:`Leave Requests`},{id:`my-eod`,icon:j.clipboard,label:`EOD Reports`},{id:`my-cash`,icon:j.rupee,label:`My Cash`},{id:`my-collections`,icon:j.card,label:`Collections`},{id:`my-salary`,icon:j.rupee,label:`Salary`},{id:`leaderboard`,icon:j.star,label:`Leaderboard`}];return br&&(e.push({type:`section`,label:`Services`}),e.push({id:`service-pricing`,icon:j.receipt,label:`Service Pricing`})),e.push({type:`section`,label:`Account`},{id:`profile`,icon:j.user,label:`Profile`}),e}return[...t,{id:`all-tickets`,icon:j.ticket,label:`All Tickets`},{type:`section`,label:`Operations`},{id:`attendance`,icon:j.clock,label:`Attendance`},{id:`inquiries`,icon:j.inbox,label:`Service Requests`},{type:`section`,label:`Management`},{id:`contacts`,icon:j.phone,label:`Contacts`},{id:`users`,icon:j.users,label:`Users`},{type:`section`,label:`Reports`},{id:`payments`,icon:j.rupee,label:`Payments`},{id:`bills`,icon:j.receipt,label:`Bills`},{id:`cash`,icon:j.rupee,label:`Cash Collections`},{id:`collections`,icon:j.card,label:`Collection Reports`},{id:`salary`,icon:j.rupee,label:`Salary`},{id:`leaves`,icon:j.hourglass,label:`Leave Requests`},{id:`eod`,icon:j.clipboard,label:`EOD Summaries`},{id:`pricing`,icon:j.receipt,label:`Service Pricing`},{id:`device-types`,icon:j.box,label:`Device Types`},{id:`feedback`,icon:j.star,label:`Leaderboard`},{id:`complaints`,icon:j.shield,label:`Complaints`},{id:`ads`,icon:j.box,label:`Landing Ads`},{id:`notices`,icon:j.clipboard,label:`Notices`},{id:`discounts`,icon:j.receipt,label:`Add Discounts`},{id:`discount-details`,icon:j.receipt,label:`Discount Details`},{type:`section`,label:`Config`},{id:`settings`,icon:j.settings||`⚙️`,label:`Settings`},{type:`section`,label:`Account`},{id:`profile`,icon:j.user,label:`Profile`}]}function Cr(e,t){let n={employee:{dashboard:J,"all-tickets":Qe,"my-attendance":Ke,"my-leaves":qe,"my-eod":Je,"my-cash":Ye,"my-collections":xn,"my-salary":Xe,leaderboard:Ze,"service-pricing":tt,profile:On},admin:{dashboard:Ot,"all-tickets":Pt,attendance:At,inquiries:Mt,contacts:Lt,users:Rt,profile:On,payments:zt,bills:Bt,cash:Ut,salary:It,leaves:Ft,eod:Nt,pricing:$t,collections:Sn,discounts:wn,"discount-details":En,"device-types":Ht,feedback:en,complaints:tn,ads:rn,notices:dn,settings:on}};return(n[e]||n.admin)[t]}var wr=null;function Tr(){wr||=(ae(),s(null,e=>{k({title:e.title||`Update`,body:e.body||``,tag:e.subject||`app-notify`,type:e.subject===`payment_received`?`payment`:e.subject===`new_assignment`||e.subject===`new_service_request`||e.subject===`new_complaint`||e.subject===`employee_clock_in`||e.subject===`employee_clock_out`?`alert`:`info`})}))}function Er(e){gr(),xr=e;let t=Sr(yr),n=Cr(yr,e);de({user:vr,role:yr,activePage:xr,navItems:t,onNav:Er,pageContent:n||(()=>{})}),Tr()}function Dr(){nr(_r,kr),hr()}async function Or(e){try{let{data:t}=await u.from(`profiles`).select(`can_add_service`).eq(`id`,e).single();br=t?.can_add_service===1||t?.can_add_service===!0}catch{br=!1}}function kr(){le(async(e,t)=>{if(t!==`admin`&&t!==`employee`){await m(),_(`Client accounts cannot log in here. Please use the public service request form.`,`error`),Dr();return}vr=e,yr=t,t===`employee`&&await Or(e.id),Er(`dashboard`)},()=>Dr())}async function Ar(){_r.innerHTML=`<div class="loading-screen"><div class="spinner"></div></div>`;let{data:{session:e}}=await u.auth.getSession();if(e?.user){if(vr=e.user,yr=e.user.role||await d(vr.id),yr!==`admin`&&yr!==`employee`){await m(),vr=null,yr=null,Dr();return}yr===`employee`&&await Or(vr.id),Er(`dashboard`)}else Dr()}u.auth.onAuthStateChange(e=>{e===`SIGNED_OUT`&&(vr=null,yr=null,Dr())}),Ar();